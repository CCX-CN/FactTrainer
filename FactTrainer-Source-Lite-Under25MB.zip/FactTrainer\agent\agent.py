import math
import re
from collections import Counter
from typing import Any

from agent.answer_post_processor import AnswerPostProcessor
from agent.knowledge_graph import StructuredKnowledgeReasoner
from agent.language import LanguageLayer


class Agent:
    """A trainable Agent whose answers are derived from learned concept structures."""

    UNKNOWN_ANSWER = "我尚未掌握与该问题匹配的知识。"
    INTENT_PROTOTYPES = {
        "definition": "是什么 定义 含义 概念 说明",
        "principle": "为什么 原理 机制 原因 因果 解释",
        "application": "如何使用 应用场景 什么时候用 解决问题 示例",
        "troubleshooting": "错误 异常 失败 原因 修复 排查 误解",
        "comparison": "区别 对比 比较 相同 不同 优缺点",
        "reasoning": "如果 假设 条件变化 推导 预测 结果 会怎样",
    }
    INTENT_DIMENSIONS = {
        "definition": ["concept", "explanation"],
        "principle": ["concept", "conditions", "principle", "process", "result"],
        "application": ["concept", "principle", "applications", "examples"],
        "troubleshooting": ["concept", "common_errors", "principle", "conditions"],
        "comparison": ["concept", "principle", "applications", "conditions"],
        "reasoning": ["conditions", "principle", "process", "result", "key_understandings"],
    }
    INTENT_CUES = {
        "definition": {"是什么": 0.7, "定义": 1.0, "含义": 1.0},
        "principle": {"为什么": 1.2, "为何": 1.2, "原理": 1.2, "机制": 1.0, "原因": 1.0},
        "application": {"如何使用": 1.2, "什么时候用": 1.2, "应用": 1.0, "场景": 0.9},
        "troubleshooting": {"报错": 1.2, "错误": 1.0, "修复": 1.0, "排查": 1.0},
        "comparison": {"区别": 1.2, "对比": 1.2, "比较": 1.0, "不同": 0.9},
        "reasoning": {"如果": 0.9, "假设": 1.0, "推导": 1.2, "预测": 1.2, "会怎样": 1.0},
    }

    def __init__(self, name: str, domain: str) -> None:
        self.name = name
        self.domain = domain
        self.level = 0
        self.score = 0
        self.learned_knowledge: dict[str, str] = {}
        self.knowledge_keywords: dict[str, list[str]] = {}
        self.knowledge_structures: dict[str, dict[str, Any]] = {}
        self.knowledge_graph: dict[str, Any] = {
            "concepts": {}, "attributes": [], "relations": [],
            "rules": [], "causal_links": [],
        }
        self.mastery: dict[str, dict[str, int | str]] = {}
        self.learning_gaps: dict[str, list[str]] = {}
        self.last_answer_log: dict[str, Any] | None = None
        self.answer_logs: list[dict[str, Any]] = []
        self.language_layer = LanguageLayer()
        self.answer_post_processor = AnswerPostProcessor()

    def answer_question(self, topic: str) -> str:
        return self.answer_text(topic)

    def answer_with_reasoning(self, question: str) -> dict[str, Any]:
        """Return the local reasoning trace without changing answer_text callers."""
        final_answer = self.answer_text(question)
        return {
            "reasoning_trace": list((self.last_answer_log or {}).get("reasoning_trace", [])),
            "final_answer": final_answer,
        }

    def answer_text(self, question: str) -> str:
        """Run the local understand → plan → retrieve → reason → verify loop."""
        understanding = self._understand_question(question)
        plan = self._plan_knowledge(understanding)
        selected = self._retrieve_multiple_knowledge(understanding, plan)
        if not selected:
            return self._finish_answer(
                question, understanding, [], [], 0.0,
                self.language_layer.unknown_answer(question),
            )

        answer, steps, coverage = self._reason_answer(understanding, plan, selected)
        verification = self._verify_answer(understanding, plan, selected, answer, coverage)

        # A failed reasoning-step check gets one regeneration pass. It never calls a model.
        if not verification["passed"]:
            expanded_plan = dict(plan)
            expanded_plan["missing_reasoning_steps"] = verification["missing_dimensions"]
            expanded_plan["max_knowledge"] = min(5, plan["max_knowledge"] + 2)
            expanded = self._retrieve_multiple_knowledge(understanding, expanded_plan)
            answer, steps, coverage = self._reason_answer(understanding, expanded_plan, expanded)
            steps.insert(0, "verification_retry:" + ",".join(verification["missing_dimensions"]))
            verification = self._verify_answer(understanding, expanded_plan, expanded, answer, coverage)
            selected = expanded

        if not verification["passed"]:
            answer = self.language_layer.unknown_answer(question)
        confidence = self._answer_confidence(selected, verification)
        return self._finish_answer(
            question, understanding, selected, steps, confidence, answer, verification
        )

    def _understand_question(self, question: str) -> dict[str, Any]:
        parsed = self.language_layer.parse_question(question, self._language_terms())
        # Preserve the proven retrieval focus used by legacy text knowledge.
        if not parsed["target_concepts"]:
            neutral = parsed["normalized_question"].casefold().replace(
                self.domain.casefold(), " "
            )
            for prototype in self.INTENT_PROTOTYPES.values():
                for marker in prototype.split():
                    neutral = neutral.replace(marker, " ")
            parsed["focus"] = (
                re.sub(r"[？?！!，,。；;：:\s]+", " ", neutral).strip()
                or parsed["normalized_question"]
            )
        return parsed

    def _language_terms(self) -> dict[str, str]:
        terms: dict[str, str] = {}
        for knowledge in self.knowledge_structures.values():
            for concept in knowledge.get("concepts", []):
                canonical = str(concept.get("name") or concept.get("id") or "").strip()
                if not canonical:
                    continue
                terms[canonical] = canonical
                for alias in concept.get("aliases", []):
                    if str(alias).strip():
                        terms[str(alias).strip()] = canonical
        return terms

    @staticmethod
    def _detect_counterfactual(question: str) -> dict[str, str] | None:
        """Extract an intervention without encoding any domain-specific answer."""
        match = re.search(
            r"(?:如果|假设|若)[^，,。；;？?]{0,16}?"
            r"(?P<action>删除|移除|去掉|修改|改变|替换)\s*"
            r"(?P<target>[^，,。；;？?]+)",
            question,
        )
        if not match:
            return None
        target = match.group("target").strip()
        return {"action": match.group("action"), "target": target}

    def _plan_knowledge(self, understanding: dict[str, Any]) -> dict[str, Any]:
        intents = understanding.get("intents", [understanding["intent"]])
        dimensions = list(dict.fromkeys(
            field for intent in intents for field in self.INTENT_DIMENSIONS[intent]
        ))
        plan = {
            "intent": understanding["intent"],
            "intents": intents,
            "required_dimensions": dimensions,
            "roles": ["core", "supporting", "application", "error"],
            "max_knowledge": 4 if "comparison" in intents else 3,
        }
        if understanding.get("reasoning_mode") == "counterfactual":
            plan["required_reasoning_steps"] = [
                "intervention", "preserved_inputs", "state_change",
                "downstream_effect", "causal_explanation",
            ]
        return plan

    def _retrieve_multiple_knowledge(
        self, understanding: dict[str, Any], plan: dict[str, Any]
    ) -> list[dict[str, Any]]:
        records = [
            (
                topic,
                self._knowledge_structure(topic),
                float(self.mastery.get(topic, {}).get("score", 0)) / 100,
            )
            for topic in self.learned_knowledge
        ]
        graph_selected = StructuredKnowledgeReasoner.retrieve(
            understanding.get("normalized_question", understanding["question"]),
            records,
            plan["max_knowledge"],
        )
        if understanding.get("response_language") == "en":
            english_selected = self.language_layer.rank_english_knowledge(
                understanding["question"], records, plan["max_knowledge"]
            )
            # English questions must pass the same learned-evidence gate. Do
            # not fall through to a weak generic graph match when no English
            # concept actually matches the question.
            return english_selected
        if graph_selected:
            return graph_selected

        ranked: list[dict[str, Any]] = []
        focus = understanding["focus"]
        question = understanding["question"]
        dimensions = plan["required_dimensions"]
        for topic in self.learned_knowledge:
            knowledge = self._knowledge_structure(topic)
            if StructuredKnowledgeReasoner.has_model(knowledge):
                continue
            identity = " ".join(
                [topic, str(knowledge.get("concept", "")), *self._as_list(knowledge.get("keywords"))]
            )
            requested = " ".join(
                str(item)
                for field in dimensions
                for item in self._as_list(knowledge.get(field))
            )
            full = self._searchable_text(knowledge)
            field_values = [
                str(value)
                for field in (
                    "topic", "concept", "explanation", "principle", "conditions",
                    "process", "result", "applications", "common_errors", "examples",
                )
                for value in self._as_list(knowledge.get(field))
            ]
            best_field = max(
                (self._similarity(focus, value) for value in field_values), default=0.0
            )
            relevance = (
                self._similarity(focus, identity) * 0.35
                + self._similarity(focus, requested) * 0.25
                + best_field * 0.30
                + self._similarity(question, full) * 0.10
            )
            mastery = float(self.mastery.get(topic, {}).get("score", 0)) / 100
            ranked.append({
                "topic": topic,
                "knowledge": knowledge,
                "relevance": relevance,
                "mastery": mastery,
            })
        ranked.sort(key=lambda item: (item["relevance"], item["mastery"]), reverse=True)
        if not ranked or ranked[0]["relevance"] < 0.10:
            return []
        floor = max(0.08, ranked[0]["relevance"] * 0.38)
        selected = [item for item in ranked if item["relevance"] >= floor]
        return selected[: plan["max_knowledge"]]

    def _retrieve_knowledge(self, query: str) -> tuple[str, dict[str, Any], float] | None:
        """Compatibility wrapper over the multi-knowledge planner."""
        understanding = self._understand_question(query)
        selected = self._retrieve_multiple_knowledge(
            understanding, self._plan_knowledge(understanding)
        )
        if not selected:
            return None
        best = selected[0]
        return best["topic"], best["knowledge"], best["relevance"]

    def _knowledge_structure(self, topic: str) -> dict[str, Any]:
        if topic in self.knowledge_structures:
            return self.knowledge_structures[topic]
        # Backward-compatible view for agents saved before structured learning.
        return {
            "topic": topic,
            "concept": topic,
            "explanation": self.learned_knowledge.get(topic, ""),
            "principle": self.learned_knowledge.get(topic, ""),
            "applications": [],
            "common_errors": [],
            "prerequisites": [],
            "examples": [],
            "keywords": self.knowledge_keywords.get(topic, []),
            "concepts": [],
            "attributes": [],
            "relations": [],
            "rules": [],
            "causal_links": [],
        }

    @classmethod
    def _searchable_text(cls, knowledge: dict[str, Any]) -> str:
        fields = (
            "topic", "concept", "explanation", "principle", "mechanism",
            "process", "result", "applications", "common_errors",
            "prerequisites", "examples", "keywords",
        )
        values = []
        for field in fields:
            value = knowledge.get(field, "")
            values.extend(str(item) for item in value) if isinstance(value, list) else values.append(str(value))
        return " ".join(values)

    @classmethod
    def _features(cls, text: str) -> Counter:
        folded = text.casefold()
        normalized = re.sub(r"\s+", "", folded)
        chinese = "".join(re.findall(r"[\u4e00-\u9fff]", normalized))
        words = re.findall(r"[a-z_][a-z0-9_]*|\d+(?:\.\d+)?", folded)
        grams = [chinese[index:index + 2] for index in range(max(0, len(chinese) - 1))]
        return Counter([*words, *grams])

    @classmethod
    def _similarity(cls, left: str, right: str) -> float:
        a, b = cls._features(left), cls._features(right)
        if not a or not b:
            return 0.0
        common = sum(min(value, b.get(key, 0)) for key, value in a.items())
        cosine = sum(a[key] * b.get(key, 0) for key in a) / (
            math.sqrt(sum(value * value for value in a.values()))
            * math.sqrt(sum(value * value for value in b.values()))
        )
        containment = common / sum(a.values())
        return cosine * 0.35 + containment * 0.65

    def _reason_answer(
        self,
        understanding: dict[str, Any],
        plan: dict[str, Any],
        selected: list[dict[str, Any]],
    ) -> tuple[str, list[str], set[str]]:
        """Select question-specific evidence, then build a grounded reasoning chain."""
        if any(
            StructuredKnowledgeReasoner.has_model(item["knowledge"])
            for item in selected
        ):
            graph_answer, trace, coverage = StructuredKnowledgeReasoner.reason(
                understanding, selected
            )
            if understanding.get("intent") == "principle" and not (
                {"principle", "process", "result"} & coverage
            ):
                principle = str(
                    selected[0]["knowledge"].get("principle")
                    or selected[0]["knowledge"].get("explanation")
                    or ""
                ).strip()
                if principle:
                    graph_answer = "\n".join(value for value in (graph_answer, principle) if value)
                    coverage.add("principle")
                    trace.append("grounded_principle:" + selected[0]["topic"])
            generated = self.language_layer.generate_answer({
                "question_type": understanding.get("question_type", "definition"),
                "question": understanding.get("question", ""),
                "response_language": understanding.get("response_language", "zh"),
                "target_concepts": understanding.get("target_concepts", []),
                "selected_knowledge": selected,
                "statements": graph_answer.splitlines(),
                "reasoning_trace": trace,
            })
            return generated, trace, coverage

        if understanding.get("reasoning_mode") == "counterfactual":
            return self._reason_counterfactual(understanding, selected)

        dimensions = plan["required_dimensions"]
        propositions: list[dict[str, Any]] = []
        steps: list[str] = []

        for index, item in enumerate(selected):
            knowledge = item["knowledge"]
            topic = item["topic"]
            role = "core" if index == 0 else self._knowledge_role(knowledge, dimensions)
            steps.append(f"{role}:{topic}")
            for field in dimensions:
                for value in self._as_list(knowledge.get(field)):
                    for sentence in re.split(r"(?<=[。！？；])|\n+", value):
                        normalized = sentence.strip("。； \n")
                        if normalized:
                            propositions.append({
                                "topic": topic,
                                "field": field,
                                "text": normalized,
                            })

        chosen = self._select_question_evidence(understanding, propositions)
        coverage = {item["field"] for item in chosen}
        answer = "\n".join(
            dict.fromkeys(item["text"].rstrip("。！？") + "。" for item in chosen)
        )
        steps.extend(
            f"回答子问题:{item['clause']} -> {item['topic']}.{item['field']}"
            for item in chosen
            if item.get("clause")
        )
        steps.append("组织字段:" + ",".join(sorted(coverage)))
        return answer, steps, coverage

    def _reason_counterfactual(
        self,
        understanding: dict[str, Any],
        selected: list[dict[str, Any]],
    ) -> tuple[str, list[str], set[str]]:
        """Apply an intervention to learned state relations and propagate its effects."""
        counterfactual = understanding["counterfactual"]
        action = counterfactual["action"]
        target = counterfactual["target"]
        compact_target = re.sub(r"\s+", "", target)
        evidence = " ".join(
            self._searchable_text(item["knowledge"]) for item in selected
        )
        steps: list[str] = []
        statements: list[str] = []
        covered: set[str] = set()

        statements.append(f"反事实改变仅作用于{compact_target}这一操作。")
        steps.append(f"intervention:{action} {compact_target}")
        covered.add("intervention")

        assignment = re.fullmatch(
            r"(?P<target>[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*)"
            r"=(?P<source>[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*|[^=]+)",
            compact_target,
        )
        compact_evidence = re.sub(r"\s+", "", evidence).casefold()
        if (
            assignment
            and assignment.group("target").casefold() in compact_evidence
            and assignment.group("source").casefold() in compact_evidence
        ):
            state_target = assignment.group("target")
            source = assignment.group("source")
            attribute = state_target.rsplit(".", 1)[-1]
            owner = state_target.rsplit(".", 1)[0] if "." in state_target else "对象"
            created = re.search(r"创建\s*([A-Za-z_]\w*)\s*对象", understanding["question"])
            class_name = created.group(1) if created else ""
            instance_name = class_name[:1].lower() + class_name[1:] if class_name else owner

            input_role = "构造参数" if created else "输入值"
            statements.append(
                f"{source}仍作为{input_role}存在，因为干预没有删除这个输入。"
            )
            steps.append(f"preserved_inputs:{source}")
            covered.add("preserved_inputs")

            statements.append(
                f"但是{state_target}不再接收{source}，所以新对象不会形成{attribute}属性状态。"
            )
            steps.append(f"state_change:{state_target}=unassigned")
            covered.add("state_change")

            access_path = f"{instance_name}.{attribute}" if instance_name else state_target
            statements.append(
                f"因此后续通过{access_path}访问时，无法取得原本应保存的{source}。"
            )
            steps.append(f"downstream_effect:{access_path}=unavailable")
            covered.add("downstream_effect")

            statements.append(
                f"因果关系是：{compact_target}原本把{source}写入对象状态；删除该写入后，输入仍在，但状态及依赖它的访问结果不再成立。"
            )
            steps.append(f"causal_explanation:{source}->{state_target}->{access_path}")
            covered.add("causal_explanation")
        else:
            relation = self._find_intervention_relation(compact_target, selected)
            if relation:
                statements.extend(relation["statements"])
                steps.extend(relation["steps"])
                covered.update(relation["covered"])

        return "\n".join(statements), steps, covered

    def _find_intervention_relation(
        self,
        target: str,
        selected: list[dict[str, Any]],
    ) -> dict[str, Any] | None:
        """Fallback for non-assignment interventions using source-backed relations."""
        candidates = []
        for item in selected:
            knowledge = item["knowledge"]
            for field in ("principle", "process", "result", "explanation", "applications"):
                for value in self._as_list(knowledge.get(field)):
                    score = self._similarity(target, value)
                    if score:
                        candidates.append((score, field, value))
        if not candidates:
            return None
        _, field, relation = max(candidates, key=lambda item: item[0])
        return {
            "statements": [
                f"未被改变的输入和前置条件继续成立。",
                f"被改变的{target}原本参与这一关系：{relation}。",
                f"该关系失去原有条件后，其结果不能再按原方式成立。",
            ],
            "steps": [
                "preserved_inputs:other premises",
                f"state_change:{target}",
                f"downstream_effect:{field}",
                f"causal_explanation:{target}->{field}",
            ],
            "covered": {
                "preserved_inputs", "state_change", "downstream_effect", "causal_explanation"
            },
        }

    def _select_question_evidence(
        self,
        understanding: dict[str, Any],
        propositions: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Ground each sub-question in different evidence instead of dumping a summary."""
        chosen: list[dict[str, Any]] = []
        for clause in understanding.get("clauses", [understanding["question"]]):
            ranked = sorted(
                propositions,
                key=lambda item: self._similarity(clause, item["text"]),
                reverse=True,
            )
            if not ranked:
                continue
            best_score = self._similarity(clause, ranked[0]["text"])
            if best_score < 0.04:
                continue
            anchor_count = 2 if len(clause) > 18 else 1
            for item in ranked[:anchor_count]:
                evidence = dict(item)
                evidence["clause"] = clause
                evidence["score"] = self._similarity(clause, item["text"])
                if evidence["text"] not in {current["text"] for current in chosen}:
                    chosen.append(evidence)

        # Add the closest causal/mechanism support for the selected direct evidence.
        support_fields = {"principle", "process", "result", "conditions", "explanation"}
        for anchor in list(chosen):
            supporting = [
                item for item in propositions
                if item["topic"] == anchor["topic"]
                and item["field"] in support_fields
                and item["text"] not in {current["text"] for current in chosen}
            ]
            if not supporting:
                continue
            support = max(
                supporting,
                key=lambda item: self._similarity(anchor["text"], item["text"]),
            )
            relation_score = self._similarity(anchor["text"], support["text"])
            if relation_score >= 0.05:
                evidence = dict(support)
                evidence["clause"] = anchor.get("clause", "")
                evidence["score"] = relation_score
                chosen.append(evidence)
        return chosen

    @staticmethod
    def _knowledge_role(knowledge: dict[str, Any], dimensions: list[str]) -> str:
        if knowledge.get("applications") and "applications" in dimensions:
            return "application"
        if knowledge.get("common_errors") and "common_errors" in dimensions:
            return "error"
        return "supporting"

    def _verify_answer(
        self,
        understanding: dict[str, Any],
        plan: dict[str, Any],
        selected: list[dict[str, Any]],
        answer: str,
        coverage: set[str],
    ) -> dict[str, Any]:
        if understanding.get("reasoning_mode") == "counterfactual":
            required_steps = set(plan.get("required_reasoning_steps", []))
            missing_steps = sorted(required_steps - coverage)
            relevant = bool(selected) and selected[0]["relevance"] >= 0.10
            return {
                "passed": bool(answer.strip()) and relevant and not missing_steps,
                "answered_intent": "counterfactual",
                "knowledge_relevant": relevant,
                "missing_dimensions": missing_steps,
                "coverage_ratio": (
                    len(required_steps & coverage) / len(required_steps)
                    if required_steps else 0.0
                ),
            }

        required = set(plan["required_dimensions"])
        alternatives_by_intent = {
            "definition": [{"concept"}, {"explanation"}],
            "principle": [{"principle"}, {"process", "result"}],
            "application": [{"applications"}, {"principle"}, {"explanation"}],
            "troubleshooting": [{"common_errors"}, {"principle"}],
            "comparison": [{"concept"}],
            "reasoning": [{"principle", "result"}, {"principle", "process"}, {"principle"}],
        }
        missing = []
        for intent in understanding.get("intents", [understanding["intent"]]):
            alternatives = alternatives_by_intent[intent]
            if not any(option <= coverage for option in alternatives):
                missing.extend(sorted(min(alternatives, key=len) - coverage))
        missing = list(dict.fromkeys(missing))
        enough_sources = "comparison" not in understanding.get("intents", []) or len(selected) >= 2
        relevant = bool(selected) and selected[0]["relevance"] >= 0.10
        passed = bool(answer.strip()) and relevant and enough_sources and not missing
        return {
            "passed": passed,
            "answered_intent": understanding["intent"],
            "knowledge_relevant": relevant,
            "missing_dimensions": missing,
            "coverage_ratio": len(coverage & required) / len(required) if required else 0.0,
        }

    @staticmethod
    def _answer_confidence(
        selected: list[dict[str, Any]], verification: dict[str, Any]
    ) -> float:
        if not selected:
            return 0.0
        relevance = sum(item["relevance"] for item in selected) / len(selected)
        mastery = sum(item["mastery"] for item in selected) / len(selected)
        confidence = relevance * 0.55 + verification["coverage_ratio"] * 0.35 + mastery * 0.10
        return round(min(1.0, confidence), 3)

    def _finish_answer(
        self,
        question: str,
        understanding: dict[str, Any],
        selected: list[dict[str, Any]],
        steps: list[str],
        confidence: float,
        answer: str,
        verification: dict[str, Any] | None = None,
    ) -> str:
        answer = self.answer_post_processor.process(answer, question)
        log = {
            "question": question,
            "question_type": understanding.get("question_type", "definition"),
            "target_concepts": understanding.get("target_concepts", []),
            "intent": understanding["intent"],
            "selected_knowledge": [item["topic"] for item in selected],
            "reasoning_steps": steps,
            "reasoning_trace": steps,
            "confidence": confidence,
            "verification": verification or {"passed": False, "missing_dimensions": ["knowledge"]},
        }
        self.last_answer_log = log
        self.answer_logs.append(log)
        del self.answer_logs[:-50]
        return answer

    @staticmethod
    def _as_list(value: Any) -> list[str]:
        if isinstance(value, list):
            return [str(item).strip() for item in value if str(item).strip()]
        return [str(value).strip()] if value and str(value).strip() else []

    def learn(
        self,
        topic: str,
        content: str,
        level: str = "basic",
        keywords: list[str] | None = None,
        knowledge: dict[str, Any] | None = None,
    ) -> None:
        """Absorb a transferable concept structure supplied by training."""
        structured = dict(knowledge or {})
        structured.setdefault("topic", topic)
        structured.setdefault("concept", structured.get("concept") or topic)
        structured.setdefault("explanation", structured.get("content") or content)
        structured.setdefault("principle", structured.get("mechanism") or content)
        structured.setdefault("applications", [])
        structured.setdefault("common_errors", [])
        structured.setdefault("prerequisites", [])
        structured.setdefault("examples", structured.get("example", []))
        structured.setdefault("keywords", list(keywords or []))
        for field in ("concepts", "attributes", "relations", "rules", "causal_links"):
            structured.setdefault(field, [])
        self.learned_knowledge[topic] = content
        self.knowledge_keywords[topic] = [str(item) for item in structured["keywords"]]
        self.knowledge_structures[topic] = structured
        self._store_knowledge_graph(topic, structured)
        self.mastery.setdefault(topic, {"level": level, "score": 0})
        self.level = len(self.learned_knowledge)

    def _store_knowledge_graph(self, topic: str, knowledge: dict[str, Any]) -> None:
        """Store semantic nodes and edges separately from legacy text."""
        prefix = topic + ":"
        self.knowledge_graph["concepts"] = {
            key: value
            for key, value in self.knowledge_graph.get("concepts", {}).items()
            if not key.startswith(prefix)
        }
        for field in ("attributes", "relations", "rules", "causal_links"):
            self.knowledge_graph[field] = [
                value for value in self.knowledge_graph.get(field, [])
                if value.get("_topic") != topic
            ]
        for index, concept in enumerate(knowledge.get("concepts", [])):
            value = dict(concept)
            identifier = str(value.get("id") or value.get("name") or index)
            value["_topic"] = topic
            self.knowledge_graph["concepts"][prefix + identifier] = value
        for field in ("attributes", "relations", "rules", "causal_links"):
            for item in knowledge.get(field, []):
                value = dict(item)
                value["_topic"] = topic
                self.knowledge_graph[field].append(value)

    def supplement_knowledge(self, topic: str, missing_dimensions: list[str], knowledge: dict[str, Any]) -> None:
        """Record a diagnosed gap and relearn the complete source-backed concept."""
        self.learning_gaps[topic] = list(dict.fromkeys(str(item) for item in missing_dimensions))
        self.learn(topic, str(knowledge.get("content", "")), str(knowledge.get("level", "basic")),
                   knowledge.get("keywords", []), knowledge)

    def update_mastery(self, topic: str, level: str, score: int) -> None:
        self.mastery[topic] = {"level": level, "score": score}
        if score >= 70:
            self.learning_gaps.pop(topic, None)

    def update_score(self, score: int) -> None:
        self.score = score
