import re


class AnswerPostProcessor:
    """Remove internal graph notation from a grounded Agent answer."""

    MAX_FACTS = 3
    MAX_LENGTH = 150
    ENGLISH_MAX_LENGTH = 320

    def process(self, answer: str, question: str = "") -> str:
        text = str(answer or "").strip()
        if not text:
            return text

        english_output = bool(re.search(r"[A-Za-z]", text)) and not re.search(r"[\u4e00-\u9fff]", text)
        if english_output:
            text = re.sub(r"\s+", " ", text)
            sentences = []
            for part in re.split(r"(?<=[.!?])\s+", text):
                sentence = self._strip_english_heading(part.strip())
                if not sentence:
                    continue
                sentence = re.sub(r"\s+\d+([.!?])$", r"\1", sentence)
                sentence = sentence[:1].upper() + sentence[1:]
                key = re.sub(r"\W+", " ", sentence.casefold()).strip()
                if any(
                    key == existing_key
                    or key.startswith(existing_key + " ")
                    or key in existing_key
                    for existing_key, _ in sentences
                ):
                    continue
                sentences.append((key, sentence))
            result = " ".join(sentence for _, sentence in sentences[: self.MAX_FACTS])
            if len(result) > self.ENGLISH_MAX_LENGTH:
                result = result[: self.ENGLISH_MAX_LENGTH - 1].rsplit(" ", 1)[0].rstrip(" ,;:.") + "."
            return result

        text = re.sub(r"(?:知识关系|推理路径|关系路径)\s*[：:]\s*", "", text)
        text = self._naturalize_relations(text)
        text = re.sub(r"\b(?:relation_hop|direct_evidence|concept_match)\b[^。；\n]*", "", text)
        text = re.sub(r"随后[，,：:]?", "", text)

        facts = []
        for part in re.split(r"[。；\n]+", text):
            fact = re.sub(r"\s+", "", part).strip("，,：:；;。 ")
            if fact and fact not in facts:
                facts.append(fact)
        facts = self._select_facts(facts, question)

        result = "。".join(facts)
        if result and not result.endswith("。"):
            result += "。"
        if len(result) > self.MAX_LENGTH:
            result = result[: self.MAX_LENGTH - 1].rstrip("，,：:；;。 ") + "。"
        return result

    @staticmethod
    def _strip_english_heading(sentence: str) -> str:
        """Remove a title-case knowledge heading prepended to a real sentence."""
        return re.sub(
            r"^(?:[A-Z][A-Za-z'-]*\s+){1,5}"
            r"(?=(?:[A-Z][A-Za-z'-]*|Cats?)\s+"
            r"(?:is|are|has|have|need|needs|use|uses|should|can|may|must|require|requires)\b)",
            "",
            sentence,
        )

    def _select_facts(self, facts: list[str], question: str) -> list[str]:
        if len(facts) <= self.MAX_FACTS:
            return facts

        def features(text: str) -> set[str]:
            chinese = "".join(re.findall(r"[\u4e00-\u9fff]", text))
            grams = {chinese[index:index + 2] for index in range(max(0, len(chinese) - 1))}
            return grams | set(re.findall(r"[A-Za-z_][A-Za-z0-9_]*", text.casefold()))

        question_features = features(question)
        ranked = []
        for index, fact in enumerate(facts):
            overlap = len(question_features & features(fact))
            explanation = sum(marker in fact for marker in ("因为", "因此", "导致", "时", "后", "会", "可以", "需要", "自动"))
            vague = sum(marker in fact for marker in ("当前", "相关内容", "已经", "完成使用"))
            score = overlap * 3 + explanation * 0.4 + min(len(fact), 40) / 40 - vague * 4
            ranked.append((score, index, fact))
        keep = {index for _, index, _ in sorted(ranked, reverse=True)[: self.MAX_FACTS]}
        return [fact for index, fact in enumerate(facts) if index in keep]

    @staticmethod
    def _naturalize_relations(text: str) -> str:
        triple = re.compile(
            r"(?P<source>[^。；\n→]+?)\s*(?:--)?→\s*"
            r"(?P<relation>[^。；\n→]+?)\s*(?:--)?→\s*"
            r"(?P<target>[^。；\n→]+)"
        )

        def replace_triple(match: re.Match) -> str:
            source = match.group("source").strip(" ，,:：")
            relation = match.group("relation").strip(" ，,:：")
            target = match.group("target").strip(" ，,:：")
            return f"{source}{relation}{target}"

        text = triple.sub(replace_triple, text)
        text = re.sub(
            r"因果边\s*([^。；\n→]+?)\s*→\s*([^。；\n→]+?)被切断",
            lambda match: (
                f"{match.group(1).strip()}与{match.group(2).strip()}之间的因果联系被切断"
            ),
            text,
        )
        text = re.sub(
            r"([^。；\n→]+?)\s*→\s*([^。；\n→]+)",
            lambda match: f"{match.group(1).strip()}会影响{match.group(2).strip()}",
            text,
        )
        relation_phrase = re.compile(
            r"(?P<source>[^。；\n，,]+?)与(?P<target>[^。；\n，,]+?)的关系是"
            r"(?P<relation>[^。；\n，,]+)(?:[，,]即(?P<description>[^。；\n]+))?"
        )

        def replace_relation(match: re.Match) -> str:
            source = match.group("source").strip()
            target = match.group("target").strip()
            relation = match.group("relation").strip()
            description = (match.group("description") or "").strip()
            if relation == "通过" and description.startswith(target):
                return f"{source}通过{description}"
            natural = f"{source}{relation}{target}"
            return f"{natural}，{description}" if description else natural

        return relation_phrase.sub(replace_relation, text)
