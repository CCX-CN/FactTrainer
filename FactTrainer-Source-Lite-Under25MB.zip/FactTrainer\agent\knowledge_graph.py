import math
import re
from collections import Counter
from typing import Any


class StructuredKnowledgeReasoner:
    """Local graph retrieval and relation composition for structured knowledge."""

    MODEL_FIELDS = ("concepts", "attributes", "relations", "rules", "causal_links")
    KIND_DIMENSIONS = {
        "concept": {"concept", "explanation"},
        "attribute": {"concept", "explanation"},
        "relation": {"principle", "process"},
        "rule": {"conditions", "process", "result", "applications"},
        "causal": {"conditions", "principle", "result"},
    }
    INTENT_KINDS = {
        "definition": ("concept", "attribute", "relation"),
        "principle": ("causal", "rule", "relation", "attribute"),
        "application": ("rule", "relation", "attribute", "causal"),
        "troubleshooting": ("rule", "causal", "relation", "attribute"),
        "comparison": ("concept", "attribute", "relation"),
        "reasoning": ("rule", "causal", "relation", "attribute"),
    }

    @classmethod
    def has_model(cls, knowledge: dict[str, Any]) -> bool:
        return any(knowledge.get(field) for field in cls.MODEL_FIELDS)

    @classmethod
    def retrieve(
        cls,
        question: str,
        records: list[tuple[str, dict[str, Any], float]],
        limit: int,
    ) -> list[dict[str, Any]]:
        question_key = cls._normalize(question)
        model_records = [record for record in records if cls.has_model(record[1])]
        entity_frequency: Counter[str] = Counter()
        entity_sets: dict[str, set[str]] = {}
        for topic, knowledge, _ in model_records:
            keys = {
                cls._normalize(entity)
                for entity in cls._entities(knowledge)
                if cls._is_meaningful_entity(entity)
            }
            entity_sets[topic] = keys
            entity_frequency.update(keys)

        ranked = []
        total = max(1, len(model_records))
        for topic, knowledge, mastery in model_records:
            entities = cls._entities(knowledge)
            hits = [entity for entity in entities if cls._entity_in_question(entity, question)]
            identity_values = [
                topic,
                str(knowledge.get("concept", "")),
                str(knowledge.get("principle", "")),
                *[str(value) for field in ("applications", "common_errors", "examples")
                  for value in (knowledge.get(field, []) if isinstance(knowledge.get(field, []), list) else [knowledge.get(field, "")])
                  if str(value).strip()],
            ]
            identity_relevance = max(
                (cls._text_similarity(question, value) for value in identity_values),
                default=0.0,
            )
            fact_relevance = max(
                (cls._text_similarity(question, cls._render_fact(fact))
                 for fact in cls._facts([{"topic": topic, "knowledge": knowledge}])),
                default=0.0,
            )
            lexical = min(1.0, identity_relevance * 0.65 + fact_relevance * 0.55)
            specific_score = 0.0
            for entity in hits:
                key = cls._normalize(entity)
                if not cls._is_meaningful_entity(entity):
                    continue
                rarity = math.log((total + 1) / (entity_frequency.get(key, total) + 1)) + 0.35
                specific_score += min(1.0, len(key) / 6) * rarity
            relevance = min(1.0, lexical + min(1.0, specific_score) * 0.28)
            if relevance >= 0.06:
                ranked.append({
                    "topic": topic,
                    "knowledge": knowledge,
                    "relevance": relevance,
                    "identity_relevance": identity_relevance,
                    "mastery": mastery,
                    "matched_entities": hits,
                })
        ranked.sort(key=lambda item: (item["relevance"], item["mastery"]), reverse=True)
        if not ranked:
            return []

        # Add support only through a specific, uncommon bridge. A generic domain
        # entity shared by most records is not evidence that the topics belong in
        # the same answer.
        core_entities = entity_sets.get(ranked[0]["topic"], set())
        known_topics = {item["topic"] for item in ranked}
        for topic, knowledge, mastery in model_records:
            if topic in known_topics or not cls.has_model(knowledge):
                continue
            shared = {
                key for key in core_entities & entity_sets.get(topic, set())
                if entity_frequency.get(key, total) <= max(1, total // 2)
            }
            identity_values = [
                topic,
                str(knowledge.get("concept", "")),
                str(knowledge.get("principle", "")),
                *[str(value) for field in ("applications", "common_errors", "examples")
                  for value in (knowledge.get(field, []) if isinstance(knowledge.get(field, []), list) else [knowledge.get(field, "")])
                  if str(value).strip()],
            ]
            identity_relevance = max(
                (cls._text_similarity(question, value) for value in identity_values),
                default=0.0,
            )
            fact_relevance = max(
                (cls._text_similarity(question, cls._render_fact(fact))
                 for fact in cls._facts([{"topic": topic, "knowledge": knowledge}])),
                default=0.0,
            )
            lexical = min(1.0, identity_relevance * 0.65 + fact_relevance * 0.55)
            if shared and lexical >= 0.06:
                ranked.append({
                    "topic": topic,
                    "knowledge": knowledge,
                    "relevance": min(0.45, lexical * 0.65 + len(shared) * 0.08),
                    "identity_relevance": identity_relevance,
                    "mastery": mastery,
                    "matched_entities": sorted(shared),
                })
        ranked.sort(key=lambda item: (item["relevance"], item["mastery"]), reverse=True)
        best_identity = max(item.get("identity_relevance", 0.0) for item in ranked)
        if best_identity >= 0.10:
            ranked = [
                item for item in ranked
                if item.get("identity_relevance", 0.0) >= best_identity * 0.35
            ]
        floor = max(0.06, ranked[0]["relevance"] * 0.70)
        selected = [item for item in ranked if item["relevance"] >= floor]
        if best_identity < 0.10:
            selected = selected[:1]
        return selected[:limit]

    @classmethod
    def reason(
        cls,
        understanding: dict[str, Any],
        selected: list[dict[str, Any]],
    ) -> tuple[str, list[str], set[str]]:
        if understanding.get("reasoning_mode") == "counterfactual":
            return cls._counterfactual(understanding, selected)

        facts = [fact for fact in cls._facts(selected) if cls._fact_is_usable(fact)]
        chosen: list[dict[str, Any]] = []
        steps: list[str] = []
        question_key = understanding.get("normalized_question", understanding["question"])
        seed_entities = cls._question_entities(question_key, facts, selected)
        if seed_entities:
            steps.append("concept_match:" + ",".join(seed_entities))

        # Traverse only short, question-relevant paths. Path diversity alone is
        # not sufficient evidence: it previously pulled unrelated facts from the
        # same domain into one answer.
        paths = cls._search_paths(cls._graph_edges(facts), seed_entities, max_hops=2)
        primary_intent = understanding.get("intent", "definition")
        preferred_kinds = cls.INTENT_KINDS[primary_intent]
        if primary_intent == "definition":
            paths = []
        paths.sort(
            key=lambda path: cls._path_score(path, question_key, preferred_kinds),
            reverse=True,
        )
        selected_paths: list[list[dict[str, Any]]] = []
        if paths:
            best_path_score = cls._path_score(paths[0], question_key, preferred_kinds)
            for kind in preferred_kinds[:2]:
                candidate = next(
                    (path for path in paths if any(edge["fact"]["kind"] == kind for edge in path)),
                    None,
                )
                if (
                    candidate
                    and cls._path_score(candidate, question_key, preferred_kinds)
                    >= max(0.16, best_path_score * 0.72)
                    and candidate not in selected_paths
                ):
                    selected_paths.append(candidate)
            for path in paths:
                if len(selected_paths) == 2:
                    break
                score = cls._path_score(path, question_key, preferred_kinds)
                if score < max(0.16, best_path_score * 0.72):
                    continue
                if path not in selected_paths:
                    selected_paths.append(path)

        for path in selected_paths:
            for edge in path:
                fact = edge["fact"]
                if fact["signature"] not in {item["signature"] for item in chosen}:
                    chosen.append(fact)
                steps.append(
                    f"relation_hop:{edge['source']} -[{edge['label']}]-> {edge['target']}"
                )
                if fact["kind"] == "rule":
                    steps.append(f"rule_applied:{fact['signature']}")
                elif fact["kind"] == "causal":
                    steps.append(f"causal_applied:{fact['signature']}")

        clauses = understanding.get("clauses", [understanding["question"]])
        intents = understanding.get("intents", [understanding["intent"]])
        for index, clause in enumerate(clauses):
            intent = intents[min(index, len(intents) - 1)]
            preferred = cls.INTENT_KINDS[intent]
            clause_entities = {
                entity for item in selected for entity in cls._entities(item["knowledge"])
                if cls._entity_in_question(entity, clause)
            }
            ranked = sorted(
                facts,
                key=lambda fact: cls._fact_score(
                    fact, clause, clause_entities, preferred
                ),
                reverse=True,
            )
            for fact in ranked[:1]:
                if cls._fact_score(fact, clause, clause_entities, preferred) < 0.14:
                    continue
                if fact["signature"] not in {item["signature"] for item in chosen}:
                    chosen.append(fact)
                    steps.append(
                        f"subquestion:{clause} -> {fact['topic']}.{fact['kind']}:{fact['signature']}"
                    )
                    if fact["kind"] == "rule":
                        steps.append(f"rule_applied:{fact['signature']}")
                    elif fact["kind"] == "causal":
                        steps.append(f"causal_applied:{fact['signature']}")

        if not chosen:
            ranked_facts = sorted(
                facts,
                key=lambda fact: cls._fact_score(
                    fact, question_key, set(seed_entities), preferred_kinds
                ),
                reverse=True,
            )
            if ranked_facts:
                best_fact_score = cls._fact_score(
                    ranked_facts[0], question_key, set(seed_entities), preferred_kinds
                )
                for fact in ranked_facts:
                    score = cls._fact_score(
                        fact, question_key, set(seed_entities), preferred_kinds
                    )
                    if score < max(0.09, best_fact_score * 0.62):
                        continue
                    chosen.append(fact)
                    steps.append("direct_evidence:" + fact["signature"])
                    if len(chosen) == 3:
                        break

        # Keep the final evidence set compact. Every retained fact must come from
        # a selected shortest path or be the best direct answer to a sub-question.
        chosen = chosen[:4]

        answer = "\n".join(dict.fromkeys(cls._render_fact(fact) for fact in chosen))
        coverage = set().union(
            *(cls.KIND_DIMENSIONS[fact["kind"]] for fact in chosen)
        ) if chosen else set()
        return answer, list(dict.fromkeys(steps)), coverage

    @classmethod
    def _fact_score(
        cls,
        fact: dict[str, Any],
        question_key: str,
        seed_entities: set[str],
        preferred_kinds: tuple[str, ...],
    ) -> float:
        meaningful_entities = [
            entity for entity in fact["entities"] if cls._is_meaningful_entity(entity)
        ]
        meaningful = {cls._normalize(entity) for entity in meaningful_entities}
        seed_keys = {cls._normalize(entity) for entity in seed_entities}
        direct = sum(
            sorted(
                (cls._entity_match_score(entity, question_key) for entity in meaningful_entities),
                reverse=True,
            )[:2]
        )
        # Seed bridges must not reward a generic entity (for example "cat")
        # more than a specific phrase (for example "litter box usage").
        bridge = min(1.0, direct)
        kind_score = (
            (len(preferred_kinds) - preferred_kinds.index(fact["kind"]))
            / len(preferred_kinds)
            if fact["kind"] in preferred_kinds else 0.0
        )
        lexical = cls._text_similarity(question_key, cls._render_fact(fact))
        return (
            min(1.0, direct) * 0.30
            + min(1.0, bridge) * 0.16
            + lexical * 0.20
            + kind_score * 0.10
            + float(fact.get("knowledge_relevance", 0.0)) * 0.08
            + float(fact.get("topic_alignment", 0.0)) * 0.16
        )

    @staticmethod
    def _entity_match_score(entity: str, question: str) -> float:
        if not re.search(r"[A-Za-z]", entity):
            key = StructuredKnowledgeReasoner._normalize(entity)
            query = StructuredKnowledgeReasoner._normalize(question)
            return min(1.0, len(key) / 6) if key and key in query else 0.0
        stop = {"a", "an", "the", "of", "to", "and", "or", "is", "are", "that", "this"}
        entity_words = [
            word for word in re.findall(r"[a-z0-9]+", str(entity).casefold())
            if word not in stop
        ]
        question_words = set(re.findall(r"[a-z0-9]+", str(question).casefold())) - stop
        overlap = set(entity_words) & question_words
        if not entity_words or not overlap:
            return 0.0
        if len(entity_words) == 1:
            return min(1.0, len(entity_words[0]) / 10)
        ratio = len(overlap) / len(set(entity_words))
        return min(1.0, len(overlap) * 0.45 + ratio * 0.55)

    @classmethod
    def _fact_is_usable(cls, fact: dict[str, Any]) -> bool:
        if len(cls._render_fact(fact)) > 280:
            return False
        if (
            fact["kind"] == "concept"
            and str(fact["data"].get("definition", "")).startswith("材料原子事实中的概念：")
        ):
            return False
        if fact["kind"] == "concept":
            return any(cls._is_meaningful_entity(entity) for entity in fact["entities"])
        meaningful = {
            cls._normalize(entity)
            for entity in fact["entities"]
            if cls._is_meaningful_entity(entity)
        }
        return len(meaningful) >= 2

    @classmethod
    def _path_score(
        cls,
        path: list[dict[str, Any]],
        question_key: str,
        preferred_kinds: tuple[str, ...],
    ) -> float:
        if not path:
            return 0.0
        fact_scores = [
            cls._fact_score(edge["fact"], question_key, set(), preferred_kinds)
            for edge in path
        ]
        preferred = any(edge["fact"]["kind"] == preferred_kinds[0] for edge in path)
        return sum(fact_scores) / len(fact_scores) + (0.12 if preferred else 0.0) - 0.08 * (len(path) - 1)

    @classmethod
    def _question_entities(
        cls,
        question_key: str,
        facts: list[dict[str, Any]],
        selected: list[dict[str, Any]],
    ) -> list[str]:
        entities = [
            entity
            for fact in facts
            for entity in fact["entities"]
            if cls._is_meaningful_entity(entity)
            and cls._entity_in_question(entity, question_key)
        ]
        if not entities:
            entities = [
                entity
                for item in selected
                for entity in item.get("matched_entities", [])
                if cls._is_meaningful_entity(entity)
            ]
        return list(dict.fromkeys(entity for entity in entities if cls._normalize(entity)))

    @classmethod
    def _graph_edges(cls, facts: list[dict[str, Any]]) -> list[dict[str, Any]]:
        edges: list[dict[str, Any]] = []

        def add(source: Any, target: Any, label: str, fact: dict[str, Any]) -> None:
            source_text, target_text = str(source or "").strip(), str(target or "").strip()
            if not source_text or not target_text:
                return
            edges.append({
                "source": source_text,
                "target": target_text,
                "source_key": cls._normalize(source_text),
                "target_key": cls._normalize(target_text),
                "label": label,
                "fact": fact,
            })

        for fact in facts:
            data, kind = fact["data"], fact["kind"]
            if kind == "relation":
                add(data.get("source"), data.get("target"), str(data.get("relation", "关系")), fact)
            elif kind == "rule":
                action = data.get("action")
                for condition in data.get("conditions", []):
                    add(condition, action, "满足条件", fact)
                add(action, data.get("result"), "产生结果", fact)
            elif kind == "causal":
                cause = data.get("cause")
                for condition in data.get("conditions", []):
                    add(condition, cause, "使因果成立", fact)
                add(cause, data.get("effect"), "导致", fact)

        # Traversal is bidirectional; rendering still keeps the source fact's direction.
        reverse = [
            {
                **edge,
                "source": edge["target"],
                "target": edge["source"],
                "source_key": edge["target_key"],
                "target_key": edge["source_key"],
                "label": "反向追溯" + edge["label"],
            }
            for edge in edges
        ]
        return [*edges, *reverse]

    @classmethod
    def _search_paths(
        cls,
        edges: list[dict[str, Any]],
        seed_entities: list[str],
        max_hops: int = 2,
    ) -> list[list[dict[str, Any]]]:
        adjacency: dict[str, list[dict[str, Any]]] = {}
        for edge in edges:
            adjacency.setdefault(edge["source_key"], []).append(edge)

        queue: list[tuple[str, list[dict[str, Any]], set[str]]] = [
            (cls._normalize(seed), [], {cls._normalize(seed)})
            for seed in seed_entities
            if cls._normalize(seed)
        ]
        paths: list[list[dict[str, Any]]] = []
        while queue:
            node, path, visited = queue.pop(0)
            if len(path) >= max_hops:
                continue
            for edge in adjacency.get(node, []):
                target = edge["target_key"]
                if not target or target in visited:
                    continue
                next_path = [*path, edge]
                paths.append(next_path)
                queue.append((target, next_path, {*visited, target}))

        # Prefer the shortest supported path; rules and causal links break ties.
        paths.sort(
            key=lambda path: (
                -len(path),
                sum(edge["fact"]["kind"] in {"rule", "causal"} for edge in path),
            ),
            reverse=True,
        )
        unique: list[list[dict[str, Any]]] = []
        signatures: set[tuple[str, ...]] = set()
        for path in paths:
            signature = tuple(edge["fact"]["signature"] for edge in path)
            if signature not in signatures:
                signatures.add(signature)
                unique.append(path)
        return unique

    @classmethod
    def _counterfactual(
        cls,
        understanding: dict[str, Any],
        selected: list[dict[str, Any]],
    ) -> tuple[str, list[str], set[str]]:
        intervention = understanding["counterfactual"]
        target = cls._normalize(intervention["target"])
        rules = [fact for fact in cls._facts(selected) if fact["kind"] in {"rule", "causal"}]
        affected = [
            fact for fact in rules
            if target in cls._normalize(fact["action_or_cause"])
            or cls._normalize(fact["action_or_cause"]) in target
        ]
        if not affected:
            return "", ["counterfactual:no matching graph edge"], {"intervention"}

        statements = []
        steps = [f"intervention:{intervention['action']} {intervention['target']}"]
        coverage = {"intervention"}
        for fact in affected:
            conditions = fact.get("conditions", [])
            if conditions:
                statements.append("；".join(conditions) + "仍然成立。")
                steps.append("preserved_inputs:" + ",".join(conditions))
                coverage.add("preserved_inputs")
            effect = fact["effect_or_result"]
            statements.append(f"{fact['action_or_cause']}被移除后，{effect}不再由该关系产生。")
            steps.append(f"state_change:{effect}=not_produced")
            coverage.add("state_change")
            steps.append(f"downstream_effect:{effect}=not_produced")
            coverage.add("downstream_effect")

            downstream = [
                other for other in cls._facts(selected)
                if other["signature"] != fact["signature"]
                and cls._fact_is_usable(other)
                and float(other.get("topic_alignment", 0.0)) >= 0.04
                and any(
                    cls._normalize(entity) in cls._normalize(effect)
                    or cls._normalize(effect) in cls._normalize(entity)
                    for entity in other["entities"]
                    if cls._normalize(entity)
                )
            ]
            downstream.sort(
                key=lambda item: {
                    "relation": 5, "rule": 4, "causal": 3,
                    "attribute": 2, "concept": 1,
                }[item["kind"]],
                reverse=True,
            )
            if downstream:
                statements.extend(
                    f"依赖这一状态的关系随之失效：{cls._render_fact(item)}"
                    for item in downstream[:2]
                )
                steps.append("downstream_effect:" + ",".join(item["signature"] for item in downstream[:2]))
                coverage.add("downstream_effect")
            statements.append(f"因果边{fact['action_or_cause']} → {effect}被切断。")
            steps.append(f"causal_explanation:{fact['action_or_cause']}->{effect}")
            coverage.add("causal_explanation")
        return "\n".join(dict.fromkeys(statements)), steps, coverage

    @classmethod
    def _facts(cls, selected: list[dict[str, Any]]) -> list[dict[str, Any]]:
        facts = []
        for selected_item in selected:
            topic, knowledge = selected_item["topic"], selected_item["knowledge"]
            start = len(facts)
            for item in knowledge.get("concepts", []):
                facts.append(cls._fact(topic, "concept", item, [item.get("id"), item.get("name"), *item.get("aliases", [])]))
            for item in knowledge.get("attributes", []):
                facts.append(cls._fact(topic, "attribute", item, [item.get("subject"), item.get("name"), item.get("value")]))
            for item in knowledge.get("relations", []):
                facts.append(cls._fact(topic, "relation", item, [item.get("source"), item.get("relation"), item.get("target")]))
            for item in knowledge.get("rules", []):
                fact = cls._fact(topic, "rule", item, [*item.get("conditions", []), item.get("action"), item.get("result")])
                fact.update(action_or_cause=str(item.get("action", "")), effect_or_result=str(item.get("result", "")), conditions=item.get("conditions", []))
                facts.append(fact)
            for item in knowledge.get("causal_links", []):
                fact = cls._fact(topic, "causal", item, [item.get("cause"), item.get("effect"), *item.get("conditions", [])])
                fact.update(action_or_cause=str(item.get("cause", "")), effect_or_result=str(item.get("effect", "")), conditions=item.get("conditions", []))
                facts.append(fact)
            topic_anchor = " ".join((
                topic,
                str(knowledge.get("concept", "")),
                str(knowledge.get("principle", "")),
            ))
            for fact in facts[start:]:
                fact["knowledge_relevance"] = float(selected_item.get("relevance", 0.0))
                fact["topic_alignment"] = cls._text_similarity(
                    topic_anchor, cls._render_fact(fact)
                )
        return facts

    @staticmethod
    def _fact(topic: str, kind: str, data: dict[str, Any], entities: list[Any]) -> dict[str, Any]:
        clean_entities = [str(value).strip() for value in entities if str(value or "").strip()]
        return {
            "topic": topic,
            "kind": kind,
            "data": data,
            "entities": clean_entities,
            "signature": f"{kind}:" + "|".join(clean_entities),
        }

    @classmethod
    def _render_fact(cls, fact: dict[str, Any]) -> str:
        data, kind = fact["data"], fact["kind"]
        if kind == "concept":
            return f"{data.get('name', '')}：{data.get('definition', '')}。"
        if kind == "attribute":
            description = data.get("description") or data.get("value", "")
            return f"{data.get('subject', '')}的{data.get('name', '')}表示{description}。"
        if kind == "relation":
            source = str(data.get("source", "")).strip()
            target = str(data.get("target", "")).strip()
            relation = str(data.get("relation", "关系")).strip()
            description = str(data.get("description", "")).strip()
            if relation in {"是", "为", "属于", "包括", "需要", "支持", "通过", "用于"}:
                statement = f"{source}{relation}{target}"
            else:
                statement = f"{source}与{target}的关系是{relation}"
            if description and cls._normalize(description) != cls._normalize(statement):
                statement += f"，即{description}"
            return statement + "。"
        if kind == "rule":
            conditions = "；".join(str(value) for value in data.get("conditions", []))
            return f"在{conditions}时，{data.get('action', '')}，结果是{data.get('result', '')}。"
        conditions = "；".join(str(value) for value in data.get("conditions", []))
        suffix = f"，条件是{conditions}" if conditions else ""
        cause = str(data.get("cause", "")).strip().removesuffix("会")
        return f"{cause}会导致{data.get('effect', '')}{suffix}。"

    @classmethod
    def _entities(cls, knowledge: dict[str, Any]) -> list[str]:
        values = []
        for fact in cls._facts([{"topic": "", "knowledge": knowledge}]):
            values.extend(fact["entities"])
        normalized = []
        for value in values:
            for part in re.split(r"[\s，,。；;：:（）()]+", value):
                if part and part not in normalized:
                    normalized.append(part)
                # Mixed labels such as "Python列表" must also be searchable by
                # their natural-language concept ("列表"). This is structural
                # normalization, not a domain-specific synonym table.
                if re.search(r"[A-Za-z0-9_]", part) and re.search(r"[\u4e00-\u9fff]", part):
                    for fragment in re.findall(r"[\u4e00-\u9fff]{2,}", part):
                        if fragment not in normalized:
                            normalized.append(fragment)
        return normalized

    @classmethod
    def _entity_in_question(cls, entity: str, question_key: str) -> bool:
        key = cls._normalize(entity)
        if not key:
            return False
        if re.search(r"[A-Za-z]", entity):
            entity_words = re.findall(r"[a-z0-9]+", str(entity).casefold())
            question_words = re.findall(r"[a-z0-9]+", str(question_key).casefold())
            if not entity_words:
                return False
            # Avoid accidental compact-string matches such as "cats" across
            # "cat stops". Match complete English words or complete phrases.
            phrase = " ".join(entity_words)
            return phrase in " ".join(question_words) or (
                len(entity_words) == 1 and entity_words[0] in question_words
            )
        # A one-character symbol such as N must not match the n inside "Python".
        if len(key) == 1 and key.isascii():
            return bool(re.search(rf"(?<![a-z0-9_]){re.escape(key)}(?![a-z0-9_])", question_key))
        return key in question_key or question_key in key

    @classmethod
    def _is_meaningful_entity(cls, entity: str) -> bool:
        key = cls._normalize(entity)
        if len(key) < 2 or re.fullmatch(r"concept_[a-f0-9]+", key):
            return False
        return not key.endswith("关系") or len(key) > 4

    @classmethod
    def _graph_text(cls, knowledge: dict[str, Any]) -> str:
        return " ".join(
            cls._render_fact(fact)
            for fact in cls._facts([{"topic": "", "knowledge": knowledge}])
        )

    @staticmethod
    def _text_features(text: str) -> Counter[str]:
        folded = str(text).casefold()
        normalized = re.sub(r"\s+", "", folded)
        # Preserve English word boundaries. Removing spaces before tokenization
        # collapsed an entire paragraph into one token and made every question
        # fall back to the first generic fact.
        words = re.findall(r"[a-z_][a-z0-9_]*|\d+(?:\.\d+)?", folded)
        chinese = "".join(re.findall(r"[\u4e00-\u9fff]", normalized))
        grams = [chinese[index:index + 2] for index in range(max(0, len(chinese) - 1))]
        return Counter([*words, *grams])

    @classmethod
    def _text_similarity(cls, left: str, right: str) -> float:
        query, evidence = cls._text_features(left), cls._text_features(right)
        if not query or not evidence:
            return 0.0
        common = sum(min(value, evidence.get(key, 0)) for key, value in query.items())
        containment = common / sum(query.values())
        cosine = sum(query[key] * evidence.get(key, 0) for key in query) / (
            math.sqrt(sum(value * value for value in query.values()))
            * math.sqrt(sum(value * value for value in evidence.values()))
        )
        return containment * 0.72 + cosine * 0.28

    @staticmethod
    def _normalize(value: str) -> str:
        return "".join(character for character in str(value).casefold() if character.isalnum() or character in "._=")
