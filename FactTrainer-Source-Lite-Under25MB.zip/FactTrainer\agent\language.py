import re
from typing import Any


class LanguageLayer:
    """Offline language adapter around the Agent's learned knowledge graph."""

    QUESTION_CUES = {
        "counterfactual": ("如果", "假设", "删除", "移除", "改变", "替换", "if", "suppose", "remove", "change", "replace"),
        "causal": ("为什么", "为何", "原因", "导致", "因果", "怎么会", "why", "cause", "because"),
        "condition": ("条件", "前提", "什么情况下", "何时", "什么时候", "when", "condition"),
        "application": ("如何使用", "怎么用", "如何", "怎样", "应该", "检查", "处理", "体现", "应用", "场景", "解决", "how", "should", "use", "apply"),
        "definition": ("是什么", "定义", "含义", "指什么", "what is", "what are", "define"),
    }
    BILINGUAL_TERMS = {
        "ordinary human food": "普通人类食物",
        "human food": "普通人类食物",
        "obligate carnivores": "专性肉食动物",
        "obligate carnivore": "专性肉食动物",
        "cats": "猫",
        "cat": "猫",
        "taurine": "牛磺酸",
        "litter box": "猫砂盆",
        "scratching": "抓挠",
        "important": "essential",
        "lack": "deficiency",
        "problem": "health issue",
    }
    ENGLISH_PHRASES = {
        "猫是专性肉食动物": "Cats are obligate carnivores",
        "猫属于专性肉食动物": "Cats are obligate carnivores",
        "猫需要动物性营养来源": "Cats need animal-based sources of nutrition",
        "专性肉食动物需要牛磺酸": "Obligate carnivores require taurine",
        "牛磺酸属于关键营养": "Taurine is an essential nutrient",
        "普通人类食物通常不能完整满足猫的营养需求": "Ordinary human food generally does not fully meet cats' nutritional needs",
        "牛磺酸摄入不足会导致视力和心脏功能受损": "Taurine deficiency can impair eye health and heart function",
        "牛磺酸摄入不足": "taurine deficiency",
        "视力和心脏功能受损": "impaired eye health and heart function",
        "长期只吃普通人类食物": "a cat eats only ordinary human food for a long time",
        "长期吃普通人类食物": "a cat eats ordinary human food for a long time",
        "关键营养摄入不足": "its intake of essential nutrients becomes insufficient",
        "健康风险增加": "its health risks increase",
        "长期缺乏": "the deficiency is prolonged",
    }
    INTENT_MAP = {
        "definition": "definition",
        "causal": "principle",
        "condition": "reasoning",
        "application": "application",
        "counterfactual": "reasoning",
    }

    def parse_question(
        self,
        question: str,
        term_map: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        original = str(question).strip()
        language = self.detect_language(original)
        learned_terms = {
            str(value).casefold() for value in (term_map or {}).values() if str(value).strip()
        }
        cross_language = {
            alias: canonical
            for alias, canonical in self.BILINGUAL_TERMS.items()
            if not re.search(r"[\u4e00-\u9fff]", canonical)
            or canonical.casefold() in learned_terms
        }
        normalized = self.normalize_terms(original, {**cross_language, **(term_map or {})})
        question_type = self._question_type(normalized)
        clauses = [
            clause.strip()
            for clause in re.split(r"[，,。；;？！?!]+", normalized)
            if clause.strip()
        ] or [normalized]
        targets = self._target_concepts(original, normalized, term_map or {})
        counterfactual = self._counterfactual(normalized) if question_type == "counterfactual" else None
        intent = self.INTENT_MAP[question_type]
        return {
            "question": original,
            "normalized_question": normalized,
            "question_type": question_type,
            "target_concepts": targets,
            "intent": intent,
            "intents": [intent],
            "clauses": clauses,
            "focus": " ".join(targets) or normalized,
            "intent_scores": {intent: 1.0},
            "reasoning_mode": "counterfactual" if counterfactual else "evidence",
            "counterfactual": counterfactual,
            "response_language": language,
        }

    def rank_english_knowledge(
        self,
        question: str,
        records: list[tuple[str, dict[str, Any], float]],
        limit: int,
    ) -> list[dict[str, Any]]:
        """Rank clean English graph facts without trusting long imported text blobs."""
        query = self._english_words(question) - {
            "why", "what", "when", "where", "which", "how", "do", "does",
            "can", "could", "should", "would", "the", "for", "from", "with",
            "into", "about", "mean", "need", "cat", "in", "is", "to", "of",
            "and", "or", "are",
        }
        if not query:
            return []
        ranked = []
        for topic, knowledge, mastery in records:
            evidence = self._clean_english_graph_text(knowledge)
            words = self._english_words(evidence)
            matched = query & words
            if not matched:
                continue
            coverage = len(matched) / len(query)
            specificity = len(matched) / max(1, len(words) ** 0.5)
            relevance = min(1.0, coverage * 0.78 + specificity * 0.22)
            ranked.append({
                "topic": topic,
                "knowledge": knowledge,
                "relevance": relevance,
                "identity_relevance": relevance,
                "mastery": mastery,
                "matched_entities": sorted(matched),
                "english_relevance": True,
            })
        ranked.sort(key=lambda item: (item["relevance"], item["mastery"]), reverse=True)
        if not ranked or ranked[0]["relevance"] < 0.16:
            return []
        floor = max(0.14, ranked[0]["relevance"] * 0.68)
        return [item for item in ranked if item["relevance"] >= floor][:limit]

    @staticmethod
    def _english_words(text: str) -> set[str]:
        words = [
            word for word in re.findall(r"[a-z][a-z0-9-]*", str(text).casefold())
            if len(word) >= 2
        ]
        normalized = set()
        for word in words:
            if len(word) > 5 and word.endswith("ing"):
                word = word[:-3]
            elif len(word) > 4 and word.endswith("ed"):
                word = word[:-2]
            elif len(word) > 4 and word.endswith("es"):
                word = word[:-2]
            elif len(word) > 3 and word.endswith("s"):
                word = word[:-1]
            normalized.add(word)
        return normalized

    @staticmethod
    def _clean_english_graph_text(knowledge: dict[str, Any]) -> str:
        values = []

        def add(value: Any, maximum: int = 180) -> None:
            text = str(value or "").strip()
            if text and len(text) <= maximum and not re.search(r"[\u4e00-\u9fff]", text):
                values.append(text)

        for field in ("topic", "concept", "content", "explanation", "principle"):
            add(knowledge.get(field))
        for keyword in knowledge.get("keywords", []):
            add(keyword, 80)
        for concept in knowledge.get("concepts", []):
            if isinstance(concept, dict):
                add(concept.get("name"), 100)
                add(concept.get("definition"), 160)
                for alias in concept.get("aliases", []):
                    add(alias, 80)
        for field in ("attributes", "relations", "rules", "causal_links"):
            for fact in knowledge.get(field, []):
                if isinstance(fact, dict):
                    for value in fact.values():
                        if isinstance(value, list):
                            for item in value:
                                add(item, 100)
                        else:
                            add(value, 160)
        return " ".join(values)

    @staticmethod
    def detect_language(text: str) -> str:
        """Use the user's question, not the learned material, to choose output language."""
        chinese_count = len(re.findall(r"[\u4e00-\u9fff]", str(text)))
        latin_count = len(re.findall(r"[A-Za-z]", str(text)))
        return "zh" if chinese_count >= latin_count else "en"

    @staticmethod
    def normalize_terms(text: str, term_map: dict[str, str]) -> str:
        normalized = str(text)
        for alias, canonical in sorted(term_map.items(), key=lambda item: len(item[0]), reverse=True):
            alias = str(alias).strip()
            canonical = str(canonical).strip()
            if alias and canonical and alias.casefold() != canonical.casefold():
                pattern = re.escape(alias)
                if re.fullmatch(r"[A-Za-z0-9_ ]+", alias):
                    pattern = rf"(?<![A-Za-z0-9_]){pattern}(?![A-Za-z0-9_])"
                normalized = re.sub(pattern, canonical, normalized, flags=re.IGNORECASE)
        # Normalize common English question grammar into the same semantic cues
        # used by the local graph retriever. This changes no learned fact.
        normalized = re.sub(
            r"why\s+can(?:not|'t)\s+(.+?)\s+eat\s+(.+?)\s+for\s+a\s+long\s+time",
            r"为什么\1不能长期吃\2",
            normalized,
            flags=re.IGNORECASE,
        )
        return normalized

    def generate_answer(self, reasoning_result: dict[str, Any]) -> str:
        """Verbalize graph-derived statements without introducing new facts."""
        statements = [
            str(item).strip().rstrip("。")
            for item in reasoning_result.get("statements", [])
            if str(item).strip()
        ]
        statements = list(dict.fromkeys(statements))[:4]
        if not statements or not reasoning_result.get("reasoning_trace"):
            return ""

        language = reasoning_result.get("response_language", "zh")
        if language == "en":
            source_support = self._english_source_support(reasoning_result)
            translated = [self._to_english(statement) for statement in statements]
            # Prefer the most question-specific sentences from the learned
            # source. Graph verbalization remains a fallback, not the lead.
            source_limit = 3 if reasoning_result.get("question_type") in {"causal", "counterfactual"} else 1
            translated = source_support[:source_limit] or [
                *self._english_grounded_support(reasoning_result),
                *self._english_graph_support(reasoning_result),
                *translated,
            ]
            translated = [statement for statement in translated if statement]
            translated = list(dict.fromkeys(translated))[:4]
            return ". ".join(translated).rstrip(". ") + "." if translated else ""

        question_type = reasoning_result.get("question_type", "definition")
        if question_type == "counterfactual":
            return "。\n".join(statements) + "。"
        if question_type == "causal" and len(statements) > 1:
            return "；".join(statements) + "。"
        if question_type == "condition" and len(statements) > 1:
            return "；".join(statements) + "。"
        if question_type == "application" and len(statements) > 1:
            return "；".join(statements) + "。"
        return "；".join(statements) + "。"

    def unknown_answer(self, question: str) -> str:
        if self.detect_language(question) == "en":
            return "I have not learned enough relevant knowledge to answer this question."
        return "我尚未掌握与该问题匹配的知识。"

    def _to_english(self, statement: str) -> str:
        """Offline, fact-preserving verbalization; it does not add outside knowledge."""
        text = statement.strip().rstrip("。")

        concept = re.fullmatch(r"(.+?)：(.+)", text)
        if concept and not re.search(r"[\u4e00-\u9fff]", "".join(concept.groups())):
            return f"{concept.group(1)} is {concept.group(2)}"

        attribute = re.fullmatch(r"(.+?)的(.+?)表示(.+)", text)
        if attribute and not re.search(r"[\u4e00-\u9fff]", "".join(attribute.groups())):
            return f"{attribute.group(1)} has {attribute.group(2)}: {attribute.group(3)}"

        relation = re.fullmatch(r"(.+?)与(.+?)的关系是(.+?)(?:，即(.+))?", text)
        if relation and not re.search(r"[\u4e00-\u9fff]", "".join(value or "" for value in relation.groups()[:3])):
            source, target, verb, description = relation.groups()
            result = f"{source} {verb} {target}"
            clean_description = description and not re.search(r"[\u4e00-\u9fff]", description)
            return f"{result}, meaning {description}" if clean_description else result

        rule = re.fullmatch(r"在(.+)时，(.+)，结果是(.+)", text)
        if rule:
            condition = self._translate_fragment(rule.group(1))
            action = self._translate_fragment(rule.group(2))
            result = self._translate_fragment(rule.group(3))
            if condition and action and result:
                return f"When {condition}, {action}, so {result}"

        causal = re.fullmatch(r"(.+?)会导致(.+?)(?:，条件是(.+))?", text)
        if causal:
            cause = self._translate_fragment(causal.group(1))
            effect = self._translate_fragment(causal.group(2))
            condition = self._translate_fragment(causal.group(3) or "")
            if cause and effect:
                result = f"{cause} causes {effect}"
                return f"{result} when {condition}" if condition else result

        for source, target in sorted(self.ENGLISH_PHRASES.items(), key=lambda item: len(item[0]), reverse=True):
            text = text.replace(source, target)

        text = text.replace("，即", ", meaning ").replace("，条件是", " when ")
        text = text.replace("；", "; ").replace("，", ", ")
        text = re.sub(r"\s+", " ", text).strip()
        # Never expose untranslated graph notation as an English answer.
        if re.search(r"[\u4e00-\u9fff]", text):
            return ""
        return text[:1].upper() + text[1:] if text else ""

    def _translate_fragment(self, text: str) -> str:
        translated = str(text).strip()
        for source, target in sorted(self.ENGLISH_PHRASES.items(), key=lambda item: len(item[0]), reverse=True):
            translated = translated.replace(source, target)
        return "" if re.search(r"[\u4e00-\u9fff]", translated) else translated

    def _english_grounded_support(self, result: dict[str, Any]) -> list[str]:
        """Verbalize directly connected learned causes; never add external facts."""
        targets = [str(value) for value in result.get("target_concepts", [])]
        support = []
        for selected in result.get("selected_knowledge", []):
            knowledge = selected.get("knowledge", {})
            for link in knowledge.get("causal_links", []):
                cause, effect = str(link.get("cause", "")), str(link.get("effect", ""))
                if not any(target and (target in cause or target in effect) for target in targets):
                    continue
                cause_en, effect_en = self._translate_fragment(cause), self._translate_fragment(effect)
                if cause_en and effect_en:
                    support.append(f"{cause_en.capitalize()} can cause {effect_en}")
        return support

    def _english_graph_support(self, result: dict[str, Any]) -> list[str]:
        """Render English relations already present in the selected knowledge graph."""
        query = self._english_words(result.get("question", ""))
        candidates = []
        allow_context = any(
            item.get("english_relevance") for item in result.get("selected_knowledge", [])
        )
        for selected in result.get("selected_knowledge", []):
            knowledge = selected.get("knowledge", {})
            for relation in knowledge.get("relations", []):
                if not isinstance(relation, dict):
                    continue
                source = str(relation.get("source", "")).replace("_", " ").strip()
                verb = str(relation.get("relation", "")).replace("_", " ").strip()
                target = str(relation.get("target", "")).replace("_", " ").strip()
                core = " ".join((source, verb, target)).strip()
                if not core or re.search(r"[\u4e00-\u9fff]", core):
                    continue
                score = len(query & self._english_words(core))
                if score or allow_context:
                    candidates.append((score, core[:1].upper() + core[1:]))
        candidates.sort(key=lambda item: (item[0], -len(item[1])), reverse=True)
        return list(dict.fromkeys(text for _, text in candidates))[:2]

    @staticmethod
    def _english_source_support(result: dict[str, Any]) -> list[str]:
        """Select a short, source-backed cause -> mechanism -> result chain."""
        def word_set(text: str) -> set[str]:
            words = set(re.findall(r"[a-z]{3,}", str(text).casefold()))
            return {
                word[:-1] if len(word) > 3 and word.endswith("s") else word
                for word in words
            }

        stop = {
            "why", "what", "when", "where", "which", "that", "this", "with",
            "from", "have", "time", "cannot", "does", "into", "can", "for",
            "the", "and", "are", "was", "were", "cat",
        }
        question_words = word_set(result.get("question", "")) - stop
        candidates: list[dict[str, Any]] = []
        order = 0
        seen: set[str] = set()
        for selected in result.get("selected_knowledge", []):
            knowledge = selected.get("knowledge", {})
            values = [
                knowledge.get("content", ""), knowledge.get("explanation", ""),
                knowledge.get("principle", ""), *knowledge.get("keywords", []),
            ]
            for relation in knowledge.get("relations", []):
                if isinstance(relation, dict):
                    values.append(relation.get("description", ""))
            for value in values:
                value_text = re.sub(
                    r"(?<=[a-z])\s+(?=[A-Z][a-z]+ing\s+(?:a|an|the)\b)",
                    ". ",
                    str(value),
                )
                sentences = re.split(r"(?<=[.!?])\s+", value_text)
                for index, sentence in enumerate(sentences):
                    sentence = sentence.strip(" -:;,.\n")
                    if (
                        not 20 <= len(sentence) <= 240
                        or re.search(r"[^\x20-\x7E]", sentence)
                        or re.match(r"^(?:to|and|or|but|them)\b", sentence, re.IGNORECASE)
                        or re.search(r"\b(?:may|can|should|must)$", sentence, re.IGNORECASE)
                        or not re.search(
                            r"\b(?:is|are|has|have|can|may|need|require|help|support|reduce|cause|indicate|use|produce|satisfy|maintain|mark|observe|depend)\w*\b",
                            sentence,
                            re.IGNORECASE,
                        )
                    ):
                        continue
                    if re.match(r"^(?:so|they|their|it|this|that)\b", sentence, re.I):
                        if index and sentences[index - 1].strip():
                            previous = sentences[index - 1].strip().rstrip(".!? ")
                            if re.match(r"^so\b", sentence, re.I):
                                sentence = previous + ", " + sentence[:1].lower() + sentence[1:]
                            else:
                                sentence = previous + ", and " + sentence[:1].lower() + sentence[1:]
                        else:
                            continue
                    key = re.sub(r"\W+", " ", sentence.casefold()).strip()
                    if key in seen:
                        continue
                    seen.add(key)
                    words = word_set(sentence) - stop
                    direct = len(question_words & words)
                    if direct:
                        candidates.append({
                            "order": order, "sentence": sentence,
                            "words": words, "direct": direct,
                        })
                    else:
                        candidates.append({
                            "order": order, "sentence": sentence,
                            "words": words, "direct": 0,
                        })
                    order += 1

        if not candidates:
            return []
        direct_candidates = [item for item in candidates if item["direct"]]
        if not direct_candidates:
            return []
        selected_chain = [max(
            direct_candidates,
            key=lambda item: (item["direct"], -len(item["sentence"])),
        )]
        causal = result.get("question_type") in {"causal", "counterfactual"}
        if causal:
            while len(selected_chain) < 3:
                chain_words = set().union(*(item["words"] for item in selected_chain))
                options = []
                for item in candidates:
                    if item in selected_chain:
                        continue
                    bridge = len(item["words"] & chain_words)
                    if not item["direct"] and not bridge:
                        continue
                    causal_marker = int(bool(re.search(
                        r"\b(?:because|require|need|cannot|lack|deficien|cause|support|help|reduce|result)\w*\b",
                        item["sentence"],
                        re.IGNORECASE,
                    )))
                    score = item["direct"] * 2 + bridge + causal_marker * 0.5
                    options.append((score, item))
                if not options:
                    break
                best = max(options, key=lambda pair: (pair[0], -len(pair[1]["sentence"])))[1]
                selected_chain.append(best)
        selected_chain.sort(key=lambda item: item["order"])
        result = []
        for item in selected_chain:
            sentence = item["sentence"]
            normalized = sentence.casefold().rstrip(".!? ")
            if any(normalized.startswith(existing.casefold().rstrip(".!? ")) for existing in result):
                continue
            result.append(sentence)
        return result

    def _question_type(self, question: str) -> str:
        lowered = question.casefold()
        if re.search(r"\bwhy\b", lowered):
            return "causal"
        for question_type in ("counterfactual", "application", "causal", "condition", "definition"):
            if question_type == "counterfactual" and self._counterfactual(question) is None:
                continue
            if any(cue.casefold() in lowered for cue in self.QUESTION_CUES[question_type]):
                return question_type
        return "definition"

    @staticmethod
    def _target_concepts(original: str, normalized: str, term_map: dict[str, str]) -> list[str]:
        targets = []
        for alias, canonical in term_map.items():
            if alias.casefold() in original.casefold() or canonical.casefold() in normalized.casefold():
                targets.append(canonical)
        return list(dict.fromkeys(targets))

    @staticmethod
    def _counterfactual(question: str) -> dict[str, str] | None:
        match = re.search(
            r"(?:如果|假设|若)[^，,。；;？?]{0,16}?"
            r"(?P<action>删除|移除|去掉|修改|改变|替换)\s*"
            r"(?P<target>[^，,。；;？?]+)",
            question,
        )
        if not match:
            return None
        return {"action": match.group("action"), "target": match.group("target").strip()}
