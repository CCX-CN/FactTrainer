import json
import os
import sys
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from agent.agent import Agent
from final_exam import FinalExam
from knowledge.knowledge_base import KnowledgeBase
from questions.question_generator import QuestionGenerator
from training.evaluator import Evaluator
from training.trainer import Trainer
from pipeline.knowledge_pipeline import KnowledgePipeline
from teacher.teacher_agent import TeacherAgent


if getattr(sys, "frozen", False):
    bundle_root = Path(sys._MEIPASS)
    ROOT = bundle_root / "FactTrainer"
    UI_DIR = bundle_root / "ui"
    STATE_FILE = Path(os.environ.get("APPDATA", Path.home())) / "FactTrainer" / "agent_state_v2.json"
    CONFIG_FILE = Path(os.environ.get("APPDATA", Path.home())) / "FactTrainer" / "ai_service.json"
else:
    ROOT = Path(__file__).resolve().parent
    UI_DIR = ROOT.parent / "ui"
    STATE_FILE = ROOT / "data" / "agent_state_v2.json"
    CONFIG_FILE = ROOT / "data" / "ai_service.json"
STATE_VERSION = 2
agent: Agent | None = None
training_result: dict[str, Any] | None = None
exam_result: dict[str, Any] | None = None
chat_history: list[dict[str, str]] = []
lesson_result: dict[str, Any] | None = None
prepared_knowledge_path: Path | None = None


def load_ai_config() -> dict[str, str]:
    """Read the per-user AI configuration without ever returning its key to the UI."""
    if not CONFIG_FILE.exists():
        return {}
    try:
        payload = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return payload if isinstance(payload, dict) else {}


def save_ai_config(api_key: str) -> None:
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    temporary = CONFIG_FILE.with_suffix(".tmp")
    temporary.write_text(
        json.dumps({"gemini_api_key": api_key}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    temporary.replace(CONFIG_FILE)


def ai_service_status() -> dict[str, Any]:
    configured = bool(load_ai_config().get("gemini_api_key") or os.environ.get("GEMINI_API_KEY"))
    return {"configured": configured, "service": "Gemini", "model": "gemini-3-flash-preview"}


def teacher_for_desktop() -> TeacherAgent:
    config = load_ai_config()
    api_key = str(config.get("gemini_api_key") or os.environ.get("GEMINI_API_KEY") or "").strip()
    return TeacherAgent(api_key=api_key)


def save_state() -> None:
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "state_version": STATE_VERSION,
        "agent": None if agent is None else {
            "name": agent.name, "domain": agent.domain, "level": agent.level,
            "score": agent.score, "learned_knowledge": agent.learned_knowledge,
            "knowledge_keywords": agent.knowledge_keywords,
            "knowledge_structures": agent.knowledge_structures,
            "knowledge_graph": agent.knowledge_graph,
            "learning_gaps": agent.learning_gaps,
            "mastery": agent.mastery,
        },
        "training": training_result,
        "exam": exam_result,
        "chat_history": chat_history,
        "lesson": lesson_result,
        "prepared_knowledge_path": (
            str(prepared_knowledge_path) if prepared_knowledge_path else None
        ),
    }
    STATE_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def load_state() -> None:
    global agent, training_result, exam_result, chat_history, lesson_result, prepared_knowledge_path
    if not STATE_FILE.exists():
        return
    payload = json.loads(STATE_FILE.read_text(encoding="utf-8"))
    if payload.get("state_version") != STATE_VERSION:
        return
    saved = payload.get("agent")
    if saved:
        agent = Agent(saved["name"], saved["domain"])
        agent.level = saved.get("level", 0)
        agent.score = saved.get("score", 0)
        agent.learned_knowledge = saved.get("learned_knowledge", {})
        agent.knowledge_keywords = saved.get("knowledge_keywords", {})
        agent.knowledge_structures = saved.get("knowledge_structures", {})
        agent.knowledge_graph = saved.get("knowledge_graph", agent.knowledge_graph)
        if not saved.get("knowledge_graph"):
            for topic, knowledge in agent.knowledge_structures.items():
                agent._store_knowledge_graph(topic, knowledge)
        agent.learning_gaps = saved.get("learning_gaps", {})
        agent.mastery = saved.get("mastery", {})
    training_result = payload.get("training")
    exam_result = payload.get("exam")
    chat_history = payload.get("chat_history", [])
    lesson_result = payload.get("lesson")
    saved_path = payload.get("prepared_knowledge_path")
    prepared_knowledge_path = Path(saved_path) if saved_path else None
    if prepared_knowledge_path is not None and not prepared_knowledge_path.is_file():
        prepared_knowledge_path = None
    if prepared_knowledge_path is None:
        lesson_result = None


def mastery_rates(current_agent: Agent) -> dict[str, int]:
    rates = {}
    for level in ("basic", "intermediate", "advanced"):
        scores = [int(v["score"]) for v in current_agent.mastery.values() if v["level"] == level]
        rates[level] = round(sum(scores) / len(scores)) if scores else 0
    return rates


def state() -> dict[str, Any]:
    if agent is None:
        return {"agent": None, "training": None, "exam": None, "lesson": None, "lesson_status": "empty", "ai_service": ai_service_status()}
    lesson_status = "learned" if training_result else "prepared" if lesson_result else "empty"
    return {
        "agent": {
            "name": agent.name,
            "domain": agent.domain,
            "level": agent.level,
            "score": agent.score,
            "learned_count": len(agent.learned_knowledge),
            "mastery_rates": mastery_rates(agent),
        },
        "training": training_result,
        "exam": exam_result,
        "chat_history": chat_history,
        "lesson": lesson_result,
        "lesson_status": lesson_status,
        "ai_service": ai_service_status(),
    }


def process_teacher_input(text: str, current_agent: Agent) -> tuple[dict[str, Any], Path]:
    """Prepare Teacher-structured knowledge for the target Agent's next training run."""
    teacher = teacher_for_desktop()
    is_topic = len(text) <= 40 and not any(mark in text for mark in ("。", "；", "\n"))
    if is_topic:
        _, knowledge_json = teacher.process_topic(text)
    else:
        document = {
            "title": text.splitlines()[0][:80] or "用户学习材料",
            "content": text,
            "url": "local://user-material",
            "source": "用户提供材料",
        }
        knowledge_json = teacher.process(document)

    KnowledgePipeline.validate(knowledge_json)
    knowledge_items = KnowledgePipeline.to_knowledge_items(
        knowledge_json, current_agent.domain
    )
    output_dir = ROOT / "knowledge" / "generated"
    output_dir.mkdir(parents=True, exist_ok=True)
    knowledge_path = output_dir / KnowledgePipeline._safe_name(current_agent.domain)
    knowledge_path.write_text(
        json.dumps(knowledge_items, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return knowledge_json, knowledge_path


def teacher_error_message(error: Exception) -> str:
    detail = str(error)
    network_markers = ("URLError", "WinError 10013", "timed out", "Network is unreachable", "Name or service not known")
    if any(marker.casefold() in detail.casefold() for marker in network_markers):
        return "Teacher 无法连接网络服务。请检查网络、代理或防火墙设置后重试。"
    if "Gemini API HTTP 401" in detail or "Gemini API HTTP 403" in detail:
        return "Gemini API Key 无效或没有调用权限，请在“AI 服务设置”中更新 API Key。"
    if "Gemini API" in detail:
        return "Gemini 服务暂时不可用，请稍后重试；如持续失败请检查 API Key 和网络。"
    return detail


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, directory=str(UI_DIR), **kwargs)

    def log_message(self, format: str, *args: Any) -> None:
        """The frozen Windows GUI has no stderr stream."""
        return

    def end_headers(self) -> None:
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        super().end_headers()

    def json_response(self, payload: Any, status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def read_json(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0"))
        return json.loads(self.rfile.read(length) or b"{}")

    def do_GET(self) -> None:
        if self.path == "/api/state":
            self.json_response(state())
            return
        if self.path == "/api/config":
            self.json_response({"ai_service": ai_service_status()})
            return
        super().do_GET()

    def do_POST(self) -> None:
        global agent, training_result, exam_result, chat_history, lesson_result, prepared_knowledge_path
        try:
            if self.path == "/api/config":
                data = self.read_json()
                api_key = str(data.get("gemini_api_key", "")).strip()
                if not api_key:
                    self.json_response({"error": "Gemini API Key 不能为空"}, 400)
                    return
                save_ai_config(api_key)
                self.json_response({"ai_service": ai_service_status()})
                return
            if self.path == "/api/agents":
                data = self.read_json()
                name = str(data.get("name", "")).strip()
                if not name:
                    self.json_response({"error": "Agent名称不能为空"}, 400)
                    return
                domain = str(data.get("domain", "")).strip()
                if not domain:
                    self.json_response({"error": "训练领域不能为空"}, 400)
                    return
                agent = Agent(name=name, domain=domain)
                training_result = None
                exam_result = None
                chat_history = []
                lesson_result = None
                prepared_knowledge_path = None
            elif self.path == "/api/train":
                if agent is None:
                    self.json_response({"error": "请先创建Agent"}, 400)
                    return
                if prepared_knowledge_path is None or not prepared_knowledge_path.is_file():
                    self.json_response({"error": f"当前没有 {agent.domain} 领域知识库"}, 400)
                    return
                kb = KnowledgeBase(prepared_knowledge_path)
                kb.load()
                learned_count_before = len(agent.learned_knowledge)
                training_result = Trainer(agent, kb, QuestionGenerator(kb), Evaluator()).train_once()
                training_result["new_knowledge_count"] = len(agent.learned_knowledge) - learned_count_before
                exam_result = None
            elif self.path == "/api/exam":
                if agent is None:
                    self.json_response({"error": "请先创建Agent"}, 400)
                    return
                exam_result = FinalExam(agent).run()
            elif self.path == "/api/chat":
                if agent is None:
                    self.json_response({"error": "请先创建Agent"}, 400)
                    return
                data = self.read_json()
                action = str(data.get("action", "")).strip()
                if action == "ask_agent":
                    question = str(data.get("question", "")).strip()
                    if not question:
                        self.json_response({"error": "问题不能为空"}, 400)
                        return
                    chat_history.append({"question": question, "answer": agent.answer_text(question)})
                elif action == "prepare_material":
                    material = str(data.get("material", "")).strip()
                    if not material:
                        self.json_response({"error": "学习材料不能为空"}, 400)
                        return
                    lesson_result, prepared_knowledge_path = process_teacher_input(material, agent)
                    training_result = None
                    exam_result = None
                else:
                    self.json_response({"error": "无效操作"}, 400)
                    return
            else:
                self.json_response({"error": "Not found"}, 404)
                return
            save_state()
            self.json_response(state())
        except Exception as error:
            self.json_response({"error": teacher_error_message(error)}, 500)


if __name__ == "__main__":
    load_state()
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    print(f"Fact Trainer UI: http://127.0.0.1:{port}")
    ThreadingHTTPServer(("127.0.0.1", port), Handler).serve_forever()
