"""Local core processing used by FactTrainer's training pipeline."""
