import hashlib
import re
from typing import Any


class LocalKnowledgeParser:
    """Rule-based, domain-independent extraction of atomic knowledge facts."""

    RELATIONS = (
        "用于", "用来", "能够", "可以", "减少", "增加", "提高", "降低",
        "导致", "引起", "影响", "依赖", "包含", "包括", "属于", "通过",
        "保存", "管理", "处理", "创建", "生成", "访问", "调用", "释放",
        "返回", "读取", "写入", "转换", "计算", "判断", "选择", "防止",
        "避免", "实现", "等于", "是", "为",
    )
    ACTIONS = (
        "保存", "管理", "处理", "创建", "生成", "访问", "调用", "释放",
        "声明", "控制", "支持", "返回", "读取", "写入", "转换", "计算",
        "判断", "选择", "防止", "避免", "实现", "减少", "增加", "提高", "降低",
    )
    CAUSAL_RELATIONS = {"减少", "增加", "提高", "降低", "导致", "引起", "影响", "防止", "避免"}

    ENGLISH_RELATIONS = (
        "is", "are", "means", "refers to", "requires", "require", "needs", "need",
        "supports", "support", "helps", "help", "provides", "provide", "uses", "use",
        "contains", "contain", "includes", "include", "causes", "cause", "affects", "affect",
        "reduces", "reduce", "increases", "increase", "prevents", "prevent", "allows", "allow",
        "stores", "store", "saves", "save", "produces", "produce", "depends on", "consists of",
    )

    def sentence_split(self, text: str) -> list[str]:
        text = re.sub(r"\s+", " ", str(text)).strip()
        if not text:
            return []
        return [
            part.strip(" ，,。；;！？!?\t\r\n")
            for part in re.split(r"[.!?;\n。；！？]+|[，,](?=\s*[^，,。；;！？!?]{2,})", text)
            if part.strip(" ，,。；;！？!?\t\r\n")
        ]

    def extract_concepts(self, sentence: str) -> list[str]:
        triple = self._extract_relation(sentence)
        if not triple:
            concept = self._clean_concept(sentence)
            return [concept] if concept else []
        concepts = [triple["from"], triple["to"]]
        concepts.extend(self._derived_concepts(triple["to"]))
        return list(dict.fromkeys(item for item in concepts if item))

    def extract_relations(self, sentence: str, concepts: list[str]) -> list[dict[str, str]]:
        triple = self._extract_relation(sentence)
        if not triple or len(concepts) < 2:
            return []
        return [{
            "source": triple["from"],
            "relation": triple["relation"],
            "target": triple["to"],
            "description": f"{triple['from']} {triple['relation']} {triple['to']}",
        }]

    def extract_facts(self, text: str) -> list[dict[str, Any]]:
        """Convert source text into independently addressable atomic facts."""
        facts = []
        for sentence in self.sentence_split(text):
            concepts = self.extract_concepts(sentence)
            relations = self.extract_relations(sentence, concepts)
            if concepts or relations:
                facts.append({
                    "sentence": sentence,
                    "concepts": concepts,
                    "relations": relations,
                })
        return facts

    def build_knowledge_graph(self, text: str) -> dict[str, list[dict[str, Any]]]:
        english = self._is_english(text)
        graph: dict[str, list[dict[str, Any]]] = {
            "concepts": [], "attributes": [], "relations": [],
            "rules": [], "causal_links": [],
        }
        concept_names: list[str] = []
        for fact in self.extract_facts(text):
            sentence = fact["sentence"]
            concepts = fact["concepts"]
            concept_names.extend(concepts)
            relations = fact["relations"]
            graph["relations"].extend(relations)
            for relation in relations:
                graph["attributes"].append({
                    "subject": relation["source"],
                    "name": (
                        f"{relation['relation']} relationship"
                        if english else f"{relation['relation']}关系"
                    ),
                    "value": relation["target"],
                    "description": relation["description"],
                })
                if relation["relation"] in self.CAUSAL_RELATIONS:
                    graph["causal_links"].append({
                        "cause": relation["source"],
                        "effect": self._effect(relation["relation"], relation["target"]),
                        "conditions": [],
                    })
            rule = self._conditional_rule(sentence)
            if rule:
                graph["rules"].append(rule)

        graph["concepts"] = [
            {
                "id": "concept_" + hashlib.sha1(name.encode("utf-8")).hexdigest()[:10],
                "name": name,
                "definition": (
                    f"Concept extracted from the source material: {name}"
                    if english else f"材料原子事实中的概念：{name}"
                ),
                "aliases": [],
            }
            for name in dict.fromkeys(concept_names)
        ]
        for field in graph:
            graph[field] = self._deduplicate(graph[field])
        return graph

    @classmethod
    def atomic_content(cls, graph: dict[str, list[dict[str, Any]]]) -> str:
        facts = [item["description"] for item in graph.get("relations", [])]
        english = cls._is_english(" ".join(facts))
        if english:
            facts.extend(
                f"When {', '.join(item['conditions'])}, {item['action']}; the result is {item['result']}"
                for item in graph.get("rules", [])
            )
            return ". ".join(dict.fromkeys(facts)) + ("." if facts else "")
        facts.extend(
            f"在{'、'.join(item['conditions'])}时，{item['action']}，结果为{item['result']}"
            for item in graph.get("rules", [])
        )
        return "。".join(dict.fromkeys(facts)) + ("。" if facts else "")

    def local_teaching_package(self, document: dict[str, str], graph: dict | None = None) -> dict:
        english = self._is_english(document["content"])
        graph = graph or self.build_knowledge_graph(document["content"])
        names = [item["name"] for item in graph["concepts"]]
        relations = graph["relations"]
        title = names[0] if names else document["title"]
        atomic = self.atomic_content(graph) or document["content"].strip()
        answer = atomic
        return {
            "title": document["title"],
            "summary": atomic,
            "knowledge_points": [{
                "title": title,
                "concept": title,
                "content": atomic,
                "principle": atomic,
                "prerequisites": [],
                "key_understandings": [item["description"] for item in relations],
                "common_errors": [],
                "applications": [],
                "examples": [],
                **graph,
                "keywords": names or [title],
                "difficulty": "beginner",
                "importance": "high",
            }],
            "questions": [{
                "question": (
                    f"Explain the concepts and relationships involved in {title}."
                    if english else f"请说明{title}涉及的概念关系。"
                ),
                "topic": title,
                "answer": answer,
                "type": "understanding",
                "difficulty": "beginner",
                "required_knowledge": names or [title],
                "scoring_criteria": ([
                    "The answer must accurately reflect the factual relationships in the material"
                ] if english else ["回答必须符合材料中的原子关系"]),
                "common_wrong_answers": [],
            }],
            "source": {"title": document["title"], "url": document["url"]},
        }

    @staticmethod
    def _is_english(text: str) -> bool:
        return len(re.findall(r"[A-Za-z]", str(text))) > len(re.findall(r"[\u4e00-\u9fff]", str(text)))

    def merge_graph(self, local: dict, enhancement: dict) -> dict:
        return {
            field: self._deduplicate([*local.get(field, []), *enhancement.get(field, [])])
            for field in ("concepts", "attributes", "relations", "rules", "causal_links")
        }

    def _extract_relation(self, sentence: str) -> dict[str, str] | None:
        sentence = sentence.strip()
        english = self._extract_english_relation(sentence)
        if english:
            return english
        markers = "|".join(sorted((re.escape(item) for item in self.RELATIONS), key=len, reverse=True))
        match = re.match(rf"^(?P<left>.+?)(?P<marker>{markers})(?P<right>.+)$", sentence)
        if not match:
            return None
        source = self._clean_concept(match.group("left"))
        marker = match.group("marker")
        right = match.group("right").strip()
        relation = marker
        if marker in {"用于", "用来", "能够", "可以", "通过"}:
            action_match = re.match(
                rf"(?P<action>{'|'.join(sorted((re.escape(item) for item in self.ACTIONS), key=len, reverse=True))})(?P<target>.+)",
                right,
            )
            if action_match:
                relation = action_match.group("action")
                right = action_match.group("target")
        target = self._clean_concept(right)
        if not source or not target:
            return None
        return {"from": source, "relation": relation, "to": target}

    def _extract_english_relation(self, sentence: str) -> dict[str, str] | None:
        """Extract a conservative subject-relation-object fact from ordinary English prose."""
        if not re.search(r"[A-Za-z]", sentence):
            return None
        markers = "|".join(
            sorted((re.escape(item) for item in self.ENGLISH_RELATIONS), key=len, reverse=True)
        )
        match = re.match(
            rf"^(?P<left>.+?)\s+(?P<marker>{markers})\s+(?P<right>.+)$",
            sentence.strip(" .,:;\t\r\n"),
            flags=re.IGNORECASE,
        )
        if not match:
            return None
        source = self._clean_english_concept(match.group("left"))
        target = self._clean_english_concept(match.group("right"))
        relation = match.group("marker").lower()
        if not source or not target:
            return None
        return {"from": source, "relation": relation, "to": target}

    @staticmethod
    def _clean_english_concept(value: str) -> str:
        value = re.sub(r"\s+", " ", str(value)).strip(" .,:;()[]{}\t\r\n")
        value = re.sub(
            r"^(?:however|therefore|for example|in addition)\s*,?\s*",
            "",
            value,
            flags=re.IGNORECASE,
        )
        return value

    @staticmethod
    def _clean_concept(value: str) -> str:
        value = str(value).strip(" ，,。；;：:\t\r\n")
        value = re.sub(r"^(?:一个|一种|该|这个|这些)", "", value)
        value = value.replace("的需求", "需求").replace("的要求", "要求")
        value = re.sub(r"^(?:会|可|能)", "", value)
        return value.strip()

    @staticmethod
    def _derived_concepts(value: str) -> list[str]:
        result = []
        match = re.search(r"声明([A-Za-z0-9_\u4e00-\u9fff]+?)(?:需求|要求)?$", value)
        if match:
            result.append(match.group(1) + "声明")
        return result

    @staticmethod
    def _effect(relation: str, target: str) -> str:
        if relation in {"减少", "降低"}:
            return target + "减少"
        if relation in {"增加", "提高"}:
            return target + "增加"
        if relation in {"防止", "避免"}:
            return target + "不发生"
        return target

    def _conditional_rule(self, sentence: str) -> dict[str, Any] | None:
        match = re.match(r"(?:如果|当|在)(?P<condition>.+?)(?:时|，|,)(?P<result>.+)$", sentence)
        if not match:
            return None
        result = match.group("result").strip()
        relation = self._extract_relation(result)
        return {
            "conditions": [match.group("condition").strip()],
            "action": relation["relation"] if relation else result,
            "result": relation["to"] if relation else result,
        }

    @staticmethod
    def _deduplicate(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
        seen = set()
        result = []
        for item in items:
            signature = repr(sorted(item.items()))
            if signature not in seen:
                seen.add(signature)
                result.append(item)
        return result
