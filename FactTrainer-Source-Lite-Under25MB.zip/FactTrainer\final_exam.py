from typing import Any

from agent.agent import Agent
from training.evaluator import Evaluator


class FinalExam:
    def __init__(self, agent: Agent) -> None:
        self.agent = agent
        self.evaluator = Evaluator()

    def run(self) -> dict[str, Any]:
        results = []
        for item in self._questions_from_learned_knowledge():
            # The Agent must receive the real exam question, not only its topic label.
            answer = self.agent.answer_question(item["question"])
            evaluation = self.evaluator.evaluate(
                item["question"],
                item["expected_answer"],
                answer,
                item["keywords"],
                item["criteria"],
            )
            results.append(
                {
                    "topic": item["topic"],
                    "question": item["question"],
                    "answer": answer,
                    "score": evaluation["score"],
                }
            )

        final_score = (
            round(sum(item["score"] for item in results) / len(results))
            if results
            else 0
        )
        return {"score": final_score, "results": results}

    def _questions_from_learned_knowledge(self) -> list[dict[str, Any]]:
        """Build a fresh exam from the knowledge this Agent actually learned."""
        questions = []
        for topic in self.agent.learned_knowledge:
            knowledge = self.agent.knowledge_structures.get(topic, {})
            concept = str(knowledge.get("concept") or topic).strip()
            principle = str(
                knowledge.get("principle")
                or knowledge.get("mechanism")
                or knowledge.get("explanation")
                or knowledge.get("content")
                or self.agent.learned_knowledge.get(topic, "")
            ).strip()
            if not principle:
                continue
            applications = self._text_list(knowledge.get("applications"))
            criteria = {"concept": concept, "principle": principle}
            if applications:
                criteria["application"] = "；".join(applications)
                question = f"请解释{topic}的核心原理，并说明它在什么情境下可以应用。"
            else:
                question = f"请用自己的话解释{topic}，并说明其核心原理。"
            questions.append({
                "topic": topic,
                "question": question,
                "expected_answer": "。".join(criteria.values()),
                "keywords": self._text_list(knowledge.get("keywords")),
                "criteria": criteria,
            })
        return questions

    @staticmethod
    def _text_list(value: Any) -> list[str]:
        if isinstance(value, list):
            return [str(item).strip() for item in value if str(item).strip()]
        return [str(value).strip()] if value and str(value).strip() else []
