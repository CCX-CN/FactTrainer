import json
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen


class CloudKnowledgeClient:
    """优先读取知识 API，失败时使用本地基础库缓存。"""

    def __init__(
        self,
        api_url: str,
        fallback_dir: str | Path,
        cache_dir: str | Path,
    ) -> None:
        self.api_url = api_url.rstrip("/")
        self.fallback_dir = Path(fallback_dir)
        self.cache_dir = Path(cache_dir)

    def list_domains(self) -> list[str]:
        return self._request_json("/knowledge/list")

    def fetch_to_file(self, domain: str) -> Path:
        try:
            items = self._request_json(
                "/knowledge/query?" + urlencode({"domain": domain})
            )
            self._validate(items, domain)
            path = self.cache_dir / f"{self._safe_name(domain)}.json"
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(
                json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            return path
        except (OSError, ValueError, json.JSONDecodeError):
            fallback = self._find_fallback(domain)
            if fallback is None:
                raise
            return fallback

    def _request_json(self, endpoint: str):
        request = Request(
            self.api_url + endpoint,
            headers={"User-Agent": "FactTrainer/0.1"},
        )
        with urlopen(request, timeout=10) as response:
            return json.loads(response.read().decode("utf-8"))

    def _find_fallback(self, domain: str) -> Path | None:
        for path in self.fallback_dir.glob("*.json"):
            with path.open("r", encoding="utf-8") as file:
                items = json.load(file)
            if items and items[0].get("domain") == domain:
                return path
        return None

    @staticmethod
    def _validate(items, domain: str) -> None:
        required = {"domain", "topic", "content", "keywords", "level", "source"}
        if not isinstance(items, list) or not items:
            raise ValueError("知识 API 返回了空数据")
        if any(not isinstance(item, dict) or not required <= item.keys() for item in items):
            raise ValueError("知识 API 返回格式不兼容")
        if any(item["domain"] != domain for item in items):
            raise ValueError("知识 API 返回领域不匹配")

    @staticmethod
    def _safe_name(domain: str) -> str:
        aliases = {
            "Python": "python",
            "人工智能": "artificial_intelligence",
            "数学": "mathematics",
            "物理": "physics",
            "航天": "aerospace",
            "计算机基础": "computer_fundamentals",
        }
        return aliases.get(domain, "knowledge")
