import json
from pathlib import Path
from typing import Any


class KnowledgeBase:
    def __init__(self, file_path: str | Path) -> None:
        self.file_path = Path(file_path)
        self.knowledge: list[dict[str, Any]] = []

    def load(self) -> list[dict[str, Any]]:
        with self.file_path.open("r", encoding="utf-8") as file:
            data = json.load(file)

        if not isinstance(data, list):
            raise ValueError("知识库 JSON 顶层必须是列表")

        required_fields = {"topic", "content", "keywords"}
        for index, item in enumerate(data):
            if not isinstance(item, dict) or not required_fields.issubset(item):
                raise ValueError(f"第 {index + 1} 个知识点格式不正确")
            if not isinstance(item["keywords"], list):
                raise ValueError(f"第 {index + 1} 个知识点的 keywords 必须是列表")

        self.knowledge = data
        return self.knowledge

    def get_all(self) -> list[dict[str, Any]]:
        return self.knowledge

    def get_by_topic(self, topic: str) -> dict[str, Any] | None:
        return next(
            (item for item in self.knowledge if item["topic"] == topic),
            None,
        )
