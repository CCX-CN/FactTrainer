import json
import re
import time
from collections import Counter
from pathlib import Path
from urllib.error import URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from xml.etree import ElementTree


class KnowledgeLoader:
    """获取公开资料并转换为 Fact Trainer 兼容格式。"""

    USER_AGENT = "FactTrainer/0.1 (local knowledge training tool)"

    def load(self, domain: str, mode: str = "normal", limit: int = 10) -> list[dict]:
        domain = domain.strip()
        if not domain:
            raise ValueError("领域不能为空")
        if mode == "normal":
            documents, level = self._fetch_wikipedia(domain, limit), "basic"
        elif mode == "expert":
            documents, level = self._fetch_arxiv(domain, limit), "advanced"
        else:
            raise ValueError("mode 必须是 normal 或 expert")

        items = []
        for title, text in documents:
            content = self._clean_text(text)
            keywords = self._extract_keywords(content)
            if title.strip() and content and keywords:
                items.append({
                    "topic": title.strip(),
                    "content": content,
                    "keywords": keywords,
                    "level": level,
                })
        if not items:
            raise ValueError(f"没有获取到可转换的公开资料：{domain}")
        return items

    def load_bundle(self, domain: str, mode: str = "normal", limit: int = 10) -> dict:
        knowledge = self.load(domain, mode, limit)
        return {"knowledge": knowledge, "questions": self.generate_questions(knowledge)}

    @staticmethod
    def generate_questions(items: list[dict]) -> list[dict]:
        return [{
            "question": f"什么是{item['topic']}？",
            "expected_answer": item["content"],
            "keywords": item["keywords"],
        } for item in items]

    def save(self, items: list[dict], file_path: str | Path) -> Path:
        path = Path(file_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")
        return path

    def _request(self, url: str) -> bytes:
        last_error = None
        for attempt in range(3):
            try:
                request = Request(url, headers={"User-Agent": self.USER_AGENT})
                with urlopen(request, timeout=30) as response:
                    return response.read()
            except (OSError, URLError) as error:
                last_error = error
                if attempt < 2:
                    time.sleep(attempt + 1)
        raise ConnectionError(f"公开资料获取失败：{last_error}") from last_error

    def _fetch_wikipedia(self, domain: str, limit: int) -> list[tuple[str, str]]:
        params = {
            "action": "query", "format": "json", "formatversion": "2",
            "generator": "search", "gsrsearch": domain, "gsrlimit": limit,
            "prop": "extracts", "explaintext": "1", "exintro": "1",
        }
        errors = []
        for language in ("zh", "en"):
            try:
                url = f"https://{language}.wikipedia.org/w/api.php?" + urlencode(params)
                payload = json.loads(self._request(url).decode("utf-8"))
                pages = payload.get("query", {}).get("pages", [])
                documents = [(page["title"], page.get("extract", "")) for page in pages]
                if documents:
                    return documents
            except (ConnectionError, ValueError, KeyError) as error:
                errors.append(str(error))
        raise ConnectionError("Wikipedia 获取失败：" + "; ".join(errors))

    def _fetch_arxiv(self, domain: str, limit: int) -> list[tuple[str, str]]:
        params = {
            "search_query": f'all:"{domain}"', "start": 0,
            "max_results": limit, "sortBy": "relevance",
        }
        root = ElementTree.fromstring(
            self._request("https://export.arxiv.org/api/query?" + urlencode(params))
        )
        namespace = {"atom": "http://www.w3.org/2005/Atom"}
        return [
            (entry.findtext("atom:title", "", namespace),
             entry.findtext("atom:summary", "", namespace))
            for entry in root.findall("atom:entry", namespace)
        ]

    @staticmethod
    def _clean_text(text: str) -> str:
        return re.sub(r"\s+", " ", text).strip()[:1200]

    @staticmethod
    def _extract_keywords(text: str, count: int = 5) -> list[str]:
        stopwords = {
            "这个", "一种", "以及", "可以", "通过", "用于", "进行", "相关",
            "研究", "方法", "结果", "我们", "the", "and", "for", "with",
            "from", "that", "this", "are", "was", "using", "based",
        }
        tokens = re.findall(r"[\u4e00-\u9fff]{2,6}|[A-Za-z][A-Za-z0-9_-]{2,}", text)
        normalized = [token for token in tokens if token.casefold() not in stopwords]
        return [token for token, _ in Counter(normalized).most_common(count)]
