from pathlib import Path

from agent.agent import Agent
from final_exam import FinalExam
from knowledge.knowledge_base import KnowledgeBase
from questions.question_generator import QuestionGenerator
from reports.report import Report
from training.evaluator import Evaluator
from training.trainer import Trainer


def main() -> None:
    knowledge_file = Path(__file__).parent / "knowledge" / "python.json"
    knowledge_base = KnowledgeBase(knowledge_file)
    knowledge_base.load()

    agent = Agent(name="Python Expert", domain="Python")
    trainer = Trainer(
        agent=agent,
        knowledge_base=knowledge_base,
        question_generator=QuestionGenerator(knowledge_base),
        evaluator=Evaluator(),
    )

    print("=== 训练前 ===")
    print(f"Agent：{agent.name}")
    print(f"领域：{agent.domain}")
    print(f"等级：{agent.level}")
    print(f"分数：{agent.score}")

    result = trainer.train_once()

    print("\n=== 训练中 ===")
    for index, record in enumerate(result["records"], start=1):
        missing = "、".join(record["missing_keywords"]) or "无"
        print(f"{index}. {record['question']}")
        print(f"   首次回答：{record['answer_before']}")
        print(f"   首次得分：{record['score_before']}")
        print(f"   缺失知识：{missing}")
        print(f"   复测得分：{record['score_after']}")

    print("\n=== 训练后 ===")
    growth_report = Report.generate(agent, result)
    print(growth_report)

    exam_result = FinalExam(agent).run()
    print("\n=== 最终考试 ===")
    print(f"最终考试分数：{exam_result['score']}")


if __name__ == "__main__":
    main()
