import json
from pathlib import Path

from knowledge.knowledge_base import KnowledgeBase
from teacher.teacher_agent import TeacherAgent


class KnowledgePipeline:
    def __init__(self, teacher: TeacherAgent, output_dir: str | Path) -> None:
        self.teacher = teacher
        self.output_dir = Path(output_dir)

    def process(self, document: dict, domain: str) -> tuple[dict, KnowledgeBase]:
        knowledge_json = self.teacher.process(document)
        self.validate(knowledge_json)
        items = self.to_knowledge_items(knowledge_json, domain)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        output_path = self.output_dir / self._safe_name(domain)
        output_path.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")
        knowledge_base = KnowledgeBase(output_path)
        knowledge_base.load()
        return knowledge_json, knowledge_base

    @staticmethod
    def validate(data: dict) -> None:
        required = {"title", "summary", "knowledge_points", "questions", "source"}
        if not isinstance(data, dict) or not required <= data.keys():
            raise ValueError("Knowledge JSON 顶层字段不完整")
        if not isinstance(data["source"], dict) or not {"title", "url"} <= data["source"].keys():
            raise ValueError("Knowledge JSON 缺少有效来源")
        point_fields = {
            "title", "concept", "content", "principle", "prerequisites",
            "key_understandings", "common_errors", "applications", "examples",
            "concepts", "attributes", "relations", "rules", "causal_links",
            "keywords", "difficulty", "importance",
        }
        question_fields = {
            "question", "topic", "answer", "type", "difficulty",
            "required_knowledge", "scoring_criteria", "common_wrong_answers",
        }
        if not data["knowledge_points"] or any(point_fields - point.keys() for point in data["knowledge_points"]):
            raise ValueError("knowledge_points 格式不完整")
        if not data["questions"] or any(question_fields - question.keys() for question in data["questions"]):
            raise ValueError("questions 格式不完整")
        difficulties = {"beginner", "intermediate", "advanced"}
        importances = {"low", "medium", "high"}
        question_types = {"memory", "understanding", "application", "reasoning"}
        for point in data["knowledge_points"]:
            title = str(point["title"]).strip()
            if not title or "知识点" in title:
                raise ValueError("知识点必须使用真实概念名称")
            if point["difficulty"] not in difficulties or point["importance"] not in importances:
                raise ValueError("知识点难度或重要程度不合法")
            if not isinstance(point["keywords"], list) or not point["keywords"]:
                raise ValueError("知识点必须包含关键词")
            for field in (
                "prerequisites", "key_understandings", "common_errors", "applications",
                "examples", "concepts", "attributes", "relations", "rules", "causal_links",
            ):
                if not isinstance(point[field], list):
                    raise ValueError(f"知识点字段 {field} 必须是列表")
            graph_schemas = {
                "concepts": {"id", "name", "definition", "aliases"},
                "attributes": {"subject", "name", "value", "description"},
                "relations": {"source", "relation", "target", "description"},
                "rules": {"conditions", "action", "result"},
                "causal_links": {"cause", "effect", "conditions"},
            }
            for field, required_keys in graph_schemas.items():
                if any(not isinstance(item, dict) or required_keys - item.keys() for item in point[field]):
                    raise ValueError(f"知识图字段 {field} 格式不完整")
            if not point["concepts"] or not point["relations"]:
                raise ValueError("知识点必须包含本地拆解生成的 concepts 和 relations")
            if any(not isinstance(item["aliases"], list) for item in point["concepts"]):
                raise ValueError("concepts.aliases 必须是列表")
            if any(not isinstance(item["conditions"], list) for field in ("rules", "causal_links") for item in point[field]):
                raise ValueError("规则和因果关系的 conditions 必须是列表")
        for question in data["questions"]:
            if question["type"] not in question_types or question["difficulty"] not in difficulties:
                raise ValueError("题目类型或难度不合法")
            if not str(question["answer"]).strip():
                raise ValueError("题目必须包含完整答案")
            for field in ("required_knowledge", "scoring_criteria", "common_wrong_answers"):
                if not isinstance(question[field], list):
                    raise ValueError(f"题目字段 {field} 必须是列表")

    @staticmethod
    def to_knowledge_items(data: dict, domain: str) -> list[dict]:
        levels = {"beginner": "basic", "intermediate": "intermediate", "advanced": "advanced"}
        items = []
        for point in data["knowledge_points"]:
            difficulty = str(point["difficulty"]).strip().lower()
            title = str(point["title"]).strip()
            if not title or "知识点" in title:
                raise ValueError("知识点必须使用真实概念名称，禁止编号标题")
            related_questions = [
                question for question in data["questions"]
                if str(question.get("topic", "")).strip() == title
            ]
            items.append({
                "domain": domain,
                "topic": title,
                "concept": point["concept"],
                "content": point["content"],
                "explanation": point["content"],
                "principle": point["principle"],
                "prerequisites": point["prerequisites"],
                "key_understandings": point["key_understandings"],
                "common_errors": point["common_errors"],
                "applications": point["applications"],
                "examples": point["examples"],
                "concepts": point["concepts"],
                "attributes": point["attributes"],
                "relations": point["relations"],
                "rules": point["rules"],
                "causal_links": point["causal_links"],
                "keywords": point["keywords"],
                "level": levels.get(difficulty, difficulty if difficulty in levels.values() else "intermediate"),
                "source": data["source"]["url"],
                "training_questions": related_questions,
            })
        return items

    @staticmethod
    def _safe_name(domain: str) -> str:
        safe = "".join(character if character.isalnum() else "_" for character in domain).strip("_")
        return f"{safe or 'knowledge'}.json"
