from typing import Any

from knowledge.knowledge_base import KnowledgeBase


class QuestionGenerator:
    """Create four cognitive tasks from each structured knowledge point."""

    def __init__(self, knowledge_base: KnowledgeBase) -> None:
        self.knowledge_base = knowledge_base

    def generate(self) -> list[dict[str, Any]]:
        return [
            question
            for knowledge in self.knowledge_base.get_all()
            for question in self.generate_from_knowledge(knowledge)
        ]

    @staticmethod
    def generate_from_knowledge(knowledge: dict[str, Any]) -> list[dict[str, Any]]:
        topic = str(knowledge["topic"])
        concept = str(knowledge.get("concept") or topic)
        explanation = str(knowledge.get("explanation") or knowledge.get("content", ""))
        principle = str(knowledge.get("principle") or knowledge.get("mechanism") or explanation)
        applications = QuestionGenerator._list(knowledge.get("applications"))
        errors = QuestionGenerator._list(knowledge.get("common_errors"))
        result = str(knowledge.get("result") or "")
        application = "；".join(applications) or explanation
        common_error = "；".join(errors) or f"忽略{topic}的适用条件和核心原理"
        base = {
            "topic": topic,
            "level": knowledge.get("level", "basic"),
            "knowledge": knowledge,
        }
        generated = [
            {**base, "type": "memory", "question": f"请说明{topic}的核心概念。",
             "expected_answer": f"{concept}。{explanation}", "criteria": {"concept": concept}},
            {**base, "type": "understanding", "question": f"为什么{topic}会呈现材料所述的结果？请解释原理。",
             "expected_answer": f"{principle}。{result}", "criteria": {"principle": principle, "result": result}},
            {**base, "type": "application", "question": f"在一个新情境中应如何应用{topic}？说明依据。",
             "expected_answer": f"{application}。依据是：{principle}",
             "criteria": {"application": application, "principle": principle}},
            {**base, "type": "reasoning", "question": f"若改变{topic}成立的条件，结果可能怎样变化？请依据原理推理。",
             "expected_answer": f"应根据条件变化和{principle}推导；原结果为：{result or explanation}",
             "criteria": {"principle": principle, "result": result or explanation, "common_error": common_error}},
        ]
        teacher_questions = {
            str(item.get("type")): item
            for item in knowledge.get("training_questions", [])
            if isinstance(item, dict)
        }
        for task in generated:
            prepared = teacher_questions.get(task["type"])
            if not prepared:
                continue
            task["question"] = str(prepared.get("question") or task["question"])
            task["expected_answer"] = str(prepared.get("answer") or task["expected_answer"])
            required = prepared.get("required_knowledge", [])
            if isinstance(required, list) and required:
                task["criteria"] = {
                    f"required_{index + 1}": str(value)
                    for index, value in enumerate(required)
                    if str(value).strip()
                }
        return generated

    @staticmethod
    def _list(value: Any) -> list[str]:
        if isinstance(value, list):
            return [str(item) for item in value if str(item).strip()]
        return [str(value)] if value and str(value).strip() else []
