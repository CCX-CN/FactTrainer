from typing import Any

from agent.agent import Agent


class Report:
    @staticmethod
    def generate(agent: Agent, training_result: dict[str, Any]) -> str:
        level_names = {
            "basic": "基础",
            "intermediate": "进阶",
            "advanced": "高级",
        }
        level_rates = {}
        for level in level_names:
            scores = [
                int(item["score"])
                for item in agent.mastery.values()
                if item["level"] == level
            ]
            level_rates[level] = round(sum(scores) / len(scores)) if scores else 0

        if level_rates["advanced"] >= 80:
            ability_level = "高级专家"
        elif level_rates["intermediate"] >= 80:
            ability_level = "进阶"
        elif level_rates["basic"] >= 60:
            ability_level = "基础"
        else:
            ability_level = "入门"

        lines = [
            "=== Fact Trainer 成长报告 ===",
            f"Agent名称：{agent.name}",
            f"领域：{agent.domain}",
            f"训练前分数：{training_result['before_score']}",
            f"训练后分数：{training_result['after_score']}",
            f"分数变化：{training_result['after_score'] - training_result['before_score']:+d}",
            f"总体能力等级：{ability_level}",
            "各等级掌握率：",
            *[
                f"- {level_names[level]}：{level_rates[level]}%"
                for level in level_names
            ],
            "",
            "学习知识点：",
        ]

        learned_topics = list(agent.learned_knowledge)
        lines.extend(f"- {topic}" for topic in learned_topics)
        if not learned_topics:
            lines.append("- 无")

        lines.extend(["", "训练记录："])
        records = training_result.get("records", [])
        for index, record in enumerate(records, start=1):
            missing = "、".join(record["missing_keywords"]) or "无"
            lines.extend(
                [
                    f"{index}. 时间：{record['time']}",
                    f"   问题：{record['question']}",
                    f"   训练前回答：{record['answer_before']}",
                    f"   训练前得分：{record['score_before']}",
                    f"   缺失关键词：{missing}",
                    f"   训练后回答：{record['answer_after']}",
                    f"   训练后得分：{record['score_after']}",
                ]
            )
        if not records:
            lines.append("无训练记录")

        return "\n".join(lines)
