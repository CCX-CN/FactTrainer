import json
import re
from html import unescape
from urllib.parse import urlencode
from urllib.request import Request, urlopen


class SearchAgent:
    USER_AGENT = "FactTrainer/0.1"

    def search(self, query: str) -> list[dict]:
        params = {
            "action": "query", "format": "json", "formatversion": "2",
            "generator": "search", "gsrsearch": query, "gsrlimit": 3,
            "prop": "extracts|info", "explaintext": "1", "exintro": "1",
            "inprop": "url",
        }
        url = "https://zh.wikipedia.org/w/api.php?" + urlencode(params)
        payload = json.loads(self._request(url).decode("utf-8"))
        return [{
            "title": page["title"],
            "content": page.get("extract", ""),
            "url": page["fullurl"],
            "source": "Wikipedia",
        } for page in payload.get("query", {}).get("pages", []) if page.get("extract")]

    def fetch_url(self, url: str, title: str, source: str) -> dict:
        html = self._request(url).decode("utf-8", errors="replace")
        html = re.sub(r"<(script|style).*?</\1>", " ", html, flags=re.I | re.S)
        content = unescape(re.sub(r"<[^>]+>", " ", html))
        content = re.sub(r"\s+", " ", content).strip()
        if not content:
            raise ValueError("公开资料内容为空")
        return {"title": title, "content": content[:12000], "url": url, "source": source}

    def _request(self, url: str) -> bytes:
        request = Request(url, headers={"User-Agent": self.USER_AGENT})
        with urlopen(request, timeout=30) as response:
            return response.read()
