import json
from pathlib import Path


class StudentCapabilityEngine:
    """把持久化能力记忆编译为 Student 每次生成时执行的行为策略。"""

    def __init__(self, memory_path: str | Path) -> None:
        self.memory_path = Path(memory_path)
        self.memory: dict = {}
        self.refresh()

    def refresh(self) -> dict:
        self.memory = json.loads(self.memory_path.read_text(encoding="utf-8"))
        return self.memory

    def build_strategy(self) -> str:
        abilities = self.memory.get("abilities", {})
        rules = self.memory.get("learned_rules", [])
        methods = self.memory.get("teaching_methods", [])
        requirements: list[str] = []

        if abilities.get("knowledge_extraction", 0) > 0 or self._contains(rules, "知识点", "核心机制"):
            requirements.append(
                "每个知识点必须是对象，并包含 title、concept、mechanism、explanation、example；"
                "机制、解释和例子只能来自输入材料支持的内容。"
            )
        if abilities.get("knowledge_classification", 0) > 0:
            requirements.append(
                "把知识按前置概念、原理或应用复杂度放入 basic、intermediate、advanced，"
                "不得为了填满层级重复同一知识。"
            )
        if abilities.get("question_generation", 0) > 0 or self._contains(rules, "多角度", "多维度"):
            requirements.append(
                "问题必须覆盖至少三个角度：概念理解、原理分析、应用场景、错误分析中的三个；"
                "每题使用对象格式并包含 type、question、answer。"
            )
        if abilities.get("answer_evaluation", 0) > 0 or self._contains(rules, "评价", "评分"):
            requirements.append(
                "每道题必须提供完整 answer 和 evaluation_criteria；评价标准要列出必须命中的"
                "核心要点、常见遗漏或错误。evaluation_ability 要说明如何判分。"
            )
        if abilities.get("teaching_planning", 0) > 0:
            requirements.append("按基础概念到机制理解再到应用练习的顺序组织内容。")

        learned = [str(item).strip() for item in [*rules, *methods] if str(item).strip()]
        if learned:
            requirements.append("执行以下已学习规则和方法：\n- " + "\n- ".join(learned))

        if not requirements:
            return "当前尚无已迁移的教学策略；依据 Student Prompt 完成基础分析。"
        return (
            "以下是 Capability Engine 编译后的强制行为策略。它们只规定教学方法，"
            "不能作为输入材料之外的事实来源：\n- " + "\n- ".join(requirements)
        )

    def skill_config(self) -> dict:
        """把能力分数直接转换为本地 Skills 的运行参数。"""
        abilities = self.memory.get("abilities", {})
        rules = self.memory.get("learned_rules", [])
        methods = self.memory.get("teaching_methods", [])
        behavior_rules = self.memory.get("behavior_rules", {})
        question_rules = behavior_rules.get("question_generation_rules", [])
        knowledge_rules = behavior_rules.get("knowledge_extraction_rules", [])
        evaluation_rules = behavior_rules.get("answer_evaluation_rules", [])
        planning_rules = behavior_rules.get("teaching_planning_rules", [])
        all_behavior_rules = [
            str(rule)
            for category_rules in behavior_rules.values()
            for rule in category_rules
        ]
        professional_titles = self._contains(
            [*knowledge_rules, *all_behavior_rules],
            "专业概念名称", "概念名称", "专业术语", "名词性概念",
        )
        required_question_types: list[str] = []
        if self._contains(question_rules, "应用场景", "场景题", "场景分析"):
            required_question_types.append("应用场景")
        if self._contains(question_rules, "代码预测", "预测代码", "执行结果"):
            required_question_types.append("代码预测")
        if self._contains(question_rules, "比较题", "比较分析", "对比"):
            required_question_types.append("比较分析")
        if self._contains(question_rules, "错误分析", "常见错误"):
            required_question_types.append("错误分析")
        return {
            "max_knowledge_points": 3 + min(5, max(1, abilities.get("knowledge_extraction", 0) // 10)) if abilities.get("knowledge_extraction", 0) > 0 else 3,
            "include_mechanism": abilities.get("knowledge_extraction", 0) > 0 or bool(knowledge_rules),
            "include_examples": self._contains([*rules, *methods], "例", "模拟", "应用"),
            "question_angles": 4 if self._contains([*rules, *methods, *question_rules], "多角度", "多个角度", "概念理解") else 3 if self._contains(question_rules, "应用场景") else min(4, 1 + abilities.get("question_generation", 0) // 2),
            "detailed_evaluation": abilities.get("answer_evaluation", 0) > 0 or bool(evaluation_rules),
            "adaptive_planning": abilities.get("teaching_planning", 0) > 0 or bool(planning_rules),
            "professional_concept_titles": professional_titles,
            "required_question_types": required_question_types,
            "evaluation_rules": [str(rule) for rule in evaluation_rules],
        }

    @staticmethod
    def _contains(rules: list, *terms: str) -> bool:
        text = "\n".join(str(rule) for rule in rules)
        return any(term in text for term in terms)
