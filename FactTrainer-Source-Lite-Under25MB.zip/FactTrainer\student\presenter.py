class StudentPresenter:
    def render(self, result: dict) -> str:
        lines = [f"# {result.get('title', '学习内容')}", ""]
        if result.get("summary"):
            lines.extend(["## 内容总结", "", str(result["summary"]), ""])
        lines.extend(["## 知识解释", ""])
        for index, point in enumerate(result.get("knowledge_points", []), 1):
            if isinstance(point, dict):
                title = point.get("title") or point.get("concept") or f"概念 {index}"
                lines.append(f"### {title}")
                for label, field in (
                    ("概念", "concept"), ("核心机制", "mechanism"),
                    ("解释", "explanation"), ("例子", "example"),
                ):
                    value = point.get(field)
                    if value:
                        lines.append(f"{label}：{value}")
                lines.append("")
            else:
                lines.extend([f"### 知识点 {index}", str(point), ""])

        lines.extend(["## 练习题", ""])
        for index, question in enumerate(result.get("questions", []), 1):
            if isinstance(question, dict):
                text = question.get("question") or question.get("content") or ""
                lines.append(f"{index}. [{question.get('type', '练习')}] {text}")
                if question.get("answer"):
                    lines.append(f"   答案解析：{question['answer']}")
                if question.get("evaluation_criteria"):
                    lines.append(f"   评价标准：{question['evaluation_criteria']}")
            else:
                lines.append(f"{index}. {question}")

        ability = result.get("evaluation_ability")
        if ability:
            lines.extend(["", "## 答案评价能力", "", str(ability)])
        return "\n".join(lines).strip()
