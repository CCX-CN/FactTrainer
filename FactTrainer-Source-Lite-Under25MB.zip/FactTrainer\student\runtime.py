import json
from pathlib import Path

from student.capability_engine import StudentCapabilityEngine
from student.presenter import StudentPresenter
from student.skills.difficulty_skill import DifficultySkill
from student.skills.evaluation_skill import EvaluationSkill
from student.skills.knowledge_skill import KnowledgeSkill
from student.skills.question_skill import QuestionSkill
from student.skills.student_evaluation_skill import StudentEvaluationSkill
from student.skills.teaching_skill import TeachingSkill


class StudentRuntime:
    """部署阶段的纯本地 Student 运行时；不包含任何模型或网络依赖。"""

    def __init__(self, memory_path: str | Path | None = None) -> None:
        path = Path(memory_path) if memory_path else Path(__file__).with_name("capability_memory.json")
        self.capability_engine = StudentCapabilityEngine(path)
        self.knowledge_skill = KnowledgeSkill()
        self.difficulty_skill = DifficultySkill()
        self.question_skill = QuestionSkill()
        self.student_evaluation_skill = StudentEvaluationSkill()
        self.evaluation_skill = EvaluationSkill()
        self.teaching_skill = TeachingSkill()
        self.presenter = StudentPresenter()

    def process(self, material: str | dict) -> dict:
        text = self._material_text(material)
        config = self.capability_engine.skill_config()
        points = self.knowledge_skill.analyze(text, config)
        levels = self.difficulty_skill.classify(points, config)
        questions = self.question_skill.generate(points, config)
        result = {
            "summary": "".join(point["explanation"] for point in points),
            "knowledge_points": points,
            "difficulty_levels": levels,
            "questions": questions,
            "evaluation_ability": self.evaluation_skill.describe(config),
            "teaching_plan": self.teaching_skill.plan(levels, config),
        }
        return result

    def teach(self, material: str | dict) -> str:
        return self.presenter.render(self.process(material))

    def evaluate_student(self, knowledge_point: dict, student_answer: str) -> dict:
        return self.student_evaluation_skill.evaluate(knowledge_point, student_answer)

    @staticmethod
    def _material_text(material: str | dict) -> str:
        if isinstance(material, str):
            text = material.strip()
        elif isinstance(material, dict):
            text = str(material.get("content", "")).strip()
        else:
            raise TypeError("输入资料必须是字符串或对象")
        if not text:
            raise ValueError("输入资料不能为空")
        return text
