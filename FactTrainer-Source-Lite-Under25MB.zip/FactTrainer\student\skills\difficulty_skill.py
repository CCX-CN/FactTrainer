class DifficultySkill:
    def classify(self, points: list[dict], config: dict) -> dict[str, list]:
        levels = {"basic": [], "intermediate": [], "advanced": []}
        count = len(points)
        for index, point in enumerate(points):
            text = point["explanation"]
            relative_level = (
                "basic" if index < count / 3 else
                "intermediate" if index < count * 2 / 3 else "advanced"
            )
            if relative_level == "advanced" or any(term in text for term in ("底层", "综合", "传播", "协议", "机制")):
                level = "advanced"
            elif any(term in text for term in ("因此", "如果", "当", "调用", "应用")):
                level = "intermediate"
            else:
                level = relative_level
            point["difficulty"] = level
            levels[level].append(point["title"])
        return levels
