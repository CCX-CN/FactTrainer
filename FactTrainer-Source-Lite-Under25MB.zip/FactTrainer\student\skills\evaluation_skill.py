class EvaluationSkill:
    def describe(self, config: dict) -> str:
        rules = config.get("evaluation_rules", [])
        if rules:
            return "按关键词、核心机制和应用逻辑检查答案，并执行：" + "；".join(rules)
        if config["detailed_evaluation"]:
            return "按必需关键词、核心机制和应用逻辑分项检查；指出正确内容、遗漏要点与错误理解。"
        return "检查答案是否覆盖材料中的核心关键词。"

    def evaluate_answer(self, answer: str, criteria: dict) -> dict:
        keywords = criteria.get("required_keywords", [])
        missing = [keyword for keyword in keywords if keyword.casefold() not in answer.casefold()]
        score = round((len(keywords) - len(missing)) / len(keywords) * 100) if keywords else 100
        return {"score": score, "missing": missing, "understood": score >= 70}
