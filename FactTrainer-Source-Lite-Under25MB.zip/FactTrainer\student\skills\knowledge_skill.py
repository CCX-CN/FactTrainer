import re
from collections import Counter


class KnowledgeSkill:
    STOPWORDS = {"用于", "以及", "一个", "可以", "需要", "进行", "其中", "因此", "如果", "当", "通过"}

    def analyze(self, text: str, config: dict) -> list[dict]:
        sentences = [item.strip() for item in re.split(r"(?<=[。！？；])", text) if len(item.strip()) >= 2]
        if not sentences:
            raise ValueError("输入材料没有可提取的有效知识")

        # 当前输入被视为一份完整材料；相邻句共同描述同一知识关系，不再逐句制造知识点。
        material = "".join(sentences)
        keywords = self._keywords(material)
        relation_type = self._relation_type(material)
        title = self._title(material, relation_type)
        structure = self._structure(material, title, relation_type, keywords)
        point = {
            "title": title,
            "concept": title,
            "relation_type": relation_type,
            "components": structure["components"],
            "conditions": structure["conditions"],
            "process": structure["process"],
            "result": structure["result"],
            "common_errors": structure["common_errors"],
            "applications": structure["applications"],
            "mechanism": structure["mechanism"],
            "explanation": material,
            "example": self._example(material) if config["include_examples"] else "",
            "keywords": keywords,
        }
        return [point]

    @staticmethod
    def _relation_type(text: str) -> str:
        rules = (
            ("因果", ("因为", "由于", "导致", "使得", "所以", "因此", "从而")),
            ("流程", ("首先", "然后", "接着", "随后", "最后", "进入", "离开", "恢复", "阶段", "步骤")),
            ("推导", ("等于", "公式", "推出", "推导", "定律", "正比", "反比", "比例", "若", "则")),
            ("分类", ("分为", "包括", "包含", "属于", "类型", "类别")),
            ("演化", ("演化", "逐渐", "生长", "发育", "转化", "变化", "积累", "循环")),
        )
        scores = [(name, sum(text.count(term) for term in terms)) for name, terms in rules]
        name, score = max(scores, key=lambda item: item[1])
        return name if score else "关联"

    @staticmethod
    def _title(text: str, relation_type: str) -> str:
        compact = text.strip("。！？； ")
        if len(compact) <= 18 and "。" not in compact:
            return compact

        if relation_type == "因果":
            outcomes = re.findall(r"(?:导致|形成|产生|成为)([^，。；]{2,18})", compact)
            if outcomes:
                outcome = re.sub(r"^(了|的)", "", outcomes[-1]).strip()
                return outcome if outcome.endswith(("过程", "现象", "效应", "关系")) else outcome + "因果关系"

        first_clause = re.split(r"[，。；]", compact, maxsplit=1)[0].strip()
        match = re.match(
            r"(?:Python\s*)?(.{2,22}?)(?:是|指|表示|描述|说明|使用|通过|会|将|可|分为|包括|产生|等于|与)",
            first_clause,
            flags=re.I,
        )
        concept = match.group(1).strip() if match else first_clause[:18].strip()
        concept = re.sub(r"^(这种|该|这个|一种)", "", concept).strip()
        suffixes = {"因果": "因果关系", "流程": "过程", "推导": "关系", "分类": "分类", "演化": "演化", "关联": "结构"}
        suffix = suffixes[relation_type]
        return concept if concept.endswith(("定律", "定理", "过程", "关系", "分类", "结构", "机制")) else concept + suffix

    def _structure(self, text: str, title: str, relation_type: str, keywords: list[str]) -> dict:
        clauses = [item.strip() for item in re.split(r"[。！？；，]", text) if item.strip()]
        components = self._components(text, keywords)
        conditions = self._conditions(clauses, title, relation_type)
        process = self._process(clauses, components, relation_type)
        result = self._result(clauses, title, relation_type)
        common_errors = self._errors(components, relation_type)
        applications = self._applications(title, components, relation_type)
        mechanism = f"关系类型：{relation_type}；条件：{'；'.join(conditions)}；过程：{'；'.join(process)}；结果：{result}"
        return {
            "components": components,
            "conditions": conditions,
            "process": process,
            "result": result,
            "common_errors": common_errors,
            "applications": applications,
            "mechanism": mechanism,
        }

    @staticmethod
    def _conditions(clauses: list[str], title: str, relation_type: str) -> list[str]:
        marked = [clause for clause in clauses if re.search(r"当|如果|若|在.+时|只有|前提|由于|因为", clause)]
        if marked:
            return marked[:2]
        descriptions = {
            "因果": f"{title}中的原因要素成立",
            "流程": f"{title}的起始状态出现",
            "推导": f"{title}给出的已知关系成立",
            "分类": f"采用{title}所依据的分类标准",
            "演化": f"{title}所描述的初始状态和变化环境成立",
            "关联": f"{title}涉及的要素同时存在",
        }
        return [descriptions[relation_type]]

    @staticmethod
    def _process(clauses: list[str], components: list[str], relation_type: str) -> list[str]:
        joined_components = "、".join(components[:4])
        if relation_type == "因果":
            cause = next((c for c in clauses if "因为" in c or "由于" in c), clauses[0])
            effect = next((c for c in clauses if re.search(r"导致|使得|所以|因此|从而", c)), clauses[-1])
            return [f"原因要素形成：{cause}", f"原因作用于{joined_components}", f"影响表现为：{effect}"]
        if relation_type == "流程":
            return [f"阶段{index}：{clause}" for index, clause in enumerate(clauses[:5], 1)]
        if relation_type == "推导":
            relation = next((c for c in clauses if re.search(r"等于|正比|反比|比例|公式|则", c)), clauses[-1])
            return [f"确定关系要素：{joined_components}", f"采用材料关系：{relation}", "由已知关系推出目标量或结论"]
        if relation_type == "分类":
            category = next((c for c in clauses if re.search(r"分为|包括|包含|属于", c)), clauses[-1])
            return [f"确定分类对象：{components[0]}", f"采用材料给出的划分：{category}", "比较各类别的共同点与区别"]
        if relation_type == "演化":
            return [f"变化阶段{index}：{clause}" for index, clause in enumerate(clauses[:5], 1)]
        return [f"确定核心要素：{joined_components}", *[f"分析关系：{clause}" for clause in clauses[:3]]]

    @staticmethod
    def _result(clauses: list[str], title: str, relation_type: str) -> str:
        if relation_type in ("流程", "演化"):
            return clauses[-1]
        if relation_type == "推导":
            related = [c for c in clauses if re.search(r"等于|正比|反比|比例|公式|则", c)]
            return "；".join(related) if related else "由材料关系可推出：" + clauses[-1]
        marked = [c for c in clauses if re.search(r"导致|使得|所以|因此|从而|得到|结果|成为|产生", c)]
        if marked:
            return marked[-1]
        prefixes = {"推导": "由材料关系可推出：", "分类": "材料形成的分类结论是：", "流程": "过程完成后的状态是：", "演化": "变化后的状态是：", "因果": "原因作用后的结果是：", "关联": "材料说明的关系是："}
        return prefixes[relation_type] + clauses[-1]

    @staticmethod
    def _errors(components: list[str], relation_type: str) -> list[str]:
        joined = "、".join(components[:3])
        messages = {
            "因果": f"混淆{joined}之间的原因与结果",
            "流程": f"颠倒{joined}相关阶段的先后顺序",
            "推导": f"忽略{joined}之间关系成立的前提",
            "分类": f"混用{joined}的分类标准",
            "演化": f"遗漏{joined}变化中的中间阶段",
            "关联": f"把{joined}之间的关联误认为彼此等同",
        }
        return [messages[relation_type]]

    @staticmethod
    def _applications(title: str, components: list[str], relation_type: str) -> list[str]:
        joined = "、".join(components[:3])
        actions = {"因果": "解释现象产生的原因", "流程": "判断各阶段的先后状态", "推导": "根据已知关系求得未知结论", "分类": "按统一标准识别类别", "演化": "预测状态随阶段如何变化", "关联": "分析要素之间如何相互联系"}
        return [f"在涉及{joined}的情境中，运用{title}{actions[relation_type]}"]

    @staticmethod
    def _components(text: str, keywords: list[str]) -> list[str]:
        symbols = re.findall(r"__[A-Za-z]+__|[A-Za-z_][A-Za-z0-9_]*|[A-Z]\s*=\s*[A-Za-z0-9*/+\-]+", text)
        values = list(dict.fromkeys([*symbols, *keywords]))
        return values[:6] or ["核心要素"]

    def _keywords(self, text: str) -> list[str]:
        tokens = re.findall(r"[A-Za-z_][A-Za-z0-9_]*|[\u4e00-\u9fff]{2,8}", text)
        filtered = [token for token in tokens if token not in self.STOPWORDS]
        return [token for token, _ in Counter(filtered).most_common(6)]

    @staticmethod
    def _example(text: str) -> str:
        symbols = re.findall(r"__[A-Za-z]+__|[A-Za-z_][A-Za-z0-9_]*\(\)|[A-Z]\s*=\s*[A-Za-z0-9*/+\-]+", text)
        return f"材料中的关系形式：{'、'.join(symbols)}" if symbols else ""
