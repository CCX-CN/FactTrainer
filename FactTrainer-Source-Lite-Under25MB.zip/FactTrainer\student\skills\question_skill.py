class QuestionSkill:
    TASKS = ("概念理解", "机制推理", "情境应用", "结果预测", "错误诊断")

    def generate(self, points: list[dict], config: dict) -> list[dict]:
        count = max(1, min(len(self.TASKS), config.get("question_angles", 1)))
        selected = list(self.TASKS[:count])
        if config.get("required_question_types"):
            selected = list(self.TASKS)

        questions = []
        for point in points:
            for task in selected:
                questions.append({
                    "type": task,
                    "question": self._question(task, point),
                    "answer": self._answer(task, point),
                    "evaluation_criteria": {
                        "required_keywords": point["keywords"],
                        "must_explain_mechanism": task != "概念理解",
                    },
                    "difficulty": point.get("difficulty", "basic"),
                })
        return questions

    @staticmethod
    def _question(task: str, point: dict) -> str:
        title = point["title"]
        conditions = "；".join(point["conditions"])
        result = point["result"]
        application = point["applications"][0]
        error = point["common_errors"][0]
        questions = {
            "概念理解": f"{title}是什么？它包含哪些核心要素和关系？",
            "机制推理": f"在“{conditions}”的前提下，为什么会得到“{result}”？",
            "情境应用": f"面对以下情境，应如何运用{title}：{application}？",
            "结果预测": f"如果“{conditions}”中的关键条件发生变化，结果可能怎样变化？请说明依据。",
            "错误诊断": f"有人认为“{error}”不会影响结论。这一理解错在哪里，应如何修正？",
        }
        return questions[task]

    @staticmethod
    def _answer(task: str, point: dict) -> str:
        title = point["title"]
        components = "、".join(point["components"])
        conditions = "；".join(point["conditions"])
        process = "；".join(point["process"])
        result = point["result"]
        application = point["applications"][0]
        error = point["common_errors"][0]
        answers = {
            "概念理解": f"{title}描述{components}之间的{point['relation_type']}关系。核心结论：{result}。",
            "机制推理": f"成立条件：{conditions}。关系过程：{process}。因此：{result}。",
            "情境应用": f"情境：{application}。分析时先确认{conditions}，再依据以下关系处理：{process}。结论应符合：{result}。",
            "结果预测": f"原有条件是：{conditions}。条件变化会沿着“{process}”所描述的关系影响结果；预测时应比较变化前后各要素，并以“{result}”作为原关系基准。",
            "错误诊断": f"错误理解：{error}。它破坏了以下关系：{process}。修正方法：恢复正确条件“{conditions}”，并检查结论是否符合“{result}”。",
        }
        return answers[task]
