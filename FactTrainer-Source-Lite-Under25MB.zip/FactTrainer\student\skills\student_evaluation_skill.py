import re


class StudentEvaluationSkill:
    """离线分析学生回答中的关系理解、概念混淆与推理完整性。"""

    def evaluate(self, knowledge_point: dict, student_answer: str) -> dict:
        answer = student_answer.strip()
        if not answer:
            raise ValueError("学生回答不能为空")

        relations = self._relations(knowledge_point)
        misconceptions: list[str] = []
        missing: list[str] = []
        supported = 0

        for left, right, relation in relations:
            judgment = self._judge_relation(answer, left, right, relation)
            if judgment == "contradicted":
                misconceptions.append(f"错误理解{left}与{right}的{relation}关系")
            elif judgment == "supported":
                supported += 1
            else:
                missing.append(f"未说明{left}与{right}的{relation}关系")

        confused = self._concept_confusions(answer, knowledge_point, relations)
        misconceptions.extend(confused)
        misconceptions = list(dict.fromkeys(misconceptions))

        has_reasoning = bool(re.search(r"因为|由于|所以|因此|意味着|从而|原因|依据", answer))
        mechanism_terms = self._mechanism_terms(knowledge_point)
        explained_terms = [term for term in mechanism_terms if term in answer]
        if not has_reasoning:
            missing.append("缺少从条件到结果的原因解释")
        elif not explained_terms and relations:
            missing.append("给出了理由，但没有使用当前知识中的关系说明因果过程")

        missing = list(dict.fromkeys(missing))
        if misconceptions:
            level = "wrong"
        elif relations and supported == len(relations) and has_reasoning:
            level = "correct"
        else:
            level = "partial"

        reasoning = self._reasoning_analysis(
            has_reasoning, supported, len(relations), misconceptions, explained_terms
        )
        strategy = self._teaching_strategy(knowledge_point, misconceptions, missing)
        next_question = self._next_question(knowledge_point, relations, misconceptions)
        return {
            "understanding_level": level,
            "misconceptions": misconceptions,
            "missing_knowledge": missing,
            "reasoning_analysis": reasoning,
            "teaching_strategy": strategy,
            "next_question": next_question,
        }

    @staticmethod
    def _relations(point: dict) -> list[tuple[str, str, str]]:
        text = "；".join([point.get("result", ""), point.get("mechanism", "")])
        relations: list[tuple[str, str, str]] = []
        current_left = ""
        for clause in re.split(r"[，；。]", text):
            match = re.search(r"(.+?)与(.+?)(?:成)?(正比|反比)", clause)
            if match:
                current_left = StudentEvaluationSkill._clean_relation_term(match.group(1))
                right = StudentEvaluationSkill._clean_relation_term(match.group(2))
                relations.append((current_left, right, match.group(3)))
                continue
            match = re.search(r"与([\u4e00-\u9fff]{1,8})(?:成)?(正比|反比)", clause)
            if match and current_left:
                relations.append((current_left, StudentEvaluationSkill._clean_relation_term(match.group(1)), match.group(2)))
        return list(dict.fromkeys(relations))

    @staticmethod
    def _clean_relation_term(term: str) -> str:
        value = re.sub(r"^.*(?:说明|指出|表明|表示|认为)", "", term).strip()
        value = re.sub(r"^(物体|所受|这个|该)", "", value).strip()
        value = re.sub(r"(成|的)$", "", value).strip()
        return value[-6:]

    @staticmethod
    def _judge_relation(answer: str, left: str, right: str, relation: str) -> str:
        left_term = left[-4:]
        right_term = right[-4:]
        both_present = left_term in answer and right_term in answer
        if not both_present:
            return "missing"

        explicit = re.search(
            rf"{re.escape(left_term)}.*?(正比|反比)|{re.escape(right_term)}.*?{re.escape(left_term)}.*?(正比|反比)",
            answer,
        )
        if explicit:
            stated = explicit.group(1) or explicit.group(2)
            return "supported" if stated == relation else "contradicted"

        right_bigger = re.search(rf"{re.escape(right_term)}[^。；]{{0,12}}越大", answer)
        left_bigger = re.search(rf"{re.escape(left_term)}[^。；]{{0,12}}越大", answer)
        left_smaller = re.search(rf"{re.escape(left_term)}[^。；]{{0,12}}越小", answer)
        if right_bigger and (left_bigger or left_smaller):
            stated = "正比" if left_bigger else "反比"
            return "supported" if stated == relation else "contradicted"
        return "missing"

    @staticmethod
    def _concept_confusions(answer: str, point: dict, relations: list[tuple[str, str, str]]) -> list[str]:
        terms = set()
        for left, right, _ in relations:
            terms.update((left[-4:], right[-4:]))
        terms.update(str(item) for item in point.get("components", []) if 1 < len(str(item)) <= 8)
        terms.update("力" for term in list(terms) if term.endswith("力"))
        confusions = []
        for match in re.finditer(r"([\u4e00-\u9fff]{1,8})(?:就是|等于|代表)([\u4e00-\u9fff]{1,8})", answer):
            left_phrase, right_phrase = match.groups()
            left_terms = sorted((term for term in terms if term in left_phrase), key=len, reverse=True)
            right_terms = sorted((term for term in terms if term in right_phrase), key=len, reverse=True)
            if left_terms and right_terms and left_terms[0] != right_terms[0]:
                confusions.append(f"混淆{left_terms[0]}和{right_terms[0]}的概念")
        return confusions

    @staticmethod
    def _mechanism_terms(point: dict) -> list[str]:
        values = [*point.get("conditions", []), *point.get("process", []), point.get("result", "")]
        terms = re.findall(r"[\u4e00-\u9fff]{2,6}|[A-Za-z][A-Za-z0-9_=]*", "；".join(values))
        return list(dict.fromkeys(terms))

    @staticmethod
    def _reasoning_analysis(
        has_reasoning: bool,
        supported: int,
        relation_count: int,
        misconceptions: list[str],
        explained_terms: list[str],
    ) -> str:
        if misconceptions:
            return "回答尝试给出原因，但推理建立在错误的概念或关系上：" + "；".join(misconceptions)
        if not has_reasoning:
            return "回答主要陈述结论，没有说明条件如何通过核心关系产生结果，表现为记忆答案而非机制理解。"
        if relation_count and supported < relation_count:
            return f"回答包含推理表达，但只正确说明了{supported}/{relation_count}项核心关系，因果链仍不完整。"
        return "回答能够从条件说明关系，并用核心机制推出结果。涉及的机制要素：" + "、".join(explained_terms[:5])

    @staticmethod
    def _teaching_strategy(point: dict, misconceptions: list[str], missing: list[str]) -> str:
        if misconceptions:
            return f"先用对比示例澄清“{'；'.join(misconceptions)}”，再依据“{point.get('result', '')}”逐步重建正确关系。"
        if missing:
            return f"围绕缺失内容“{'；'.join(missing)}”追问条件、关系和结果，并让学生用自己的话复述{point['title']}的机制。"
        return f"学生已理解{point['title']}，下一步用条件变化题检查能否迁移应用。"

    @staticmethod
    def _next_question(
        point: dict,
        relations: list[tuple[str, str, str]],
        misconceptions: list[str],
    ) -> str:
        if relations:
            left, right, relation = relations[-1]
            direction = "怎样变化" if relation == "正比" else "怎样变化（注意关系方向）"
            return f"保持其他条件不变，将{right}增大时，{left}会{direction}？请依据{relation}关系解释。"
        application = (point.get("applications") or [f"应用{point['title']}"])[0]
        focus = "修正刚才的错误理解后，" if misconceptions else ""
        return f"{focus}在“{application}”情境中，哪些条件会影响结果？请说明推理过程。"
