class TeachingSkill:
    def plan(self, levels: dict, config: dict) -> list[dict]:
        labels = {"basic": "基础概念", "intermediate": "原理与关系", "advanced": "综合应用"}
        plan = []
        for level in ("basic", "intermediate", "advanced"):
            if levels[level]:
                plan.append({
                    "stage": labels[level],
                    "topics": levels[level],
                    "method": "解释后练习并按评价标准检查" if config["adaptive_planning"] else "依次学习",
                })
        return plan
