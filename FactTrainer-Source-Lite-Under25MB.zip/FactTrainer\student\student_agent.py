import json
from pathlib import Path

from student.runtime import StudentRuntime


class StudentAgent:
    """训练阶段的 Student 外壳；教学决策全部由本地 StudentRuntime 完成。"""

    ABILITY_TERMS = {
        "knowledge_extraction": ("知识", "概念", "提取", "机制", "总结"),
        "knowledge_classification": ("分层", "难度", "基础", "进阶", "高级"),
        "question_generation": ("问题", "题目", "提问", "角度"),
        "answer_evaluation": ("评价", "答案", "评分", "遗漏", "错误"),
        "teaching_planning": ("教学", "顺序", "计划", "下一步", "调整"),
    }

    def __init__(self, memory_path: str | Path | None = None, **_unused) -> None:
        self.memory_path = (
            Path(memory_path) if memory_path else Path(__file__).with_name("capability_memory.json")
        )
        self.runtime = StudentRuntime(self.memory_path)
        self.capability_engine = self.runtime.capability_engine
        self.capability_memory = self.capability_engine.memory

    def process(self, material: str | dict) -> dict:
        return self.runtime.process(material)

    def evaluate_student(self, knowledge_point: dict, student_answer: str) -> dict:
        return self.runtime.evaluate_student(knowledge_point, student_answer)

    def learn_from_feedback(
        self,
        material: str | dict,
        before_output: dict,
        after_output: dict,
        feedback: dict,
        after_feedback: dict,
        behavior_rules: dict | None = None,
    ) -> dict:
        del material, before_output, after_output
        feedback_items = [
            str(item).strip()
            for field in ("weaknesses", "improvement")
            for item in feedback.get(field, [])
            if str(item).strip()
        ]
        text = "\n".join(feedback_items)
        score_gain = max(0, round(after_feedback.get("score", 0) - feedback.get("score", 0)))
        step = min(10, max(1, score_gain // 10 + 1))
        improvements = {
            ability: step if any(term in text for term in terms) else 0
            for ability, terms in self.ABILITY_TERMS.items()
        }
        learned_rules = list(dict.fromkeys(feedback_items))
        new_methods = [item for item in learned_rules if "方法" in item or "步骤" in item or "策略" in item]
        reflection = {
            "learned_rules": learned_rules,
            "ability_improvements": improvements,
            "new_methods": new_methods,
            "behavior_rules": behavior_rules or {},
        }
        self._update_memory(reflection)
        return reflection

    def _update_memory(self, reflection: dict) -> None:
        memory = self.capability_memory
        for ability, increase in reflection["ability_improvements"].items():
            memory["abilities"][ability] = min(100, memory["abilities"][ability] + increase)
        for rule in reflection["learned_rules"]:
            if rule not in memory["learned_rules"]:
                memory["learned_rules"].append(rule)
        memory.setdefault("teaching_methods", [])
        for method in reflection["new_methods"]:
            if method not in memory["teaching_methods"]:
                memory["teaching_methods"].append(method)
        memory.setdefault("behavior_rules", {})
        for category, rules in reflection.get("behavior_rules", {}).items():
            saved = memory["behavior_rules"].setdefault(category, [])
            for rule in rules:
                if rule not in saved:
                    saved.append(rule)
        temporary = self.memory_path.with_suffix(".tmp")
        temporary.write_text(json.dumps(memory, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.replace(self.memory_path)
        self.capability_memory = self.capability_engine.refresh()
