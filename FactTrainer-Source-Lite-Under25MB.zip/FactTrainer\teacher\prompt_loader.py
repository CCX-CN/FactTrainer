import sys
from pathlib import Path


def load_teacher_prompt(path: str | Path | None = None) -> str:
    if path:
        candidates = [Path(path)]
    elif getattr(sys, "frozen", False):
        bundle_root = Path(sys._MEIPASS)
        candidates = [
            bundle_root / "FactTrainer" / "prompts" / "teacher_prompt.txt",
            bundle_root / "prompts" / "teacher_prompt.txt",
        ]
    else:
        candidates = [Path(__file__).resolve().parents[1] / "prompts" / "teacher_prompt.txt"]
    prompt_path = next((candidate for candidate in candidates if candidate.is_file()), None)
    if prompt_path is None:
        searched = ", ".join(str(candidate) for candidate in candidates)
        raise FileNotFoundError(f"Teacher Prompt 未打包或不存在；已检查：{searched}")
    prompt = prompt_path.read_text(encoding="utf-8").strip()
    if not prompt:
        raise ValueError("AI 教师 Prompt 不能为空")
    return prompt
