import json
import os
import re
from datetime import datetime
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen

from core.knowledge_parser import LocalKnowledgeParser
from search.search_agent import SearchAgent
from teacher.prompt_loader import load_teacher_prompt


class TeacherAgent:
    MAX_ACTIVE_RULES = 30
    MAX_PENDING_RULES = 100
    PROMOTION_MIN_OCCURRENCES = 2
    PROMOTION_MIN_CONFIDENCE = 0.7
    def __init__(
        self,
        api_key: str | None = None,
        model: str = "gemini-3-flash-preview",
        memory_path: str | Path | None = None,
    ) -> None:
        self.api_key = str(api_key or os.environ.get("GEMINI_API_KEY") or "").strip()
        self.model = model
        self.prompt = load_teacher_prompt()
        self.knowledge_parser = LocalKnowledgeParser()
        self.memory_path = (
            Path(memory_path)
            if memory_path
            else Path(__file__).with_name("teacher_memory.json")
        )
        self.memory = self._load_memory()

    def _load_memory(self) -> dict:
        default = {
            "active_rules": [],
            "pending_rules": [],
            "rejected_rules": [],
            "teaching_rules": [],
            "evaluation_rules": [],
            "common_error_patterns": [],
            "question_rules": [],
        }
        if not self.memory_path.exists():
            return default
        try:
            memory = json.loads(self.memory_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as error:
            raise ValueError(f"Teacher经验文件无法读取：{error}") from error
        if not isinstance(memory, dict):
            raise ValueError("Teacher经验文件必须是JSON对象")
        for field in default:
            if not isinstance(memory.get(field, []), list):
                raise ValueError(f"Teacher经验字段 {field} 必须是列表")
            memory.setdefault(field, [])
        return memory

    def record_feedback(self, feedback: str | dict) -> dict:
        """Save feedback as pending experience without changing current behavior."""
        if isinstance(feedback, str):
            text = feedback.strip()
            entry = {"feedback": text, "confidence": 0.5}
        elif isinstance(feedback, dict):
            entry = dict(feedback)
            text = json.dumps(entry, ensure_ascii=False, sort_keys=True).strip()
        else:
            raise TypeError("Teacher反馈必须是字符串或JSON对象")
        if not text:
            raise ValueError("Teacher反馈不能为空")

        confidence = entry.get("confidence", 0.5)
        if isinstance(confidence, bool) or not isinstance(confidence, (int, float)):
            raise ValueError("Teacher反馈置信度必须是0到1之间的数字")
        entry["confidence"] = min(1.0, max(0.0, float(confidence)))
        pending = self.memory["pending_rules"]
        signature = self._feedback_signature(entry)
        existing = next(
            (item for item in pending if self._feedback_signature(item) == signature), None
        )
        if existing is None:
            entry["occurrence_count"] = 1
            entry["created_at"] = datetime.now().isoformat(timespec="seconds")
            pending.append(entry)
            result = entry
        else:
            existing["occurrence_count"] = int(existing.get("occurrence_count", 1)) + 1
            existing["confidence"] = min(
                1.0, max(float(existing.get("confidence", 0.5)), entry["confidence"]) + 0.2
            )
            existing["last_seen_at"] = datetime.now().isoformat(timespec="seconds")
            result = existing
        self._trim_pending_rules()
        self._save_memory()
        return result

    @staticmethod
    def _feedback_signature(entry: dict) -> str:
        ignored = {"created_at", "last_seen_at", "occurrence_count", "confidence"}
        normalized = {key: value for key, value in entry.items() if key not in ignored}
        return json.dumps(normalized, ensure_ascii=False, sort_keys=True)

    def _trim_pending_rules(self) -> None:
        pending = self.memory["pending_rules"]
        if len(pending) > self.MAX_PENDING_RULES:
            pending.sort(
                key=lambda item: (
                    float(item.get("confidence", 0)),
                    int(item.get("occurrence_count", 1)),
                ),
                reverse=True,
            )
            del pending[self.MAX_PENDING_RULES:]

    def _save_memory(self) -> None:
        temporary = self.memory_path.with_suffix(".tmp")
        temporary.write_text(
            json.dumps(self.memory, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        temporary.replace(self.memory_path)

    def promote_pending_rules(self, effect_improved: bool | dict[str, bool]) -> list[str]:
        """Promote only repeated, confident rules confirmed to improve outcomes."""
        promoted = []
        active = self.memory["active_rules"]
        for entry in self.memory["pending_rules"]:
            rule = str(entry.get("rule", "")).strip()
            if not rule or rule in active:
                continue
            improved = (
                effect_improved.get(rule, False)
                if isinstance(effect_improved, dict)
                else effect_improved
            )
            if (
                improved
                and int(entry.get("occurrence_count", 1)) >= self.PROMOTION_MIN_OCCURRENCES
                and float(entry.get("confidence", 0)) >= self.PROMOTION_MIN_CONFIDENCE
                and len(active) < self.MAX_ACTIVE_RULES
            ):
                active.append(rule)
                promoted.append(rule)
        if promoted:
            self._save_memory()
        return promoted

    def learn_from_feedback(self, feedback: str | dict) -> list[dict]:
        """Convert feedback into pending experience rules for later review."""
        if isinstance(feedback, str):
            feedback_items = [feedback.strip()] if feedback.strip() else []
        elif isinstance(feedback, dict):
            feedback_items = [
                str(item).strip()
                for field in ("weaknesses", "improvement", "feedback")
                for item in (
                    feedback.get(field, [])
                    if isinstance(feedback.get(field, []), list)
                    else [feedback.get(field, "")]
                )
                if str(item).strip()
            ]
        else:
            raise TypeError("Teacher反馈必须是字符串或JSON对象")
        if not feedback_items:
            raise ValueError("Teacher反馈中没有可学习的内容")

        experiences = []
        for text in dict.fromkeys(feedback_items):
            if any(term in text for term in ("来源", "资料", "可信", "正文")):
                category = "source_selection"
            elif any(term in text for term in ("问题", "题目", "提问", "答案")):
                category = "question_generation"
            elif any(term in text for term in ("难度", "分层", "基础", "进阶", "高级")):
                category = "difficulty_classification"
            elif any(term in text for term in ("评价", "评分", "标准", "遗漏")):
                category = "evaluation_standard"
            else:
                category = "knowledge_generation"

            rule = text
            if "缺少" in text:
                rule = "生成内容时必须补充：" + text.split("缺少", 1)[1].strip(" ：:")
            elif "不足" in text:
                rule = "生成内容时必须改进：" + text.replace("不足", "").strip(" ：:")

            experiences.append(
                self.record_feedback(
                    {"category": category, "rule": rule, "source": "teacher_feedback"}
                )
            )
            memory_field = {
                "knowledge_generation": "teaching_rules",
                "evaluation_standard": "evaluation_rules",
                "question_generation": "question_rules",
            }.get(category)
            if memory_field and rule not in self.memory[memory_field]:
                self.memory[memory_field].append(rule)
                del self.memory[memory_field][50:]
        self._save_memory()
        return experiences

    def process_topic(
        self, topic: str, search_agent: SearchAgent | None = None
    ) -> tuple[dict, dict]:
        """Search one topic and process the first available raw document."""
        normalized_topic = topic.strip()
        if not normalized_topic:
            raise ValueError("学习主题不能为空")

        documents = (search_agent or SearchAgent()).search(normalized_topic)
        if not documents:
            raise RuntimeError(f"未找到主题资料：{normalized_topic}")

        document = self._select_document(normalized_topic, documents)
        return document, self.process(document)

    @staticmethod
    def _select_document(topic: str, documents: list[dict]) -> dict:
        """Choose the highest-quality document, then require a complete raw document."""
        if not documents:
            raise RuntimeError(f"搜索结果中没有完整可用的资料：{topic}")
        selected = max(documents, key=lambda item: TeacherAgent._score_document(topic, item))
        if TeacherAgent._score_document(topic, selected) <= 0:
            raise RuntimeError(f"未找到与主题相关的资料：{topic}")
        if not all(
            isinstance(selected.get(field), str) and selected[field].strip()
            for field in ("title", "content", "url", "source")
        ):
            raise RuntimeError(f"搜索结果中没有完整可用的资料：{topic}")
        return selected

    @staticmethod
    def _score_document(topic: str, document: dict) -> int:
        """Score relevance, source credibility, completeness and teaching structure."""
        title = str(document.get("title", "")).strip()
        content = str(document.get("content", "")).strip()
        url = str(document.get("url", "")).strip()
        source = str(document.get("source", "")).strip()
        normalized_topic = re.sub(r"\s+", "", topic).casefold()
        normalized_title = re.sub(r"\s+", "", title).casefold()
        normalized_content = re.sub(r"\s+", "", content).casefold()
        terms = {
            normalized_topic[index:index + 2]
            for index in range(max(0, len(normalized_topic) - 1))
        } or {normalized_topic}

        title_ratio = sum(term in normalized_title for term in terms) / len(terms)
        content_ratio = sum(term in normalized_content for term in terms) / len(terms)
        relevance = round(title_ratio * 25 + content_ratio * 15)

        host = (urlparse(url).hostname or "").casefold()
        source_text = source.casefold()
        if (
            host == "wikipedia.org" or host.endswith(".wikipedia.org")
            or host.endswith((".gov", ".gov.cn", ".edu", ".edu.cn", ".ac.cn"))
            or "官方" in source_text or "官方文档" in source_text
        ):
            credibility = 30
        elif any(term in host + source_text for term in ("百科", "教育", "baike", "education")):
            credibility = 18
        elif url and source:
            credibility = 5
        else:
            credibility = 0

        completeness = 0
        completeness += 2 if title else 0
        completeness += 2 if url else 0
        completeness += 2 if source else 0
        completeness += 4 if content else 0
        completeness += 5 if len(content) >= 80 else 0
        completeness += 5 if content and len(content) <= 12000 else 0

        structure = 0
        structure += 3 if any(term in content for term in ("是指", "定义", "称为", "表示")) else 0
        structure += 3 if any(term in content for term in ("因为", "因此", "即", "说明", "关系")) else 0
        structure += 4 if any(term in content for term in ("例如", "比如", "示例", "例子")) else 0
        return min(100, relevance + credibility + completeness + structure)

    def process(self, document: dict) -> dict:
        self._validate_document(document)
        parser = getattr(self, "knowledge_parser", None) or LocalKnowledgeParser()
        self.knowledge_parser = parser
        local_graph = parser.build_knowledge_graph(document["content"])
        active_rules = [
            str(rule).strip() for rule in self.memory["active_rules"] if str(rule).strip()
        ]
        experience_instruction = (
            "\n\nTeacher已确认的经验规则：\n- " + "\n- ".join(active_rules)
            if active_rules
            else ""
        )
        output_language = self._detect_material_language(document["content"])
        language_instruction = (
            "\n\nOutput language requirement: The source material is predominantly English. "
            "Keep all generated natural-language content in English, including titles, summaries, "
            "knowledge points, explanations, questions, answers, criteria, examples, and errors. "
            "Do not translate the material into Chinese. Keep JSON field names unchanged."
            if output_language == "en"
            else "\n\n输出语言要求：原始材料以中文为主。所有生成的自然语言内容保持中文，JSON字段名不变。"
        )
        instruction = (
            self.prompt
            + experience_instruction
            + language_instruction
            + "\n\n必须只输出合法 JSON，不要使用 Markdown 代码块。"
            + "source 必须是包含 title 和 url 的对象。"
            + "每个 knowledge_points 项必须包含 title、concept、content、principle、keywords、difficulty、importance、prerequisites、key_understandings、common_errors、applications、examples、concepts、attributes、relations、rules、causal_links；结构化关系必须由资料支持。"
            + "每个 questions 项必须包含 question、topic、answer、type、difficulty、required_knowledge、scoring_criteria、common_wrong_answers；每个知识点必须覆盖memory、understanding、application、reasoning。"
            + "\n\n待处理原始资料：\n"
            + json.dumps(document, ensure_ascii=False)
        )
        enhancement_available = bool(getattr(self, "api_key", "")) or (
            self.__class__._generate is not TeacherAgent._generate
        )
        if enhancement_available:
            try:
                response = self._generate(instruction)
                package = self._normalize_teaching_package(self._parse_json(response))
            except (RuntimeError, ValueError, json.JSONDecodeError):
                package = self.knowledge_parser.local_teaching_package(document, local_graph)
        else:
            package = self.knowledge_parser.local_teaching_package(document, local_graph)
        return self._merge_local_knowledge(package, local_graph)

    @staticmethod
    def _detect_material_language(text: str) -> str:
        """Return the dominant source language without translating the material."""
        chinese_count = len(re.findall(r"[\u4e00-\u9fff]", text))
        english_count = len(re.findall(r"[A-Za-z]", text))
        return "en" if english_count > chinese_count else "zh"

    def _merge_local_knowledge(self, package: dict, document_graph: dict) -> dict:
        """Make local atomic facts mandatory; Gemini may only enhance them."""
        package = self._normalize_teaching_package(package)
        if not package["knowledge_points"]:
            raise ValueError("Teacher output requires at least one knowledge point")
        graph_fields = ("concepts", "attributes", "relations", "rules", "causal_links")
        for index, point in enumerate(package["knowledge_points"]):
            point_graph = self.knowledge_parser.build_knowledge_graph(point.get("content", ""))
            if index == 0:
                point_graph = self.knowledge_parser.merge_graph(document_graph, point_graph)
            enhancement = {field: point.get(field, []) for field in graph_fields}
            merged = self.knowledge_parser.merge_graph(point_graph, enhancement)
            point.update(merged)
            atomic = self.knowledge_parser.atomic_content(point_graph)
            if atomic:
                point["content"] = atomic
            local_names = [item["name"] for item in merged["concepts"]]
            point["keywords"] = list(dict.fromkeys([
                *[str(item) for item in point.get("keywords", []) if str(item).strip()],
                *local_names,
            ]))
            if not point.get("principle"):
                point["principle"] = atomic
        return package

    def grade_answer(
        self,
        question: str,
        standard_answer: str,
        scoring_criteria: dict | list | str,
        agent_answer: str,
    ) -> dict:
        """Teacher-owned assessment of one Agent answer.

        Gemini remains an internal reasoning tool; this method owns the task,
        validation, feedback loop, and Teacher memory updates.
        """
        if not all(isinstance(value, str) and value.strip() for value in (question, standard_answer, agent_answer)):
            raise ValueError("question, standard_answer and agent_answer must not be empty")
        prompt = (
            self.prompt
            + "\n\nYou are grading an Agent answer as the Teacher. Return JSON only with exactly: "
            + "score (0-100 integer), understanding_level (mastered|partial|not_understood), "
            + "missing_knowledge (array), error_type (array), reasoning_analysis (string), "
            + "improvement_direction (string). Do not invent facts not supported by the standard answer. "
            + "Assess conclusion, mechanism/reasoning, omissions, and misconceptions; do not score keyword overlap alone."
            + "\n\nQuestion:\n" + question
            + "\n\nStandard answer:\n" + standard_answer
            + "\n\nScoring criteria:\n" + json.dumps(scoring_criteria, ensure_ascii=False)
            + "\n\nAgent answer:\n" + agent_answer
        )
        assessment = self._parse_json(self._generate(prompt))
        self._validate_assessment(assessment)
        self._remember_assessment(assessment)
        return assessment

    def teaching_feedback(self, assessment: dict, knowledge_point: dict | None = None) -> dict:
        """Convert a real grading result into the next Teacher teaching action."""
        self._validate_assessment(assessment)
        missing = list(assessment["missing_knowledge"])
        level = assessment["understanding_level"]
        should_raise_difficulty = level == "mastered" and assessment["score"] >= 85
        next_focus = missing or ([knowledge_point.get("title")] if knowledge_point and level != "mastered" else [])
        result = {
            "mastered": level == "mastered",
            "review_topics": next_focus,
            "next_step": "increase_difficulty" if should_raise_difficulty else "review_and_retest",
            "improvement_direction": assessment["improvement_direction"],
        }
        self.learn_from_feedback({"improvement": [assessment["improvement_direction"]]})
        return result

    @staticmethod
    def _validate_assessment(assessment: dict) -> None:
        required = {
            "score", "understanding_level", "missing_knowledge", "error_type",
            "reasoning_analysis", "improvement_direction",
        }
        if not isinstance(assessment, dict) or required - assessment.keys():
            raise ValueError("Teacher assessment fields are incomplete")
        score = assessment["score"]
        if isinstance(score, bool) or not isinstance(score, (int, float)) or not 0 <= score <= 100:
            raise ValueError("Teacher assessment score must be between 0 and 100")
        if assessment["understanding_level"] not in {"mastered", "partial", "not_understood"}:
            raise ValueError("Teacher assessment has an invalid understanding_level")
        for field in ("missing_knowledge", "error_type"):
            if not isinstance(assessment[field], list) or not all(isinstance(item, str) for item in assessment[field]):
                raise ValueError(f"Teacher assessment {field} must be a string list")
        for field in ("reasoning_analysis", "improvement_direction"):
            if not isinstance(assessment[field], str) or not assessment[field].strip():
                raise ValueError(f"Teacher assessment {field} must be a non-empty string")

    def _remember_assessment(self, assessment: dict) -> None:
        """Keep bounded observed error patterns; do not activate unreviewed rules."""
        patterns = self.memory["common_error_patterns"]
        for error in assessment["error_type"]:
            if error and error not in patterns:
                patterns.append(error)
        del patterns[50:]
        direction = assessment["improvement_direction"]
        if direction not in self.memory["evaluation_rules"]:
            self.memory["evaluation_rules"].append(direction)
            del self.memory["evaluation_rules"][50:]
        self.record_feedback({
            "category": "evaluation_standard",
            "rule": direction,
            "source": "answer_grading",
            "confidence": 0.6,
        })

    @staticmethod
    def _normalize_teaching_package(package: dict) -> dict:
        """Add compatible teaching fields without inventing unsupported facts."""
        if not isinstance(package.get("knowledge_points"), list) or not isinstance(package.get("questions"), list):
            raise ValueError("Teacher output requires knowledge_points and questions")
        for point in package["knowledge_points"]:
            if not isinstance(point, dict):
                raise ValueError("Teacher knowledge point must be an object")
            point.setdefault("concept", point.get("title", ""))
            point.setdefault("principle", point.get("content", ""))
            point.setdefault("prerequisites", [])
            point.setdefault("key_understandings", [])
            point.setdefault("common_errors", [])
            point.setdefault("applications", [])
            point.setdefault("examples", [])
            point.setdefault("concepts", [])
            point.setdefault("attributes", [])
            point.setdefault("relations", [])
            point.setdefault("rules", [])
            point.setdefault("causal_links", [])
            for field in (
                "prerequisites", "key_understandings", "common_errors", "applications",
                "examples", "concepts", "attributes", "relations", "rules", "causal_links",
            ):
                if not isinstance(point[field], list):
                    raise ValueError(f"Teacher knowledge point {field} must be a list")
        point_titles = [str(point.get("title", "")) for point in package["knowledge_points"]]
        for item in package["questions"]:
            if not isinstance(item, dict):
                raise ValueError("Teacher question must be an object")
            type_map = {
                "basic_understanding": "memory",
                "deep_understanding": "understanding",
            }
            item["type"] = type_map.get(item.get("type"), item.get("type"))
            inferred_topic = next(
                (title for title in point_titles if title and title in str(item.get("answer", ""))),
                point_titles[0] if len(point_titles) == 1 else "",
            )
            item.setdefault("topic", inferred_topic)
            item.setdefault("required_knowledge", item.get("must_include", [inferred_topic] if inferred_topic else []))
            item.setdefault("must_include", list(item["required_knowledge"]))
            criteria = item.get("scoring_criteria", [])
            if isinstance(criteria, dict):
                criteria = [f"{key}: {value}" for key, value in criteria.items()]
            item["scoring_criteria"] = criteria
            item.setdefault("common_wrong_answers", [])
            if not all(isinstance(item[field], list) for field in ("required_knowledge", "scoring_criteria", "common_wrong_answers")):
                raise ValueError("Teacher question requirement fields must be lists")
        return package

    def _generate(self, text: str) -> str:
        url = (
            "https://generativelanguage.googleapis.com/v1beta/models/"
            f"{self.model}:generateContent"
        )
        payload = {"contents": [{"parts": [{"text": text}]}]}
        request = Request(
            url,
            data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            headers={"Content-Type": "application/json; charset=utf-8", "x-goog-api-key": self.api_key},
            method="POST",
        )
        try:
            with urlopen(request, timeout=60) as response:
                result = json.loads(response.read().decode("utf-8"))
            return result["candidates"][0]["content"]["parts"][0]["text"]
        except HTTPError as error:
            detail = error.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Gemini API HTTP {error.code}: {detail}") from error
        except (URLError, KeyError, IndexError, json.JSONDecodeError) as error:
            raise RuntimeError(f"Gemini API 调用失败: {error}") from error

    @staticmethod
    def _parse_json(text: str) -> dict:
        cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip(), flags=re.I)
        result = json.loads(cleaned)
        if not isinstance(result, dict):
            raise ValueError("AI 教师返回值必须是 JSON 对象")
        return result

    @staticmethod
    def _validate_document(document: dict) -> None:
        required = {"title", "content", "url", "source"}
        if not isinstance(document, dict) or not required <= document.keys():
            raise ValueError("Raw Document 字段不完整")
        if not all(isinstance(document[key], str) and document[key].strip() for key in required):
            raise ValueError("Raw Document 字段不能为空")
