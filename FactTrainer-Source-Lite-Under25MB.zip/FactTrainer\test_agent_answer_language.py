"""Verify that the offline Agent follows the user's question language."""

from agent.agent import Agent


def cat_knowledge() -> dict:
    return {
        "topic": "专性肉食营养机制",
        "content": "猫是专性肉食动物，需要动物性食物提供关键营养。",
        "keywords": ["猫", "专性肉食动物", "牛磺酸", "普通人类食物"],
        "concepts": [
            {"id": "cat", "name": "猫", "definition": "专性肉食动物", "aliases": []},
            {"id": "food", "name": "普通人类食物", "definition": "通常不能完整满足猫的营养需求", "aliases": []},
            {"id": "taurine", "name": "牛磺酸", "definition": "维持视力和心脏功能的关键营养", "aliases": []},
        ],
        "attributes": [],
        "relations": [
            {"source": "猫", "relation": "属于", "target": "专性肉食动物", "description": "猫需要动物性营养来源"},
            {"source": "专性肉食动物", "relation": "需要", "target": "牛磺酸", "description": "牛磺酸属于关键营养"},
        ],
        "rules": [{
            "conditions": ["长期吃普通人类食物"],
            "action": "关键营养摄入不足",
            "result": "健康风险增加",
        }],
        "causal_links": [
            {"cause": "牛磺酸摄入不足", "effect": "视力和心脏功能受损", "conditions": ["长期缺乏"]},
        ],
    }


def main() -> None:
    agent = Agent("Bilingual Agent", "Cat care")
    knowledge = cat_knowledge()
    agent.learn(knowledge["topic"], knowledge["content"], knowledge=knowledge)

    english = agent.answer_text("Why can't cats eat human food for a long time?")
    taurine = agent.answer_text("Why is taurine important for cats?")
    chinese = agent.answer_text("为什么猫不能长期吃普通人类食物？")
    unknown = agent.answer_text("What is quantum chromodynamics?")
    print({"english": english, "taurine": taurine, "chinese": chinese, "unknown": unknown})

    assert english and not any("\u4e00" <= char <= "\u9fff" for char in english)
    assert any(word in english.casefold() for word in ("cat", "carnivore", "taurine"))
    assert chinese and any("\u4e00" <= char <= "\u9fff" for char in chinese)
    assert all(term in taurine.casefold() for term in ("taurine", "eye health", "heart function"))
    assert unknown == agent.language_layer.unknown_answer("What is quantum chromodynamics?")

    english_agent = Agent("English-trained Agent", "Cat Care")
    english_knowledge = {
        "topic": "Cat Nutrition",
        "content": "Cats are obligate carnivores and need taurine.",
        "keywords": ["cats", "human food", "taurine", "eye health", "heart function"],
        "concepts": [
            {"id": "cat", "name": "Cats", "definition": "obligate carnivores", "aliases": ["cat"]},
            {"id": "food", "name": "Human food", "definition": "does not provide complete feline nutrition", "aliases": []},
            {"id": "taurine", "name": "Taurine", "definition": "an essential nutrient for cats", "aliases": []},
        ],
        "attributes": [],
        "relations": [
            {"source": "Taurine", "relation": "supports", "target": "Eye health", "description": "Taurine supports vision"},
            {"source": "Taurine", "relation": "supports", "target": "Heart function", "description": "Taurine supports cardiac health"},
        ],
        "rules": [],
        "causal_links": [{"cause": "Long-term taurine deficiency", "effect": "Eye and heart problems", "conditions": []}],
    }
    english_agent.learn("Cat Nutrition", english_knowledge["content"], knowledge=english_knowledge)
    english_material_answer = english_agent.answer_text("Why can't cats eat human food for a long time?")
    print({"english_material_answer": english_material_answer})
    assert english_material_answer != english_agent.language_layer.unknown_answer(
        "Why can't cats eat human food for a long time?"
    )


if __name__ == "__main__":
    main()
