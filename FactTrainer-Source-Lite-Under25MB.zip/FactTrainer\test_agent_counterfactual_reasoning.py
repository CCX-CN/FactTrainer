"""Verify state-transition reasoning after removing a learned operation."""

import json

from agent.agent import Agent


def main() -> None:
    agent = Agent("反事实测试", "Python")
    agent.learn(
        "Student属性保存",
        "Student类通过self.name保存name属性",
        keywords=["Student", "self.name", "name"],
    )
    question = "如果删除 self.name=name，之后创建Student对象会发生什么？为什么？"
    answer = agent.answer_text(question)
    log = agent.last_answer_log or {}
    print(json.dumps({"question": question, "answer": answer, "log": log}, ensure_ascii=False, indent=2))

    assert "name仍作为构造参数存在" in answer
    assert "不会形成name属性状态" in answer
    assert "student.name" in answer and "无法取得" in answer
    assert log["verification"]["passed"] is True
    assert set(log["verification"]["missing_dimensions"]) == set()
    assert log["verification"]["coverage_ratio"] == 1.0


if __name__ == "__main__":
    main()
