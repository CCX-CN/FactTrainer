"""Offline acceptance test for the Agent answer decision loop."""

import json
import tempfile
from pathlib import Path

from agent.agent import Agent
from knowledge.knowledge_base import KnowledgeBase
from questions.question_generator import QuestionGenerator
from training.evaluator import Evaluator
from training.trainer import Trainer


def knowledge_items() -> list[dict]:
    return [
        {
            "topic": "Python列表零基索引",
            "concept": "列表第一个位置的索引是0",
            "content": "Python列表按照零基索引编号，第一个元素对应索引0。",
            "explanation": "Python列表按照零基索引编号，第一个元素对应索引0。",
            "principle": "零基索引把序列起点映射到数字0，后续位置依次递增。",
            "conditions": ["按位置访问有序序列"],
            "process": ["将元素顺序位置减1得到索引"],
            "result": "第一个元素使用索引0访问",
            "applications": ["按位置读取列表元素"],
            "common_errors": ["误把索引1当成第一个位置"],
            "examples": ["items[0]读取第一个元素"],
            "keywords": ["列表", "零基索引"],
            "level": "basic",
        },
        {
            "topic": "with文件上下文管理",
            "concept": "with语句管理文件资源的使用范围",
            "content": "with打开文件后会在代码块结束时执行上下文退出处理。",
            "explanation": "with语句限定文件资源的使用范围，并负责退出处理。",
            "principle": "上下文管理器进入时获得文件资源，离开代码块时调用退出流程。",
            "conditions": ["文件对象支持上下文管理协议"],
            "process": ["进入代码块获得文件对象", "离开代码块执行退出处理"],
            "result": "文件资源在正常结束或异常离开时都能进入清理流程",
            "applications": ["读取或写入文件时管理打开和关闭"],
            "common_errors": ["手动打开文件后遗漏关闭"],
            "examples": ["with open(path) as file"],
            "keywords": ["with", "文件", "上下文管理"],
            "level": "intermediate",
        },
        {
            "topic": "文件资源释放",
            "concept": "使用结束后关闭文件资源",
            "content": "关闭文件会释放系统资源并完成缓冲数据处理。",
            "explanation": "文件使用结束后需要可靠关闭。",
            "principle": "退出处理调用文件关闭操作，从而释放资源并处理缓冲数据。",
            "conditions": ["文件已经打开并完成使用"],
            "process": ["执行关闭操作", "释放文件句柄"],
            "result": "避免资源泄漏和未完成的缓冲写入",
            "applications": ["文件读写完成后的资源清理"],
            "common_errors": ["异常发生后跳过手动close调用"],
            "examples": [],
            "keywords": ["文件", "关闭", "资源释放"],
            "level": "intermediate",
        },
    ]


def main() -> None:
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "python.json"
        path.write_text(json.dumps(knowledge_items(), ensure_ascii=False), encoding="utf-8")
        base = KnowledgeBase(path)
        base.load()
        agent = Agent("决策循环测试", "Python")
        Trainer(agent, base, QuestionGenerator(base), Evaluator()).train_once()

    list_answer = agent.answer_text("为什么Python不用1作为第一个索引？")
    list_log = dict(agent.last_answer_log or {})
    file_answer = agent.answer_text("为什么Python推荐with打开文件？")
    file_log = dict(agent.last_answer_log or {})
    unknown_answer = agent.answer_text("Python装饰器底层原理是什么？")
    unknown_log = dict(agent.last_answer_log or {})

    result = {
        "zero_index": {"answer": list_answer, "log": list_log},
        "with_file": {"answer": file_answer, "log": file_log},
        "unknown": {"answer": unknown_answer, "log": unknown_log},
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))

    assert "序列起点映射到数字0" in list_answer
    assert list_log["intent"] == "principle"
    assert "退出" in file_answer and "释放" in file_answer
    assert len(file_log["selected_knowledge"]) >= 2
    assert unknown_answer == Agent.UNKNOWN_ANSWER
    assert unknown_log["selected_knowledge"] == []


if __name__ == "__main__":
    main()
