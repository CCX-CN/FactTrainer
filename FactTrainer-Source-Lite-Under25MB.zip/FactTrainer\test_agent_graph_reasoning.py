"""Minimal acceptance test for two-hop graph reasoning and legacy fallback."""

from agent.agent import Agent


def main() -> None:
    agent = Agent("图推理测试", "通用")
    graph_knowledge = {
        "topic": "资源自动释放",
        "content": "上下文管理器负责在离开作用域时释放资源。",
        "keywords": ["上下文管理器", "资源"],
        "concepts": [
            {"id": "context", "name": "上下文管理器", "definition": "管理资源生命周期", "aliases": []}
        ],
        "attributes": [],
        "relations": [
            {"source": "上下文管理器", "relation": "进入", "target": "受控作用域", "description": "资源在作用域内可用"},
            {"source": "受控作用域", "relation": "离开", "target": "退出处理", "description": "正常结束或异常都会离开作用域"},
        ],
        "rules": [
            {"conditions": ["退出处理发生"], "action": "调用清理动作", "result": "资源被释放"}
        ],
        "causal_links": [
            {"cause": "退出处理", "effect": "调用清理动作", "conditions": ["离开受控作用域"]}
        ],
    }
    agent.learn(graph_knowledge["topic"], graph_knowledge["content"], knowledge=graph_knowledge)
    result = agent.answer_with_reasoning("上下文管理器离开受控作用域后，为什么资源会被释放？")
    answer = result["final_answer"]
    trace = result["reasoning_trace"]
    print({"answer": answer, "reasoning_trace": trace})

    assert answer != Agent.UNKNOWN_ANSWER
    assert "退出处理" in answer and "资源被释放" in answer
    assert sum(step.startswith("relation_hop:") for step in trace) >= 2
    assert any(step.startswith("rule_applied:") for step in trace)
    assert any(step.startswith("causal_applied:") for step in trace)

    legacy = Agent("文本回退测试", "Python")
    legacy.learn("Python变量", "变量用于保存数据", keywords=["变量"])
    assert "变量" in legacy.answer_text("Python变量是什么？")

    print({"fallback": "passed"})


if __name__ == "__main__":
    main()
