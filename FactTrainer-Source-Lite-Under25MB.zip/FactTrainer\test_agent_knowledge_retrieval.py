"""Regression test: each question must retrieve its own learned topic."""

from agent.agent import Agent


def main() -> None:
    agent = Agent("检索验证 Agent", "Python")
    agent.learn(
        "Python 变量与赋值",
        "变量用于保存数据，赋值会让名称引用一个对象。",
        keywords=["变量", "赋值", "名称", "对象"],
    )
    agent.learn(
        "Python 条件判断",
        "if 根据条件表达式的真假选择要执行的分支。",
        keywords=["if", "条件判断", "条件表达式", "分支"],
    )
    agent.learn(
        "Python 文件操作",
        "使用 open 打开文件，并在完成读写后关闭文件或使用 with 自动关闭。",
        keywords=["文件", "open", "读写", "with", "关闭"],
    )
    agent.learn(
        "列表数据结构与零基索引机制",
        "列表（List）保存多个数据，使用零基索引，list[0]访问第一个元素。",
        keywords=["列表", "索引", "零基索引"],
        knowledge={
            "topic": "列表数据结构与零基索引机制",
            "concept": "列表是有序序列，索引从零开始",
            "explanation": "列表保存多个数据，索引0对应第一个元素。",
            "principle": "零基索引把第一个位置映射为0，后续位置依次递增。",
            "applications": ["按位置读取列表元素"],
            "common_errors": ["误把索引1当作第一个位置"],
            "examples": ["list[0]访问列表第一个元素"],
            "keywords": ["列表", "索引", "零基索引"],
        },
    )

    checks = {
        "变量如何保存数据？": "变量用于保存数据",
        "if判断怎样选择分支？": "条件表达式的真假",
        "Python文件操作如何读写？": "open 打开文件",
    }
    for question, expected in checks.items():
        answer = agent.answer_text(question)
        print(f"{question} -> {answer}")
        assert expected in answer, (question, answer)

    list_question = "在 Python 中执行 list=[10,20,30] 后访问 list[0]，结果是什么？"
    list_answer = agent.answer_text(list_question)
    print(f"{list_question} -> {list_answer}")
    assert "索引0对应第一个元素" in list_answer


if __name__ == "__main__":
    main()
