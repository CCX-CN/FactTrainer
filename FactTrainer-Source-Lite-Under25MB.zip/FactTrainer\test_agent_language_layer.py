"""Acceptance test for the offline language layer around graph reasoning."""

from agent.agent import Agent


def graph_knowledge() -> dict:
    return {
        "topic": "资源生命周期",
        "content": "上下文管理器离开作用域时释放资源。",
        "keywords": ["上下文管理器", "资源释放"],
        "concepts": [{
            "id": "context_manager",
            "name": "上下文管理器",
            "definition": "管理资源生命周期",
            "aliases": ["资源管理器", "作用域管理器"],
        }],
        "attributes": [],
        "relations": [
            {"source": "上下文管理器", "relation": "管理", "target": "资源作用域", "description": "资源仅在作用域内使用"},
            {"source": "资源作用域", "relation": "离开后进入", "target": "退出处理", "description": "正常或异常离开都会触发退出处理"},
        ],
        "rules": [{
            "conditions": ["退出处理发生"],
            "action": "执行清理动作",
            "result": "文件资源被释放",
        }],
        "causal_links": [{
            "cause": "退出处理",
            "effect": "执行清理动作",
            "conditions": ["离开资源作用域"],
        }],
    }


def main() -> None:
    agent = Agent("通用Agent", "通用")
    knowledge = graph_knowledge()
    agent.learn(knowledge["topic"], knowledge["content"], knowledge=knowledge)

    result = agent.answer_with_reasoning("资源管理器离开作用域后，为什么文件会被释放？")
    log = agent.last_answer_log or {}
    print({"result": result, "log": log})
    assert log["question_type"] == "causal"
    assert "上下文管理器" in log["target_concepts"]
    assert result["final_answer"] != Agent.UNKNOWN_ANSWER
    assert "退出处理" in result["final_answer"] and "文件资源被释放" in result["final_answer"]
    assert any(step.startswith("relation_hop:") for step in result["reasoning_trace"])

    unknown = agent.answer_text("完全未学习的量子纠缠实验是什么？")
    assert unknown == Agent.UNKNOWN_ANSWER

    legacy = Agent("旧知识Agent", "通用")
    legacy.learn("变量", "变量用于保存数据", keywords=["变量"])
    assert "变量" in legacy.answer_text("变量是什么？")

    print({"question_type": log["question_type"], "fallback": "passed"})


if __name__ == "__main__":
    main()
