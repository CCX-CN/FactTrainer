"""Verify that training writes knowledge which the public answer path can use."""

import json
import tempfile
from pathlib import Path

from agent.agent import Agent
from knowledge.knowledge_base import KnowledgeBase
from questions.question_generator import QuestionGenerator
from training.evaluator import Evaluator
from training.trainer import Trainer


def main() -> None:
    knowledge = [{
        "topic": "Python 列表与序列索引",
        "content": "列表是有序的可变序列，可通过索引访问元素。",
        "keywords": ["列表", "有序", "可变", "索引"],
        "level": "basic",
    }]
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "python.json"
        path.write_text(json.dumps(knowledge, ensure_ascii=False), encoding="utf-8")
        base = KnowledgeBase(path)
        base.load()
        agent = Agent("验证 Agent", "Python")
        before = len(agent.learned_knowledge)
        Trainer(agent, base, QuestionGenerator(base), Evaluator()).train_once()
        after = len(agent.learned_knowledge)
        answer = agent.answer_text("Python列表怎样通过索引访问元素？")

    print(f"训练前 learned_knowledge: {before}")
    print(f"训练后 learned_knowledge: {after}")
    print(f"匹配知识: {answer}")
    assert before == 0 and after == 1
    assert "有序的可变序列" in answer


if __name__ == "__main__":
    main()
