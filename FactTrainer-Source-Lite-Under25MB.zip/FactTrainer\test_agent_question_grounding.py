"""The same knowledge point must produce question-grounded, different answers."""

import json

from agent.agent import Agent


def main() -> None:
    agent = Agent("OOP测试", "Python")
    knowledge = {
        "topic": "Student对象初始化与属性封装",
        "concept": "Student('Tom')创建Student类的对象，Tom是传给构造方法的name参数",
        "explanation": "构造方法接收Tom后执行self.name = name，把Tom保存在当前对象的name属性中",
        "principle": "封装通过对象属性保存自身数据；self表示当前对象，外部通过对象变量的name属性访问该值",
        "conditions": ["Student构造方法接收name参数"],
        "process": ["创建student对象", "把name参数赋给self.name"],
        "result": "student.name得到该对象保存的Tom",
        "applications": ["student = Student('Tom')后使用student.name访问Tom"],
        "common_errors": ["把Tom误认为对象名；对象名实际是student"],
        "examples": ["student = Student('Tom'); student.name"],
        "keywords": ["Student", "对象", "属性", "封装"],
    }
    agent.learn(
        knowledge["topic"], knowledge["explanation"], keywords=knowledge["keywords"],
        knowledge=knowledge,
    )

    answer_a = agent.answer_text("Student对象中的Tom是什么？")
    log_a = dict(agent.last_answer_log or {})
    answer_b = agent.answer_text("封装如何体现？")
    log_b = dict(agent.last_answer_log or {})
    print(json.dumps({
        "question_a": {"answer": answer_a, "log": log_a},
        "question_b": {"answer": answer_b, "log": log_b},
    }, ensure_ascii=False, indent=2))

    assert answer_a != answer_b
    assert "name参数" in answer_a and "self.name" in answer_a
    assert "封装" in answer_b and "对象属性" in answer_b
    assert log_a["reasoning_steps"] != log_b["reasoning_steps"]


if __name__ == "__main__":
    main()
