"""Verify that graph reasoning keeps only question-relevant evidence."""

import json

from agent.agent import Agent


def knowledge(topic, concept, concepts, relations=None, rules=None, causal_links=None):
    return {
        "topic": topic,
        "concept": concept,
        "content": concept,
        "explanation": concept,
        "principle": concept,
        "keywords": [topic, concept],
        "applications": [],
        "common_errors": [],
        "prerequisites": [],
        "examples": [],
        "concepts": concepts,
        "attributes": [],
        "relations": relations or [],
        "rules": rules or [],
        "causal_links": causal_links or [],
    }


def main() -> None:
    agent = Agent("跨领域相关性测试", "猫咪护理")
    nutrition = knowledge(
        "专性肉食营养机制",
        "猫是专性肉食动物，需要动物性食物提供关键营养",
        [
            {"id": "cat", "name": "猫", "definition": "专性肉食动物", "aliases": []},
            {"id": "carnivore", "name": "专性肉食动物", "definition": "必须从动物组织获得必需营养的动物", "aliases": []},
            {"id": "taurine", "name": "牛磺酸", "definition": "维持视力和心脏功能的关键营养", "aliases": []},
            {"id": "human_food", "name": "普通人类食物", "definition": "通常不能完整满足猫的营养需求", "aliases": []},
        ],
        relations=[
            {"source": "猫", "relation": "属于", "target": "专性肉食动物", "description": "猫需要动物性营养来源"},
            {"source": "专性肉食动物", "relation": "需要", "target": "牛磺酸", "description": "牛磺酸属于关键营养"},
        ],
        rules=[
            {"conditions": ["长期只吃普通人类食物"], "action": "关键营养摄入不足", "result": "健康风险增加"},
        ],
        causal_links=[
            {"cause": "牛磺酸摄入不足", "effect": "视力和心脏功能受损", "conditions": ["长期缺乏"]},
        ],
    )
    litter = knowledge(
        "猫砂盆使用行为逻辑",
        "猫砂盆使用会受到清洁度、位置、压力和健康状态影响",
        [
            {"id": "cat", "name": "猫", "definition": "会使用猫砂盆的动物", "aliases": []},
            {"id": "litter", "name": "猫砂盆", "definition": "猫的排泄设施", "aliases": []},
            {"id": "avoidance", "name": "突然停止使用猫砂盆", "definition": "需要检查环境和健康原因", "aliases": []},
        ],
        rules=[
            {"conditions": ["猫突然不使用猫砂盆"], "action": "检查清洁度、位置、压力和健康状态", "result": "定位停止使用的原因"},
        ],
        causal_links=[
            {"cause": "猫砂盆脏乱或位置不合适", "effect": "猫减少使用猫砂盆", "conditions": ["环境不舒适"]},
        ],
    )
    body_language = knowledge(
        "猫的身体语言",
        "猫通过尾巴、耳朵和呼噜声表达状态",
        [
            {"id": "cat", "name": "猫", "definition": "会表达身体信号的动物", "aliases": []},
            {"id": "tail", "name": "尾巴状态", "definition": "用于表达情绪", "aliases": []},
            {"id": "ears", "name": "耳朵方向", "definition": "用于表达警觉或紧张", "aliases": []},
            {"id": "purr", "name": "呼噜声", "definition": "可能表达放松或压力", "aliases": []},
        ],
        relations=[
            {"source": "猫", "relation": "通过", "target": "尾巴状态", "description": "尾巴状态表达情绪"},
            {"source": "猫", "relation": "通过", "target": "耳朵方向", "description": "耳朵方向表达心理状态"},
        ],
    )
    scratching = knowledge(
        "猫抓挠行为",
        "猫抓挠可以维护指甲，也可能留下气味标记",
        [
            {"id": "scratching", "name": "抓挠行为", "definition": "猫的自然行为", "aliases": []},
            {"id": "claw_care", "name": "指甲维护", "definition": "去除老旧爪鞘", "aliases": []},
        ],
        relations=[
            {"source": "抓挠行为", "relation": "用于", "target": "指甲维护", "description": "抓挠帮助去除老旧爪鞘"},
        ],
    )
    for item in (nutrition, litter, body_language, scratching):
        agent.learn(item["topic"], item["content"], "basic", item["keywords"], item)

    cases = [
        {
            "type": "definition",
            "question": "什么是专性肉食动物？",
            "required": ["专性肉食动物"],
            "forbidden": ["猫砂盆", "尾巴", "耳朵", "呼噜声"],
        },
        {
            "type": "causal",
            "question": "为什么猫不能长期只吃普通人类食物？",
            "required": ["营养", "健康"],
            "forbidden": ["猫砂盆", "尾巴", "耳朵", "呼噜声"],
        },
        {
            "type": "application",
            "question": "如果猫突然不使用猫砂盆，应该检查哪些原因？",
            "required": ["检查", "猫砂盆"],
            "forbidden": ["牛磺酸", "专性肉食", "尾巴", "耳朵"],
        },
        {
            "type": "counterfactual",
            "question": "如果删除牛磺酸摄入不足，会发生什么？",
            "required": ["视力", "心脏"],
            "forbidden": ["猫砂盆", "尾巴", "耳朵", "呼噜声"],
        },
        {
            "type": "application",
            "question": "猫抓挠如何帮助维护指甲？",
            "required": ["抓挠", "指甲"],
            "forbidden": ["猫砂盆", "牛磺酸", "尾巴", "耳朵"],
        },
    ]
    results = []
    for case in cases:
        answer = agent.answer_text(case["question"])
        selected = list(agent.last_answer_log["selected_knowledge"])
        assert answer != Agent.UNKNOWN_ANSWER, case
        assert all(term in answer for term in case["required"]), (case, answer)
        assert not any(term in answer for term in case["forbidden"]), (case, answer)
        assert not any(marker in answer for marker in ("知识关系", "关系是", "随后", "→")), answer
        assert len(answer) <= 150, answer
        results.append({
            "type": case["type"],
            "question": case["question"],
            "selected_knowledge": selected,
            "answer": answer,
            "reasoning_trace": list(agent.last_answer_log["reasoning_trace"]),
            "verification": dict(agent.last_answer_log["verification"]),
        })

    print(json.dumps(results, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
