"""Verify graph-based answers while legacy text remains only a fallback."""

import json

from agent.agent import Agent


def main() -> None:
    knowledge = {
        "topic": "Student对象状态",
        "concept": "旧文本摘要不应成为新回答的唯一来源",
        "content": "旧文本摘要不应成为新回答的唯一来源",
        "keywords": ["Student"],
        "concepts": [
            {
                "id": "student_object",
                "name": "Student对象",
                "definition": "Student类创建的实例",
                "aliases": ["student", "实例"],
            },
            {
                "id": "encapsulation",
                "name": "对象数据封装",
                "definition": "数据保存在对象自身属性中",
                "aliases": ["封装"],
            },
        ],
        "attributes": [
            {
                "subject": "Student对象",
                "name": "name属性",
                "value": "构造参数name的值",
                "description": "对象自身保存的名称状态",
            }
        ],
        "relations": [
            {
                "source": "name参数",
                "relation": "赋值到",
                "target": "Student对象.name属性",
                "description": "self.name=name建立参数到对象状态的关系",
            },
            {
                "source": "Student对象",
                "relation": "通过属性访问",
                "target": "student.name",
                "description": "外部使用对象变量读取name属性",
            },
            {
                "source": "Student对象",
                "relation": "封装",
                "target": "name属性",
                "description": "name数据属于每个对象自身的状态",
            },
        ],
        "rules": [
            {
                "conditions": ["Student构造方法接收name参数"],
                "action": "self.name=name",
                "result": "Student对象形成name属性",
            }
        ],
        "causal_links": [
            {
                "cause": "self.name=name",
                "effect": "Student对象拥有name属性",
                "conditions": ["name参数已经传入"],
            }
        ],
    }
    agent = Agent("结构化知识测试", "Python")
    agent.learn(knowledge["topic"], knowledge["content"], knowledge=knowledge)

    role_answer = agent.answer_text("Student('Tom')里的Tom进入了对象的什么位置？之后怎样访问？")
    role_log = dict(agent.last_answer_log or {})
    encapsulation_answer = agent.answer_text("对象数据的封装体现在哪种关系中？")
    encapsulation_log = dict(agent.last_answer_log or {})
    counterfactual_answer = agent.answer_text(
        "如果删除self.name=name，之后创建Student对象会发生什么？为什么？"
    )
    counterfactual_log = dict(agent.last_answer_log or {})

    print(json.dumps({
        "role": {"answer": role_answer, "log": role_log},
        "encapsulation": {"answer": encapsulation_answer, "log": encapsulation_log},
        "counterfactual": {"answer": counterfactual_answer, "log": counterfactual_log},
        "graph": agent.knowledge_graph,
    }, ensure_ascii=False, indent=2))

    assert role_answer != encapsulation_answer
    assert "name属性" in role_answer and "student.name" in role_answer
    assert "封装" in encapsulation_answer
    assert "构造方法接收name参数" in counterfactual_answer
    assert "Student对象形成name属性不再由该关系产生" in counterfactual_answer
    assert "student.name" in counterfactual_answer
    assert counterfactual_log["verification"]["passed"] is True
    assert agent.knowledge_graph["relations"]


if __name__ == "__main__":
    main()
