import json
import tempfile
from pathlib import Path

from student.presenter import StudentPresenter
from student.student_agent import StudentAgent
from teacher.teacher_agent import TeacherAgent
from training.evaluator import TeacherTrainerEvaluator
from training.training_loop import TeacherTrainingLoop


EMPTY_MEMORY = {
    "abilities": {
        "knowledge_extraction": 0,
        "knowledge_classification": 0,
        "question_generation": 0,
        "answer_evaluation": 0,
        "teaching_planning": 0,
    },
    "learned_rules": [],
    "teaching_methods": [],
}
material = {
    "title": "Python 异常处理的 else 与 finally",
    "content": (
        "try 语句的 except 子句处理匹配的异常。可选的 else 子句在 try 子句没有引发异常时执行。"
        "finally 子句无论是否发生异常都会执行，因此常用于释放资源。如果 finally 中存在 return，"
        "它会使尚未重新引发的异常不再传播。"
    ),
    "source": "Python 官方教程",
    "url": "https://docs.python.org/zh-cn/3/tutorial/errors.html",
}


def quality(result: dict) -> dict:
    structured_points = sum(
        isinstance(point, dict)
        and all(point.get(field) for field in ("concept", "mechanism", "explanation"))
        for point in result["knowledge_points"]
    )
    types = {
        question.get("type") for question in result["questions"]
        if isinstance(question, dict) and question.get("type")
    }
    evaluated_questions = sum(
        isinstance(question, dict)
        and question.get("answer")
        and question.get("evaluation_criteria")
        for question in result["questions"]
    )
    return {
        "structured_knowledge": structured_points,
        "question_angles": len(types),
        "evaluated_questions": evaluated_questions,
    }


with tempfile.TemporaryDirectory() as directory:
    memory_path = Path(directory) / "capability_memory.json"
    memory_path.write_text(json.dumps(EMPTY_MEMORY, ensure_ascii=False), encoding="utf-8")

    student = StudentAgent(memory_path=memory_path)
    before = student.process(material)
    before_quality = quality(before)

    TeacherTrainingLoop(student, TeacherTrainerEvaluator(TeacherAgent())).train_once(material)

    independent_student = StudentAgent(memory_path=memory_path)
    after = independent_student.process(material)
    after_quality = quality(after)
    assert independent_student.capability_memory["learned_rules"], "训练未形成可迁移规则"
    assert sum(after_quality.values()) > sum(before_quality.values()), "能力迁移后质量没有提升"

    print(json.dumps({
        "before_quality": before_quality,
        "after_quality": after_quality,
        "memory": independent_student.capability_memory,
        "teaching_content": StudentPresenter().render(after),
    }, ensure_ascii=False, indent=2))
