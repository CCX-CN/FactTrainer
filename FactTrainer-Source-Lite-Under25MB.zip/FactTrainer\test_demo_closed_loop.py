"""Offline acceptance test for the real demo learning and persistence chain."""

import json
import tempfile
from pathlib import Path

import app_server
from agent.agent import Agent
from knowledge.knowledge_base import KnowledgeBase
from questions.question_generator import QuestionGenerator
from training.evaluator import Evaluator
from training.trainer import Trainer


def main() -> None:
    knowledge = [{
        "topic": "Python列表零基索引",
        "concept": "列表索引从0开始",
        "content": "Python列表保存有序元素，第一个元素的索引是0。",
        "explanation": "索引表示元素相对序列起点的偏移量，因此起点偏移量是0。",
        "principle": "第N个元素对应索引N-1。",
        "prerequisites": ["有序序列"],
        "key_understandings": ["位置序号与索引相差1"],
        "common_errors": ["误把索引1当作第一个元素"],
        "applications": ["读取列表开头的数据"],
        "examples": ["items[0]读取第一个元素"],
        "keywords": ["Python列表", "索引", "零基"],
        "level": "basic",
        "concepts": [
            {"id": "list", "name": "Python列表", "definition": "有序元素集合", "aliases": ["列表"]},
            {"id": "index", "name": "零基索引", "definition": "序列起点索引为0", "aliases": ["位置编号"]},
        ],
        "attributes": [],
        "relations": [{"source": "Python列表", "relation": "使用", "target": "零基索引", "description": "列表使用从0开始的位置编号"}],
        "rules": [{"conditions": ["元素位于第N个位置"], "action": "计算N-1", "result": "得到对应索引"}],
        "causal_links": [{"cause": "索引表示相对起点的偏移量", "effect": "第一个元素索引为0", "conditions": ["从序列起点计数"]}],
    }]

    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        knowledge_path = root / "knowledge.json"
        knowledge_path.write_text(json.dumps(knowledge, ensure_ascii=False), encoding="utf-8")
        base = KnowledgeBase(knowledge_path)
        base.load()

        agent = Agent("演示验收 Agent", "Python")
        assert agent.score == 0
        assert not agent.learned_knowledge
        assert not any(agent.knowledge_graph.values())
        assert agent.answer_text("为什么列表开头的位置编号是零？") == Agent.UNKNOWN_ANSWER

        result = Trainer(agent, base, QuestionGenerator(base), Evaluator()).train_once()
        answer = agent.answer_text("为什么读取列表开头的数据时位置编号要写成零？")
        assert answer != Agent.UNKNOWN_ANSWER
        assert len(agent.learned_knowledge) == 1
        assert agent.knowledge_graph["relations"] and agent.knowledge_graph["rules"]
        assert result["before_score"] == round(sum(item["score_before"] for item in result["records"]) / len(result["records"]))
        assert result["after_score"] == round(sum(item["score_after"] for item in result["records"]) / len(result["records"]))

        state_path = root / "agent_state_v2.json"
        app_server.STATE_FILE = state_path
        app_server.agent = agent
        app_server.training_result = result
        app_server.exam_result = None
        app_server.chat_history = [{"question": "为什么列表开头的位置编号是零？", "answer": answer}]
        app_server.lesson_result = None
        app_server.prepared_knowledge_path = None
        app_server.save_state()
        app_server.agent = None
        app_server.training_result = None
        app_server.chat_history = []
        app_server.load_state()
        assert app_server.agent is not None
        assert app_server.agent.learned_knowledge == agent.learned_knowledge
        assert app_server.agent.score == result["after_score"]
        assert app_server.training_result == result

    print(json.dumps({
        "initial_score": 0,
        "initial_learned_count": 0,
        "before_score": result["before_score"],
        "after_score": result["after_score"],
        "learned_count": len(agent.learned_knowledge),
        "variant_answer": answer,
        "persistence": "passed",
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
