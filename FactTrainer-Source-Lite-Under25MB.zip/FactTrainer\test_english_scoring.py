"""English Agent answers must receive real, non-zero evaluation scores."""

from agent.agent import Agent
from final_exam import FinalExam
from training.evaluator import Evaluator


def main() -> None:
    knowledge = {
        "topic": "Python variables",
        "content": "Python variables store values and names refer to objects.",
        "keywords": ["Python variables", "values", "objects"],
        "concepts": [{
            "id": "variable", "name": "Python variables",
            "definition": "names that refer to objects", "aliases": ["variables"],
        }],
        "attributes": [],
        "relations": [{
            "source": "Python variables", "relation": "refer to", "target": "objects",
            "description": "variables store references to values",
        }],
        "rules": [],
        "causal_links": [],
    }
    agent = Agent("English Agent", "Python")
    before = agent.answer_text("What do Python variables refer to?")
    agent.learn(knowledge["topic"], knowledge["content"], knowledge=knowledge)
    after = agent.answer_text("What do Python variables refer to?")
    result = Evaluator().evaluate(
        "What do Python variables refer to?",
        "Python variables are names that refer to objects.",
        after,
        knowledge["keywords"],
    )
    exam = FinalExam(agent).run()
    print({"before": before, "after": after, "knowledge": len(agent.learned_knowledge), "score": result["score"], "exam_score": exam["score"]})
    assert len(agent.learned_knowledge) > 0
    assert after and not any("\u4e00" <= char <= "\u9fff" for char in after)
    assert result["score"] > 0
    assert exam["results"] and exam["score"] > 0


if __name__ == "__main__":
    main()
