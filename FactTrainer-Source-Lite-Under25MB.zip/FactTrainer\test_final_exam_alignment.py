from agent.agent import Agent
from agent.knowledge_graph import StructuredKnowledgeReasoner
from final_exam import FinalExam


def main() -> None:
    agent = Agent("Exam Audit", "Python")
    knowledge = {
        "topic": "列表零基索引",
        "concept": "零基索引",
        "content": "列表第一个元素的索引是0。",
        "principle": "第N个元素对应索引N-1。",
        "keywords": ["列表", "索引", "N-1"],
        "applications": ["按位置访问列表元素"],
        "concepts": [
            {"id": "index", "name": "零基索引", "definition": "首元素索引为0", "aliases": []},
        ],
        "attributes": [],
        "relations": [
            {"source": "第N个元素", "relation": "对应", "target": "索引N-1", "description": "第N个元素对应索引N-1"},
        ],
        "rules": [],
        "causal_links": [],
    }
    agent.learn("列表零基索引", knowledge["content"], "basic", knowledge["keywords"], knowledge)
    result = FinalExam(agent).run()

    assert len(result["results"]) == 1
    exam_item = result["results"][0]
    assert exam_item["topic"] == "列表零基索引"
    assert agent.last_answer_log["question"] == exam_item["question"]
    assert exam_item["question"] != exam_item["topic"]
    assert not StructuredKnowledgeReasoner._entity_in_question("N", "python变量")
    print(result)


if __name__ == "__main__":
    main()
