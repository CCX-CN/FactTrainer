from agent.agent import Agent
from pipeline.knowledge_pipeline import KnowledgePipeline
from questions.question_generator import QuestionGenerator
from search.search_agent import SearchAgent
from teacher.teacher_agent import TeacherAgent
from training.evaluator import Evaluator
from training.trainer import Trainer


document = SearchAgent().fetch_url(
    "https://docs.python.org/zh-cn/3/tutorial/controlflow.html#defining-functions",
    "Python 函数定义",
    "Python 官方文档",
)
knowledge_json, knowledge_base = KnowledgePipeline(
    TeacherAgent(), "knowledge/generated"
).process(document, "Python")
agent = Agent("Python Expert", "Python")
result = Trainer(
    agent, knowledge_base, QuestionGenerator(knowledge_base), Evaluator()
).train_once()
assert result["records"], "Trainer 没有生成训练记录"
print({"knowledge_points": len(knowledge_json["knowledge_points"]), "training": result})
