import copy
import json
import tempfile
from pathlib import Path

from student.student_agent import StudentAgent
from teacher.teacher_agent import TeacherAgent
from training.evaluator import TeacherTrainerEvaluator
from training.training_loop import TeacherTrainingLoop


EMPTY_MEMORY = {
    "abilities": {
        "knowledge_extraction": 0,
        "knowledge_classification": 0,
        "question_generation": 0,
        "answer_evaluation": 0,
        "teaching_planning": 0,
    },
    "learned_rules": [],
    "teaching_methods": [],
    "behavior_rules": {
        "knowledge_extraction_rules": [],
        "difficulty_rules": [],
        "question_generation_rules": [],
        "answer_evaluation_rules": [],
        "teaching_planning_rules": [],
    },
}
material = {
    "title": "Python 默认参数",
    "content": (
        "函数默认参数在函数定义时求值一次。可变对象作为默认值时，多次调用会共享同一对象。"
        "通常使用 None 作为默认值，并在函数体内创建新对象。"
    ),
    "source": "Python 官方文档",
    "url": "https://docs.python.org/zh-cn/3/tutorial/controlflow.html#default-argument-values",
}

with tempfile.TemporaryDirectory() as directory:
    memory_path = Path(directory) / "capability_memory.json"
    memory_path.write_text(json.dumps(EMPTY_MEMORY, ensure_ascii=False), encoding="utf-8")
    student = StudentAgent(memory_path=memory_path)
    outputs = []
    original_process = student.process

    def record_process(value):
        result = original_process(value)
        outputs.append(copy.deepcopy(result))
        return result

    student.process = record_process
    training = TeacherTrainingLoop(
        student, TeacherTrainerEvaluator(TeacherAgent())
    ).train_once(material)
    before, after = outputs
    behavior_rules = student.capability_memory["behavior_rules"]
    assert any(behavior_rules.values()), "Gemini feedback 没有转换为 behavior_rules"
    assert before != after, "第二次生成结果没有变化"
    assert len(after["questions"]) != len(before["questions"]) or after["evaluation_ability"] != before["evaluation_ability"], (
        "behavior_rules 没有影响问题或评价行为"
    )
    print(json.dumps({
        "feedback": training["feedback"],
        "behavior_rules": behavior_rules,
        "before": before,
        "after": after,
    }, ensure_ascii=False, indent=2))
