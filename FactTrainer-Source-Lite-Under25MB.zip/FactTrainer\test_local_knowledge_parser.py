"""Acceptance test: raw text becomes an offline graph before optional Gemini enhancement."""

import json
import tempfile
from pathlib import Path

from agent.agent import Agent
from core.knowledge_parser import LocalKnowledgeParser
from pipeline.knowledge_pipeline import KnowledgePipeline
from teacher.teacher_agent import TeacherAgent


TEXT = "Python变量用于保存数据，动态类型机制减少提前声明类型的需求。"


def main() -> None:
    parser = LocalKnowledgeParser()
    assert parser.sentence_split(TEXT) == [
        "Python变量用于保存数据",
        "动态类型机制减少提前声明类型的需求",
    ]
    graph = parser.build_knowledge_graph(TEXT)
    concept_names = [item["name"] for item in graph["concepts"]]
    relation_triples = {
        (item["source"], item["relation"], item["target"])
        for item in graph["relations"]
    }
    assert {"Python变量", "数据", "动态类型机制", "类型声明"} <= set(concept_names)
    assert ("Python变量", "保存", "数据") in relation_triples
    assert ("动态类型机制", "减少", "提前声明类型需求") in relation_triples

    document = {
        "title": "Python变量与动态类型",
        "content": TEXT,
        "url": "local://parser-test",
        "source": "本地测试材料",
    }
    with tempfile.TemporaryDirectory() as directory:
        knowledge_json, knowledge_base = KnowledgePipeline(
            TeacherAgent(api_key=""), Path(directory)
        ).process(document, "Python")
        saved = knowledge_base.get_all()[0]
        assert saved["concepts"] and saved["relations"]
        assert saved["content"] != TEXT

        agent = Agent("本地拆解测试", "Python")
        agent.learn(
            saved["topic"], saved["content"], saved["level"],
            saved["keywords"], saved,
        )
        assert agent.knowledge_graph["concepts"]
        assert agent.knowledge_graph["relations"]

    print(json.dumps({
        "input": TEXT,
        "sentences": parser.sentence_split(TEXT),
        "graph": graph,
        "saved_knowledge": knowledge_json["knowledge_points"][0],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
