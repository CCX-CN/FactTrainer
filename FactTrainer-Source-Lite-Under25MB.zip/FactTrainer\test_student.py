import json

from student.student_agent import StudentAgent


material = {
    "title": "Python 函数定义",
    "content": (
        "Python 使用 def 关键字定义函数，def 后跟函数名和圆括号中的形参列表。"
        "函数体从下一行开始并且必须缩进。return 语句用于从函数返回一个值；"
        "没有 return 的函数也会返回 None。"
    ),
    "source": "Python 官方文档",
    "url": "https://docs.python.org/zh-cn/3/tutorial/controlflow.html#defining-functions",
}

result = StudentAgent().process(material)
assert result["knowledge_points"], "未输出知识点"
assert set(result["difficulty_levels"]) == {"basic", "intermediate", "advanced"}
assert result["questions"], "未输出问题"
print(json.dumps(result, ensure_ascii=False, indent=2))
