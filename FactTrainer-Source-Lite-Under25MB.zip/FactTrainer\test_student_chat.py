# -*- coding: utf-8 -*-
import json

from student.student_agent import StudentAgent


def main() -> None:
    student = StudentAgent()
    print("=" * 20)
    print("Student Agent Chat")
    print("输入学习材料，输入 exit 退出")
    print("=" * 20)

    while True:
        try:
            material = input("\n学习材料：").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n已退出。")
            break

        if material.casefold() == "exit":
            print("已退出。")
            break
        if not material:
            continue

        try:
            result = student.process(material)
            teaching_content = student.runtime.presenter.render(result)
        except Exception as error:
            print(f"处理失败：{error}")
            continue

        print("\nsummary：")
        print(result["summary"])
        print("\nknowledge_points：")
        print(json.dumps(result["knowledge_points"], ensure_ascii=False, indent=2))
        print("\nquestions：")
        print(json.dumps(result["questions"], ensure_ascii=False, indent=2))
        print("\nteaching_content：")
        print(teaching_content)


if __name__ == "__main__":
    main()
