import json
import os
import tempfile
from pathlib import Path
from unittest.mock import patch

from student.runtime import StudentRuntime
from student.student_agent import StudentAgent
from teacher.teacher_agent import TeacherAgent
from training.evaluator import TeacherTrainerEvaluator
from training.training_loop import TeacherTrainingLoop


source_memory = Path("student/capability_memory.json")
training_material = {
    "content": "Python 列表是可变序列。索引用于访问元素。切片用于取得子序列。修改列表会改变原对象。"
}
deployment_material = {
    "content": (
        "Python 生成器函数使用 yield 产生值。每次恢复时从上次暂停位置继续执行。"
        "生成器按需产生数据，因此不必预先保存全部结果。生成器也是迭代器，可用于 for 循环。"
    )
}

with tempfile.TemporaryDirectory() as directory:
    memory_path = Path(directory) / "capability_memory.json"
    memory_path.write_text(source_memory.read_text(encoding="utf-8"), encoding="utf-8")

    student = StudentAgent(memory_path=memory_path)
    TeacherTrainingLoop(student, TeacherTrainerEvaluator(TeacherAgent())).train_once(training_material)

    os.environ.pop("GEMINI_API_KEY", None)
    with patch("socket.socket.connect", side_effect=AssertionError("部署阶段禁止网络连接")):
        runtime = StudentRuntime(memory_path)
        result = runtime.process(deployment_material)
        teaching_content = runtime.teach(deployment_material)

    assert result["summary"]
    assert result["knowledge_points"]
    assert set(result["difficulty_levels"]) == {"basic", "intermediate", "advanced"}
    assert result["questions"]
    assert result["evaluation_ability"]
    assert result["teaching_plan"]
    assert teaching_content
    print(json.dumps({"graduated": True, "result": result, "teaching_content": teaching_content}, ensure_ascii=False, indent=2))
