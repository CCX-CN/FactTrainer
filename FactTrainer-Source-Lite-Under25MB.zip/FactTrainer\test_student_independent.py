import json

from student.student_agent import StudentAgent


material = {
    "title": "Python 上下文管理器与 with 语句",
    "content": (
        "with 语句用于包装上下文管理器定义的方法执行代码块。进入代码块时，"
        "上下文管理器的 __enter__ 方法被调用；离开代码块时，__exit__ 方法被调用。"
        "即使代码块因异常退出，__exit__ 仍会执行，因此 with 常用于可靠地释放文件等资源。"
    ),
    "source": "Python 官方语言参考",
    "url": "https://docs.python.org/zh-cn/3/reference/compound_stmts.html#the-with-statement",
}

student = StudentAgent()
memory = student.capability_memory
assert memory["learned_rules"], "capability_memory.json 尚无已学习规则"
assert any(score > 0 for score in memory["abilities"].values()), "Student 尚未获得能力提升"

result = student.process(material)
assert result["knowledge_points"], "未输出 knowledge_points"
assert set(result["difficulty_levels"]) == {"basic", "intermediate", "advanced"}
assert result["questions"], "未输出 questions"
assert result["evaluation_ability"].strip(), "未输出 evaluation_ability"

print(json.dumps(result, ensure_ascii=False, indent=2))
