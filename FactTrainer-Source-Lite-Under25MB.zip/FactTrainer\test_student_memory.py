import json

from student.student_agent import StudentAgent
from teacher.teacher_agent import TeacherAgent
from training.evaluator import TeacherTrainerEvaluator
from training.training_loop import TeacherTrainingLoop


material = {
    "title": "Python 可变默认参数",
    "content": (
        "函数默认参数只在函数定义时求值一次。如果列表等可变对象被用作默认值，"
        "多次调用可能共享并累积同一个对象的修改。常用做法是以 None 作为默认值，"
        "并在函数体内创建新列表。"
    ),
    "source": "Python 官方文档",
    "url": "https://docs.python.org/zh-cn/3/tutorial/controlflow.html#default-argument-values",
}

first_student = StudentAgent()
memory_items_before = sum(
    len(first_student.capability_memory[field])
    for field in ("learned_rules", "teaching_methods")
)
training_result = TeacherTrainingLoop(
    first_student, TeacherTrainerEvaluator(TeacherAgent())
).train_once(material)
assert sum(
    len(first_student.capability_memory[field])
    for field in ("learned_rules", "teaching_methods")
) > memory_items_before

second_student = StudentAgent()
assert second_student.capability_memory == first_student.capability_memory
independent_result = second_student.process(material)
assert independent_result["knowledge_points"]
assert independent_result["questions"]

print(json.dumps({
    "training": training_result,
    "saved_memory": second_student.capability_memory,
    "independent_result": independent_result,
}, ensure_ascii=False, indent=2))
