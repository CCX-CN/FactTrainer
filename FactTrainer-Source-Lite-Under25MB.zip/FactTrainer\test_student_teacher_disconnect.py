import json

from student.student_agent import StudentAgent


material = {
    "title": "Python 迭代器协议",
    "content": (
        "迭代器对象需要实现 __iter__ 和 __next__ 方法。__iter__ 返回迭代器对象本身，"
        "__next__ 返回序列中的下一个元素。当没有更多元素时，__next__ 必须抛出 "
        "StopIteration。for 语句会调用 iter() 获得迭代器，并不断调用 next()，直到捕获 "
        "StopIteration 后结束循环。"
    ),
    "source": "Python 官方教程",
    "url": "https://docs.python.org/zh-cn/3/tutorial/classes.html#iterators",
}

student = StudentAgent()
memory = student.capability_memory
memory_used = bool(memory["learned_rules"]) and any(
    value > 0 for value in memory["abilities"].values()
)
assert memory_used, "Capability Memory 中没有可供 Student 使用的训练成果"

result = student.process(material)

# 核心知识提取能力
assert isinstance(result["knowledge_points"], list) and result["knowledge_points"], (
    "Student 未提取核心知识"
)

# 知识难度分层能力
levels = result["difficulty_levels"]
assert set(levels) == {"basic", "intermediate", "advanced"}, "知识难度层级不完整"
assert all(isinstance(levels[level], list) for level in levels), "知识难度层级格式错误"
assert any(levels[level] for level in levels), "Student 未进行知识分层"

# 多角度出题能力
questions = result["questions"]
assert isinstance(questions, list) and len(questions) >= 2, "Student 生成的问题不足"
question_types = {
    question.get("type", "").strip()
    for question in questions
    if isinstance(question, dict) and question.get("type")
}
assert len(question_types) >= 2, "Student 未生成多角度问题"

# 答案评价能力
assert isinstance(result["evaluation_ability"], str) and result["evaluation_ability"].strip(), (
    "Student 未展示答案评价能力"
)

print(json.dumps({
    "teacher_used": False,
    "memory_used": True,
    "result": result,
}, ensure_ascii=False, indent=2))
