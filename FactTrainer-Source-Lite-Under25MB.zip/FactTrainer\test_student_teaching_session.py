# -*- coding: utf-8 -*-
import json

from student.student_agent import StudentAgent


material = (
    "牛顿第二定律说明物体加速度与所受合力成正比，与质量成反比。"
    "合力方向决定加速度方向，关系式为F=ma。"
)
student_answer = "质量越大的物体受到相同力时加速度越大，因为质量代表力量大小。"

student = StudentAgent()
lesson = student.process(material)
knowledge_point = lesson["knowledge_points"][0]
evaluation = student.evaluate_student(knowledge_point, student_answer)

assert evaluation["understanding_level"] == "wrong"
assert evaluation["misconceptions"], "必须识别具体错误概念"
assert evaluation["teaching_strategy"], "必须提供针对性教学调整"
assert evaluation["next_question"], "必须生成后续检测题"
assert "关键词不足" not in json.dumps(evaluation, ensure_ascii=False)

print(json.dumps({
    "knowledge_point": knowledge_point,
    "student_answer": student_answer,
    "evaluation": evaluation,
}, ensure_ascii=False, indent=2))
