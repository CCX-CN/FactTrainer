import json

from student.student_agent import StudentAgent
from teacher.teacher_agent import TeacherAgent
from training.evaluator import TeacherTrainerEvaluator
from training.training_loop import TeacherTrainingLoop


material = {
    "title": "Python 函数参数与返回值",
    "content": (
        "Python 使用 def 定义函数，函数名后的圆括号中是形参列表。调用函数时，"
        "实参会绑定到形参。位置参数按照顺序绑定，关键字参数按照参数名绑定。"
        "return 语句结束当前函数调用并返回一个值；没有显式 return 时函数返回 None。"
        "函数体必须缩进。"
    ),
    "source": "Python 官方文档",
    "url": "https://docs.python.org/zh-cn/3/tutorial/controlflow.html#defining-functions",
}

loop = TeacherTrainingLoop(
    StudentAgent(),
    TeacherTrainerEvaluator(TeacherAgent()),
)
result = loop.train_once(material)
assert 0 <= result["before_score"] <= 100
assert 0 <= result["after_score"] <= 100
assert set(result["feedback"]) == {"score", "strengths", "weaknesses", "improvement"}
print(json.dumps(result, ensure_ascii=False, indent=2))
