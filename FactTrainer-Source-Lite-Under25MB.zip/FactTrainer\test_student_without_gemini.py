import ast
import json
import os
from pathlib import Path
from unittest.mock import patch

from student.runtime import StudentRuntime


runtime_source = Path("student/runtime.py").read_text(encoding="utf-8")
imports = [node for node in ast.walk(ast.parse(runtime_source)) if isinstance(node, (ast.Import, ast.ImportFrom))]
for node in imports:
    text = ast.unparse(node).lower()
    assert "gemini" not in text and "teacher" not in text and "urllib" not in text, f"禁止的运行时导入: {text}"

os.environ.pop("GEMINI_API_KEY", None)
material = {
    "content": (
        "上下文管理器定义 __enter__ 和 __exit__ 方法。with 语句进入代码块时调用 __enter__。"
        "离开代码块时调用 __exit__。即使发生异常，__exit__ 仍会执行，因此可以可靠释放资源。"
    )
}
with patch("socket.socket.connect", side_effect=AssertionError("部署阶段禁止网络连接")):
    runtime = StudentRuntime()
    result = runtime.process(material)
    teaching_content = runtime.teach(material)

assert result["knowledge_points"]
assert result["difficulty_levels"]
assert result["questions"]
assert result["evaluation_ability"]
assert result["teaching_plan"]
assert teaching_content
print(json.dumps({"gemini_used": False, "result": result, "teaching_content": teaching_content}, ensure_ascii=False, indent=2))
