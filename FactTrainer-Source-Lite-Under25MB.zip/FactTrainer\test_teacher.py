from teacher.teacher_agent import TeacherAgent


document = {
    "title": "Python 函数定义",
    "content": "Python 使用 def 关键字定义函数。函数体从下一行开始并且必须缩进。return 语句用于返回函数值。",
    "url": "https://docs.python.org/zh-cn/3/tutorial/controlflow.html#defining-functions",
    "source": "Python 官方文档",
}

result = TeacherAgent().process(document)
assert result.get("knowledge_points"), "未生成知识点"
assert result.get("questions"), "未生成问题"
assert all(point.get("title") and "知识点" not in point["title"] for point in result["knowledge_points"])
assert all(point.get("concept") for point in result["knowledge_points"])
print(result)
