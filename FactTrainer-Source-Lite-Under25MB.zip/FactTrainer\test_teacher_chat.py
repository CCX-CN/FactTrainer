from student.student_agent import StudentAgent


def display(result: dict) -> None:
    print("\n知识总结")
    print(result.get("summary", "暂无总结"))

    print("\n知识难度分类")
    labels = {"basic": "基础", "intermediate": "进阶", "advanced": "高级"}
    for level in ("basic", "intermediate", "advanced"):
        topics = result["difficulty_levels"].get(level, [])
        print(f"{labels[level]}：{'、'.join(topics) if topics else '暂无'}")

    print("\n知识解释与示例")
    for point in result["knowledge_points"]:
        print(f"\n【{point['title']}】")
        print(f"概念：{point.get('concept', '')}")
        print(f"解释：{point.get('explanation', '')}")
        if point.get("mechanism"):
            print(f"核心机制：{point['mechanism']}")
        if point.get("example"):
            print(f"示例：{point['example']}")

    print("\n多角度问题")
    for index, question in enumerate(result["questions"], 1):
        print(f"{index}. [{question.get('type', '练习')}] {question.get('question', '')}")
        print(f"   答案解释：{question.get('answer', '')}")

    print("\n答案评价")
    print(result.get("evaluation_ability", "暂无评价标准"))
    print()


def main() -> None:
    print("====================")
    print("Teacher Agent Test")
    print("输入 exit 退出")
    print("====================")
    agent = StudentAgent()

    while True:
        try:
            user_input = input("\n请输入学习材料、知识问题或需要解释的内容：").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n已退出")
            break
        if user_input.casefold() == "exit":
            print("已退出")
            break
        if not user_input:
            continue
        display(agent.process(user_input))


if __name__ == "__main__":
    main()
