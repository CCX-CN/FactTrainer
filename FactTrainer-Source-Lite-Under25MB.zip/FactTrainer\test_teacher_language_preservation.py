import json
import tempfile
import unittest
from pathlib import Path

from teacher.teacher_agent import TeacherAgent


class CapturingTeacher(TeacherAgent):
    def _generate(self, text: str) -> str:
        self.generated_prompt = text
        return json.dumps({
            "title": "Cat nutrition",
            "summary": "Cats require nutrients from animal-based food.",
            "knowledge_points": [{
                "title": "Taurine requirement",
                "concept": "Taurine is an essential nutrient for cats.",
                "content": "Cats need taurine to support eye and heart health.",
                "principle": "Taurine deficiency can harm eye and heart health.",
                "keywords": ["cats", "taurine", "eye health", "heart health"],
                "difficulty": "beginner",
                "importance": "high",
            }],
            "questions": [{
                "question": "Why is taurine important for cats?",
                "answer": "It supports eye and heart health.",
                "type": "understanding",
                "difficulty": "beginner",
            }],
            "source": {"title": "Cat nutrition", "url": "https://example.org/cats"},
        })


class TeacherLanguagePreservationTest(unittest.TestCase):
    def test_english_material_requires_english_output(self):
        with tempfile.TemporaryDirectory() as directory:
            teacher = CapturingTeacher(api_key="test", memory_path=Path(directory) / "memory.json")
            result = teacher.process({
                "title": "Cat nutrition",
                "content": "Cats require taurine from animal-based food. Taurine supports eye and heart health.",
                "url": "https://example.org/cats",
                "source": "Example",
            })
        self.assertIn("Do not translate the material into Chinese", teacher.generated_prompt)
        self.assertEqual(result["title"], "Cat nutrition")
        self.assertEqual(result["questions"][0]["question"], "Why is taurine important for cats?")


if __name__ == "__main__":
    unittest.main()
