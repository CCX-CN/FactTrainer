from teacher.teacher_agent import TeacherAgent


TOPIC = "牛顿第二定律"

try:
    document, knowledge = TeacherAgent().process_topic(TOPIC)
except Exception as error:
    raise SystemExit(f"Teacher 搜索处理失败：{error}") from error

assert document.get("title"), "搜索结果缺少标题"
assert document.get("content"), "搜索结果缺少内容"
assert document.get("url"), "搜索结果缺少 URL"
assert knowledge.get("knowledge_points"), "Teacher 未生成知识点"
assert knowledge.get("questions"), "Teacher 未生成问题"

print("获取资料：")
print({"title": document["title"], "url": document["url"], "source": document["source"]})
print("生成知识结构：")
print(knowledge)
