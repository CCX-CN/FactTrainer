import unittest

from teacher.teacher_agent import TeacherAgent


class TeacherSourceQualityTest(unittest.TestCase):
    def test_official_complete_source_wins(self) -> None:
        topic = "牛顿第二定律"
        official = {
            "title": "牛顿第二定律",
            "content": (
                "牛顿第二定律是经典力学定律，表示物体加速度与合力成正比、与质量成反比。"
                "它说明力、质量与加速度之间的关系。例如，相同力作用下质量较小的物体加速度更大。"
            ),
            "url": "https://zh.wikipedia.org/wiki/牛顿第二定律",
            "source": "Wikipedia",
        }
        blog = {
            "title": "牛顿第二定律学习笔记",
            "content": "牛顿第二定律说明力和运动有关。这是一篇个人学习记录。",
            "url": "https://random-blog.example/post/2",
            "source": "个人博客",
        }
        empty = {
            "title": "牛顿第二定律",
            "content": "",
            "url": "https://example.com/empty",
            "source": "未知网页",
        }

        official_score = TeacherAgent._score_document(topic, official)
        blog_score = TeacherAgent._score_document(topic, blog)
        empty_score = TeacherAgent._score_document(topic, empty)

        self.assertGreater(official_score, blog_score)
        self.assertGreater(blog_score, empty_score)
        self.assertIs(TeacherAgent._select_document(topic, [blog, empty, official]), official)


if __name__ == "__main__":
    unittest.main(verbosity=2)
