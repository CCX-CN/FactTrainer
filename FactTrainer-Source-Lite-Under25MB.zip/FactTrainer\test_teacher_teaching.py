import json
import tempfile
import unittest
from pathlib import Path

from teacher.teacher_agent import TeacherAgent


class DeterministicTeacher(TeacherAgent):
    """Exercises Teacher-owned logic without exposing or calling Gemini."""

    def __init__(self, responses: list[dict], memory_path: Path) -> None:
        self.prompt = "Teacher"
        self.memory_path = memory_path
        self.memory = self._load_memory()
        self.responses = [json.dumps(item, ensure_ascii=False) for item in responses]

    def _generate(self, text: str) -> str:
        return self.responses.pop(0)


class TeacherTeachingTest(unittest.TestCase):
    def test_teaching_package_grading_and_feedback_memory(self) -> None:
        package = {
            "title": "牛顿第二定律",
            "summary": "力、质量与加速度的关系。",
            "knowledge_points": [{
                "title": "牛顿第二定律",
                "concept": "F=ma",
                "content": "合力等于质量与加速度的乘积。",
                "keywords": ["合力", "质量", "加速度"],
                "difficulty": "beginner",
                "importance": "high",
            }],
            "questions": [{
                "question": "同一合力作用于不同质量物体时，加速度如何变化？",
                "answer": "合力相同时，质量越大，加速度越小。",
                "type": "deep_understanding",
                "difficulty": "intermediate",
            }],
            "source": {"title": "教材", "url": "https://example.edu/source"},
        }
        assessment = {
            "score": 45,
            "understanding_level": "partial",
            "missing_knowledge": ["质量与加速度成反比"],
            "error_type": ["因果关系颠倒"],
            "reasoning_analysis": "回答知道力和加速度有关，但把质量的作用说反了。",
            "improvement_direction": "用相同合力、不同质量的对比例子复习质量对加速度的影响。",
        }
        with tempfile.TemporaryDirectory() as directory:
            teacher = DeterministicTeacher([package, assessment], Path(directory) / "teacher_memory.json")
            document = {"title": "牛顿第二定律", "content": "合力等于质量乘以加速度。", "url": "https://example.edu/source", "source": "University"}
            result = teacher.process(document)
            point = result["knowledge_points"][0]
            question = result["questions"][0]
            self.assertEqual(point["prerequisites"], [])
            self.assertIn("key_understandings", point)
            self.assertIn("common_errors", point)
            self.assertIn("applications", point)
            self.assertIn("must_include", question)
            self.assertIn("scoring_criteria", question)
            self.assertIn("common_wrong_answers", question)

            graded = teacher.grade_answer(question["question"], question["answer"], question["scoring_criteria"], "质量越大加速度越大。")
            feedback = teacher.teaching_feedback(graded, point)
            self.assertEqual(graded["understanding_level"], "partial")
            self.assertEqual(feedback["next_step"], "review_and_retest")
            self.assertIn("因果关系颠倒", teacher.memory["common_error_patterns"])
            self.assertTrue(teacher.memory["evaluation_rules"])
            self.assertTrue(teacher.memory["pending_rules"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
