import re
import unittest

from teacher.teacher_agent import TeacherAgent


class SelectionOnlyTeacher(TeacherAgent):
    """Skip Gemini so this test measures only search-result selection."""

    def __init__(self) -> None:
        super().__init__(api_key="selection-test-only")

    def process(self, document: dict) -> dict:
        return {"selected_title": document["title"]}


class TeacherTopicSelectionTest(unittest.TestCase):
    def setUp(self) -> None:
        self.teacher = SelectionOnlyTeacher()

    @staticmethod
    def assert_topic_related(topic: str, document: dict) -> None:
        normalized_topic = re.sub(r"\s+", "", topic).casefold()
        searchable = re.sub(
            r"\s+", "", document["title"] + document["content"]
        ).casefold()
        terms = {
            normalized_topic[index:index + 2]
            for index in range(max(1, len(normalized_topic) - 1))
        }
        if len(normalized_topic) < 2:
            terms = {normalized_topic}
        assert normalized_topic in searchable or any(term in searchable for term in terms), (
            f"资料与主题不相关：{topic} -> {document['title']}"
        )

    def test_newtons_third_law(self) -> None:
        document, _ = self.teacher.process_topic("牛顿第三定律")
        self.assert_topic_related("牛顿第三定律", document)
        self.assertNotIn("牛顿第一定律", document["title"])
        self.assertNotIn("牛顿第二定律", document["title"])

    def test_python_generator(self) -> None:
        document, _ = self.teacher.process_topic("Python生成器")
        self.assert_topic_related("Python生成器", document)

    def test_photosynthesis(self) -> None:
        document, _ = self.teacher.process_topic("光合作用")
        self.assert_topic_related("光合作用", document)

    def test_nonexistent_topic_fails_clearly(self) -> None:
        fake_topic = "不存在概念甲乙丙丁戊己FactTrainer999999"
        with self.assertRaisesRegex(RuntimeError, "未找到"):
            self.teacher.process_topic(fake_topic)


if __name__ == "__main__":
    unittest.main(verbosity=2)
