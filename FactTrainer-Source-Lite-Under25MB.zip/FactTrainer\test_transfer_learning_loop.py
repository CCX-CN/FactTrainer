"""Verify structured learning, cognitive coverage and paraphrased retrieval."""

import json
import tempfile
from pathlib import Path

from agent.agent import Agent
from knowledge.knowledge_base import KnowledgeBase
from questions.question_generator import QuestionGenerator
from training.evaluator import Evaluator
from training.trainer import Trainer


def main() -> None:
    knowledge = [{
        "topic": "Python列表零基索引",
        "concept": "列表位置编号从0开始",
        "content": "Python列表是有序序列，第一个元素的索引为0。",
        "explanation": "Python列表是有序序列，第一个元素的索引为0。",
        "principle": "零基索引把序列起点映射到数字0，后续位置依次增加。",
        "prerequisites": ["列表", "顺序"],
        "key_understandings": ["位置编号与元素顺序相差1"],
        "applications": ["按照元素所在位置读取列表数据"],
        "common_errors": ["把索引1误认为第一个元素"],
        "examples": ["items[0]读取第一个元素"],
        "keywords": ["列表", "索引", "零基"],
        "level": "basic",
    }]
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "knowledge.json"
        path.write_text(json.dumps(knowledge, ensure_ascii=False), encoding="utf-8")
        base = KnowledgeBase(path)
        base.load()
        agent = Agent("迁移测试", "Python")
        assert agent.answer_text("序列开头的位置编号是多少？") == Agent.UNKNOWN_ANSWER
        result = Trainer(agent, base, QuestionGenerator(base), Evaluator()).train_once()
        answer = agent.answer_text("为什么读取列表开头的数据时位置编号要写成零？")

    types = {record["question_type"] for record in result["records"]}
    print(json.dumps({
        "before_score": result["before_score"],
        "after_score": result["after_score"],
        "question_types": sorted(types),
        "learned_structure": agent.knowledge_structures["Python列表零基索引"],
        "paraphrased_answer": answer,
    }, ensure_ascii=False, indent=2))
    assert types == {"memory", "understanding", "application", "reasoning"}
    assert "序列起点映射到数字0" in answer
    assert agent.learning_gaps == {}


if __name__ == "__main__":
    main()
