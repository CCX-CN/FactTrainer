import json
import math
import re
from collections import Counter
from typing import Any

from teacher.teacher_agent import TeacherAgent


def feedback_to_behavior_rules(feedback: dict) -> dict[str, list[str]]:
    """把 Teacher 的改进建议转换为 Student 可直接执行的行为规则。"""
    rules = {
        "knowledge_extraction_rules": [],
        "difficulty_rules": [],
        "question_generation_rules": [],
        "answer_evaluation_rules": [],
        "teaching_planning_rules": [],
    }
    feedback_items = [
        str(item).strip()
        for field in ("weaknesses", "improvement")
        for item in feedback.get(field, [])
        if str(item).strip()
    ]
    for text in feedback_items:
        if any(term in text for term in ("标题", "命名", "概念名", "专业术语", "连接词")):
            rules["knowledge_extraction_rules"].append(
                "知识点标题必须使用材料中的专业概念名词，不允许保留原文连接词、句式片段或编号"
            )
        if any(term in text for term in ("知识提取", "提取", "知识点", "核心概念", "核心机制", "概念解释")):
            rules["knowledge_extraction_rules"].append(
                "每个知识点必须分别写明专业概念名称、核心机制和完整解释，不能只截取或改写原句"
            )

        if any(term in text for term in ("难度", "分层", "层级", "基础", "进阶", "高级")):
            rules["difficulty_rules"].append(
                "难度必须按认知要求判断：定义和前置概念为基础，机制与关系分析为进阶，综合应用、边界条件和错误诊断为高级"
            )
            rules["difficulty_rules"].append(
                "同一知识点不得为填满层级而重复分类，每个难度判断必须能由题目要求或知识复杂度解释"
            )

        if any(term in text for term in ("应用", "场景", "实际问题")):
            rules["question_generation_rules"].append(
                "应用题必须要求学生预测结果、解释原因或解决实际问题，不能只是改写概念定义"
            )
        if any(term in text for term in ("推理", "原理", "分析", "为什么", "因果")):
            rules["question_generation_rules"].append(
                "推理题必须给出条件或现象，要求学生依据核心机制推导结果并解释因果链"
            )
        if any(term in text for term in ("多角度", "多个角度", "题型", "问题生成", "提问", "错误分析")):
            rules["question_generation_rules"].append(
                "每个核心知识点至少生成概念理解、原理推理、应用场景和错误诊断四种不同认知任务"
            )

        if any(term in text for term in ("评价", "评分", "答案", "遗漏", "关键词", "正确性")):
            rules["answer_evaluation_rules"].append(
                "答案评价必须分别检查结论正确性、核心机制、必要关键词和关键遗漏，并指出错误发生在哪一步"
            )
            rules["answer_evaluation_rules"].append(
                "不能仅按关键词命中判定正确；结论正确但原因错误或缺少因果解释时不得视为完全掌握"
            )

        if any(term in text for term in ("教学", "学习顺序", "教学顺序", "计划", "下一步", "前置")):
            rules["teaching_planning_rules"].append(
                "教学计划必须先安排前置概念，再讲核心机制，最后进行应用与错误诊断；下一步内容必须针对当前遗漏选择"
            )
    return {key: list(dict.fromkeys(value)) for key, value in rules.items()}


class Evaluator:
    def evaluate(
        self,
        question: str,
        expected_answer: str,
        agent_answer: str,
        keywords: list[str],
        criteria: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Evaluate required knowledge dimensions, not a memorized answer string."""
        dimensions = {
            name: str(value).strip()
            for name, value in (criteria or {"concept": expected_answer}).items()
            if str(value).strip()
        }
        coverage = {
            name: self._semantic_coverage(agent_answer, value)
            for name, value in dimensions.items()
        }
        missing_dimensions = [name for name, value in coverage.items() if value < 0.45]
        score = round(sum(coverage.values()) / len(coverage) * 100) if coverage else 0
        missing_keywords = [
            keyword for keyword in keywords
            if self._semantic_coverage(agent_answer, keyword) < 0.45
        ]
        feedback = (
            "需要补充知识维度：" + "、".join(missing_dimensions)
            if missing_dimensions else "回答已覆盖本题要求的知识维度。"
        )

        return {
            "score": score,
            "missing_keywords": missing_keywords,
            "missing_dimensions": missing_dimensions,
            "dimension_coverage": {key: round(value, 3) for key, value in coverage.items()},
            "feedback": feedback,
        }

    @staticmethod
    def _semantic_coverage(answer: str, expected: str) -> float:
        """Measure relation coverage with word and character n-gram vectors."""
        def features(text: str) -> Counter:
            normalized = text.casefold()
            words = re.findall(r"[a-z_][a-z0-9_]*|\d+(?:\.\d+)?", normalized)

            def stem(word: str) -> str:
                if len(word) > 5 and word.endswith("ing"):
                    return word[:-3]
                if len(word) > 4 and word.endswith("ed"):
                    return word[:-2]
                if len(word) > 4 and word.endswith("es"):
                    return word[:-2]
                if len(word) > 3 and word.endswith("s"):
                    return word[:-1]
                return word

            words = [stem(word) for word in words]
            chinese = "".join(re.findall(r"[\u4e00-\u9fff]", normalized))
            grams = [chinese[i:i + 2] for i in range(max(0, len(chinese) - 1))]
            return Counter([*words, *grams])

        actual, target = features(answer), features(expected)
        if not target or not actual:
            return 0.0
        dot = sum(actual[key] * target.get(key, 0) for key in actual)
        cosine = dot / (
            math.sqrt(sum(value * value for value in actual.values()))
            * math.sqrt(sum(value * value for value in target.values()))
        )
        covered = sum(min(value, actual.get(key, 0)) for key, value in target.items()) / sum(target.values())
        return min(1.0, cosine * 0.35 + covered * 0.65)


class TeacherTrainerEvaluator:
    """使用现有 Teacher Agent 的推理能力评价 Student 的教学能力。"""

    def __init__(self, teacher: TeacherAgent) -> None:
        self.teacher = teacher

    def evaluate(self, material: str | dict, student_output: dict) -> dict[str, Any]:
        prompt = (
            self.teacher.prompt
            + "\n\n你现在负责训练 Student Agent。请依据学习材料评价 Student 输出。"
            + "必须分别检查：知识提取能力、知识分层能力、问题生成能力、"
            + "多角度提问能力、答案评价能力。"
            + "只输出合法 JSON，格式严格为："
            + '{"score":0,"strengths":[],"weaknesses":[],"improvement":[]}'
            + "。score 必须是 0 到 100 的整数；反馈必须具体、可执行，不得虚构材料外事实。"
            + "\n\n学习材料：\n"
            + self._serialize(material)
            + "\n\nStudent 输出：\n"
            + json.dumps(student_output, ensure_ascii=False)
        )
        feedback = self._parse_json(self.teacher._generate(prompt))
        self._validate(feedback)
        return feedback

    @staticmethod
    def _serialize(value: str | dict) -> str:
        return json.dumps(value, ensure_ascii=False) if isinstance(value, dict) else value

    @staticmethod
    def _parse_json(text: str) -> dict:
        cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip(), flags=re.I)
        result = json.loads(cleaned)
        if not isinstance(result, dict):
            raise ValueError("Teacher Trainer 返回值必须是 JSON 对象")
        return result

    @staticmethod
    def _validate(feedback: dict) -> None:
        required = {"score", "strengths", "weaknesses", "improvement"}
        if required - feedback.keys():
            raise ValueError("Teacher Trainer 反馈字段不完整")
        score = feedback["score"]
        if isinstance(score, bool) or not isinstance(score, (int, float)) or not 0 <= score <= 100:
            raise ValueError("Teacher Trainer 分数必须在 0 到 100 之间")
        for field in ("strengths", "weaknesses", "improvement"):
            if not isinstance(feedback[field], list):
                raise ValueError(f"{field} 必须是列表")
