from collections import defaultdict
from datetime import datetime
from typing import Any

from agent.agent import Agent
from knowledge.knowledge_base import KnowledgeBase
from questions.question_generator import QuestionGenerator
from training.evaluator import Evaluator


class Trainer:
    def __init__(self, agent: Agent, knowledge_base: KnowledgeBase,
                 question_generator: QuestionGenerator, evaluator: Evaluator) -> None:
        self.agent = agent
        self.knowledge_base = knowledge_base
        self.question_generator = question_generator
        self.evaluator = evaluator

    def train_once(self) -> dict[str, Any]:
        questions = self.question_generator.generate()
        knowledge_by_topic = {item["topic"]: item for item in self.knowledge_base.get_all()}
        before_results = []
        records: list[dict[str, Any]] = []
        gaps: dict[str, list[str]] = defaultdict(list)

        # Diagnose memory, understanding, application and reasoning before teaching.
        for item in questions:
            answer = self.agent.answer_text(item["question"])
            result = self.evaluator.evaluate(
                item["question"], item["expected_answer"], answer,
                item["knowledge"].get("keywords", []), item.get("criteria"),
            )
            before_results.append((item, answer, result))
            gaps[item["topic"]].extend(result["missing_dimensions"])

        # Wrong answers trigger supplementation with the complete transferable structure.
        for topic, missing in gaps.items():
            knowledge = knowledge_by_topic[topic]
            self.agent.supplement_knowledge(topic, missing, knowledge)

        for item, answer_before, result_before in before_results:
            answer_after = self.agent.answer_text(item["question"])
            result_after = self.evaluator.evaluate(
                item["question"], item["expected_answer"], answer_after,
                item["knowledge"].get("keywords", []), item.get("criteria"),
            )
            records.append({
                "time": datetime.now().isoformat(timespec="seconds"),
                "question": item["question"], "question_type": item["type"],
                "topic": item["topic"], "level": item["level"],
                "answer_before": answer_before, "score_before": result_before["score"],
                "missing_knowledge": result_before["missing_dimensions"],
                "missing_keywords": result_before["missing_dimensions"],
                "answer_after": answer_after, "score_after": result_after["score"],
            })

        scores_by_topic: dict[str, list[int]] = defaultdict(list)
        for record in records:
            scores_by_topic[record["topic"]].append(record["score_after"])
        for topic, scores in scores_by_topic.items():
            knowledge = knowledge_by_topic[topic]
            self.agent.update_mastery(topic, knowledge.get("level", "basic"), round(sum(scores) / len(scores)))

        before_score = round(sum(r["score_before"] for r in records) / len(records)) if records else self.agent.score
        after_score = round(sum(r["score_after"] for r in records) / len(records)) if records else before_score
        self.agent.update_score(after_score)
        return {"before_score": before_score, "after_score": after_score, "records": records}
