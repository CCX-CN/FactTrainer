from typing import Any

from student.student_agent import StudentAgent
from training.evaluator import TeacherTrainerEvaluator, feedback_to_behavior_rules


class TeacherTrainingLoop:
    def __init__(self, student: StudentAgent, evaluator: TeacherTrainerEvaluator) -> None:
        self.student = student
        self.evaluator = evaluator

    def train_once(self, material: str | dict) -> dict[str, Any]:
        before_output = self.student.process(material)
        feedback = self.evaluator.evaluate(material, before_output)
        behavior_rules = feedback_to_behavior_rules(feedback)
        reflection = self.student.learn_from_feedback(
            material, before_output, before_output, feedback, feedback, behavior_rules
        )
        after_output = self.student.process(material)
        after_feedback = self.evaluator.evaluate(material, after_output)

        return {
            "before_score": round(feedback["score"]),
            "after_score": round(after_feedback["score"]),
            "feedback": feedback,
            "reflection": reflection,
        }
