import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse


DATABASE_DIR = Path(__file__).resolve().parent / "database"


def load_catalog() -> dict[str, list[dict]]:
    catalog: dict[str, list[dict]] = {}
    for path in DATABASE_DIR.glob("*.json"):
        with path.open("r", encoding="utf-8") as file:
            items = json.load(file)
        for item in items:
            catalog.setdefault(item["domain"], []).append(item)
    return catalog


class KnowledgeHandler(BaseHTTPRequestHandler):
    def send_json(self, status: int, payload) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        request = urlparse(self.path)
        catalog = load_catalog()
        if request.path == "/knowledge/list":
            self.send_json(200, sorted(catalog))
            return
        if request.path == "/knowledge/query":
            domain = parse_qs(request.query).get("domain", [""])[0].strip()
            if not domain:
                self.send_json(400, {"error": "domain is required"})
            elif domain not in catalog:
                self.send_json(404, {"error": f"unknown domain: {domain}"})
            else:
                self.send_json(200, catalog[domain])
            return
        self.send_json(404, {"error": "not found"})

    def log_message(self, format: str, *args) -> None:
        return


def run(host: str = "127.0.0.1", port: int = 8765) -> None:
    server = ThreadingHTTPServer((host, port), KnowledgeHandler)
    print(f"Knowledge API: http://{host}:{port}", flush=True)
    server.serve_forever()


if __name__ == "__main__":
    run()
