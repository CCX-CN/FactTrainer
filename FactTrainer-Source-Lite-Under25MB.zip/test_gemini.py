# -*- coding: utf-8 -*-
import json
import os
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


def main() -> None:
    print("开始运行", flush=True)

    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        raise SystemExit("未设置环境变量 GEMINI_API_KEY")

    url = (
        "https://generativelanguage.googleapis.com/v1beta/"
        "models/gemini-3-flash-preview:generateContent"
    )
    body = {
        "contents": [
            {"parts": [{"text": "请用一句话回复：Gemini API 测试成功。"}]}
        ]
    }
    request = Request(
        url,
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers={
            "Content-Type": "application/json; charset=utf-8",
            "x-goog-api-key": api_key,
        },
        method="POST",
    )

    try:
        with urlopen(request, timeout=30) as response:
            result = json.loads(response.read().decode("utf-8"))
        text = result["candidates"][0]["content"]["parts"][0]["text"]
        print("API返回结果")
        print(text)
    except HTTPError as error:
        detail = error.read().decode("utf-8", errors="replace")
        raise SystemExit(f"Gemini API HTTP {error.code}: {detail}") from error
    except (URLError, KeyError, IndexError, json.JSONDecodeError) as error:
        raise SystemExit(f"Gemini API 调用失败: {error}") from error


if __name__ == "__main__":
    main()
