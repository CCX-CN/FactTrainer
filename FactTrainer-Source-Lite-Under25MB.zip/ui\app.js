let state = { agent: null, training: null, exam: null, chat_history: [], lesson: null, lesson_status: "empty", ai_service: { configured: false } };
let activeOperation = "";
const $ = id => document.getElementById(id);
const escapeHtml = value => String(value).replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]));

async function request(path, options) {
  const response = await fetch(path, options);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Operation failed");
  return data;
}

function rate(level, value) {
  $(level + "-rate").textContent = value + "%";
  $(level + "-bar").style.width = value + "%";
}

function renderLesson(lesson, status) {
  const panel = $("lesson-panel");
  panel.hidden = !lesson;
  if (!lesson) { $("lesson-content").innerHTML = ""; return; }
  const phase = activeOperation === "train" ? "training" : status;
  const display = {
    prepared: ["Teacher Prepared Training Content", "This knowledge has not entered the Agent yet. Click “Start Training”.", "Knowledge Ready for Training", "Questions Ready for Training"],
    training: ["Agent Is Learning", "Teacher-prepared knowledge is being written to the Agent and evaluated.", "Knowledge Being Learned", "Training Questions"],
    learned: ["Learned Knowledge", "Training is complete and this content is now stored in the Agent.", "Learned Knowledge Points", "Completed Training Questions"]
  }[phase] || ["Teacher Prepared Training Content", "This knowledge has not entered the Agent yet. Click “Start Training”.", "Knowledge Ready for Training", "Questions Ready for Training"];
  $("lesson-title").textContent = display[0];
  $("lesson-note").textContent = display[1];
  const points = lesson.knowledge_points || [];
  const questions = lesson.questions || [];
  $("lesson-content").innerHTML = `
    <h3>Knowledge Summary</h3><p>${escapeHtml(lesson.summary || "")}</p>
    <h3>${display[2]}</h3>
    ${points.map(point => `<article><b>${escapeHtml(point.title)}</b><p>${escapeHtml(point.content || point.mechanism || point.explanation || "")}</p></article>`).join("") || "<p>No knowledge points available.</p>"}
    <h3>${display[3]}</h3>
    ${questions.map(item => `<article><b>${escapeHtml(item.question)}</b><p>Reference answer: ${escapeHtml(item.answer)}</p></article>`).join("") || "<p>No questions available.</p>"}`;
}

function renderFlow() {
  const prepared = Boolean(state.lesson), trained = Boolean(state.training);
  const steps = [
    ["Collecting materials", prepared || trained, false],
    ["Analyzing knowledge", prepared || trained, activeOperation === "prepare_material"],
    ["Generating training questions", prepared || trained, false],
    ["Training agent", trained, activeOperation === "train"],
    ["Testing ability", trained, activeOperation === "train"]
  ];
  $("flow-steps").innerHTML = steps.map(([label, done, active]) => {
    const completed = done && !active;
    return `<li class="${completed ? "done" : ""} ${active ? "active" : ""}"><b>${active ? "Running" : completed ? "Done" : "Waiting"}</b><span>${label}</span></li>`;
  }).join("");
  $("flow-status").textContent = activeOperation === "prepare_material" ? "Analyzing material and generating training questions…" : activeOperation === "train" ? "Training the Agent and testing its current ability…" : activeOperation === "exam" ? "Running the final exam…" : state.exam ? `Final exam completed: ${state.exam.score}.` : trained ? "This learning cycle is complete." : prepared ? "The Teacher has prepared the training content. Click “Start Training”." : "Enter learning material in step 1 first.";
}

function renderGrowth() {
  const panel = $("growth-panel"), training = state.training;
  panel.hidden = !training;
  if (!training) return;
  const before = Number(training.before_score), after = Number(training.after_score), change = after - before;
  $("before-score").textContent = before;
  $("after-score").textContent = after;
  $("score-change").textContent = `${change >= 0 ? "+" : ""}${change}`;
  $("new-knowledge-count").textContent = Number.isFinite(Number(training.new_knowledge_count)) ? training.new_knowledge_count : "—";
  $("growth-summary").textContent = change > 0 ? "Knowledge score improved" : change === 0 ? "No score change" : "Knowledge score decreased";
}

function render() {
  const service = state.ai_service || { configured: false };
  $("ai-config-status").textContent = service.configured ? `Gemini configured (${service.model})` : "Save a Gemini API Key once to enable the Teacher workflow.";
  const has = Boolean(state.agent);
  $("empty").hidden = has;
  $("dashboard").hidden = !has;
  $("create-panel").hidden = has;
  $("action-panel").hidden = !has;
  $("new-agent-button").hidden = !has;
  if (!has) { $("agent-list").innerHTML = "<p>No Agent yet</p>"; return; }

  const agent = state.agent;
  const hasCurrentMaterial = Boolean(state.lesson), hasTraining = Boolean(state.training), hasLearned = agent.learned_count > 0;
  $("agent-list").innerHTML = `<div class="agent-card"><b>${escapeHtml(agent.name)}</b><small>${escapeHtml(agent.domain)} · Level ${agent.level}</small></div>`;
  $("agent-name").textContent = agent.name;
  $("agent-domain").textContent = agent.domain;
  $("score").textContent = agent.score;
  $("learned").textContent = agent.learned_count;
  $("training-state").textContent = hasTraining ? "Learning cycle complete" : hasCurrentMaterial ? "Training content ready" : "Waiting for material";
  $("agent-state").textContent = hasLearned ? "Knowledge learned" : "Not trained";
  $("exam-score").textContent = state.exam ? state.exam.score : "Not taken";
  $("train-agent-name").textContent = agent.name;
  $("train-learned-count").textContent = agent.learned_count;
  $("train-agent-score").textContent = agent.score;
  rate("basic", agent.mastery_rates.basic); rate("intermediate", agent.mastery_rates.intermediate); rate("advanced", agent.mastery_rates.advanced);
  $("train-button").disabled = !hasCurrentMaterial || Boolean(activeOperation);
  $("exam-button").disabled = !hasTraining || Boolean(activeOperation);
  $("exam-button").textContent = activeOperation === "exam" ? "Exam in progress…" : "Run Final Exam";
  $("action-help").textContent = hasTraining ? `Cycle complete: ${state.training.before_score} before training, ${state.training.after_score} after training.` : hasCurrentMaterial ? "The Teacher has organized the knowledge. Training can now begin." : "Complete step 1 to prepare knowledge for training.";
  renderFlow(); renderGrowth();

  const records = state.training?.records || [];
  $("record-count").textContent = records.length ? `${records.length} records` : "";
  $("log-list").innerHTML = records.length ? records.map(record => `<div class="log"><time>${escapeHtml(record.time)}</time><span>${escapeHtml(record.topic)}</span><span>${escapeHtml(record.level)}</span><span class="${record.score_before < 60 ? "bad" : ""}">${record.score_before} → ${record.score_after}</span><span>${record.missing_keywords.length ? "Missing before training: " + record.missing_keywords.map(escapeHtml).join(", ") : "Passed before training"}</span></div>`).join("") : "<p class='empty-line'>Records will appear after training.</p>";
  const chats = state.chat_history || [];
  $("chat-history").innerHTML = chats.length ? chats.map(item => `<p><b>Question: ${escapeHtml(item.question)}</b><span>Agent answer: ${escapeHtml(item.answer)}</span></p>`).join("") : "<p>No Agent Q&amp;A records yet.</p>";
  const lessonStatus = state.lesson_status || (state.training ? "learned" : state.lesson ? "prepared" : "empty");
  renderLesson(state.lesson, lessonStatus);
}

async function act(path, body) {
  $("error").textContent = "";
  activeOperation = path === "/api/train" ? "train" : path === "/api/exam" ? "exam" : body?.action === "prepare_material" ? "prepare_material" : "";
  render();
  try {
    state = await request(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) });
  } catch (error) {
    $("error").textContent = error.message;
  } finally {
    activeOperation = "";
    render();
  }
}

$("create-form").addEventListener("submit", event => { event.preventDefault(); act("/api/agents", { name: $("name-input").value, domain: $("domain-input").value }); });
$("ai-config-form").addEventListener("submit", async event => { event.preventDefault(); $("error").textContent = ""; const input = $("gemini-key-input"); try { const data = await request("/api/config", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ gemini_api_key: input.value }) }); state.ai_service = data.ai_service; input.value = ""; render(); } catch (error) { $("error").textContent = error.message; } });
$("material-form").addEventListener("submit", event => { event.preventDefault(); const input = $("material-input"); act("/api/chat", { action: "prepare_material", material: input.value }).then(() => { input.value = ""; }); });
$("question-form").addEventListener("submit", event => { event.preventDefault(); const input = $("question-input"); act("/api/chat", { action: "ask_agent", question: input.value }).then(() => { input.value = ""; }); });
$("train-button").onclick = () => act("/api/train");
$("exam-button").onclick = () => act("/api/exam");
$("new-agent-button").onclick = () => {
  $("dashboard").hidden = true;
  $("action-panel").hidden = true;
  $("empty").hidden = true;
  $("create-panel").hidden = false;
  $("name-input").value = "";
  $("domain-input").value = "";
  $("name-input").focus();
};
request("/api/state").then(data => { state = data; render(); }).catch(() => { $("error").textContent = "The Fact Trainer backend could not start."; });
