use std::{net::TcpListener, process::{Child, Command}, sync::Mutex, thread, time::Duration};
use tauri::{Manager, WebviewUrl, WebviewWindowBuilder};

struct Backend(Mutex<Option<Child>>);

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
  tauri::Builder::default()
    .setup(|app| {
      let executable = std::env::current_exe()?;
      let release_sidecar = executable.parent().unwrap().join("fact-trainer-backend.exe");
      let dev_sidecar = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("binaries").join("fact-trainer-backend-x86_64-pc-windows-msvc.exe");
      let sidecar = if release_sidecar.exists() { release_sidecar } else { dev_sidecar };
      let listener = TcpListener::bind("127.0.0.1:0")?;
      let port = listener.local_addr()?.port();
      drop(listener);
      let mut command = Command::new(sidecar);
      command.arg(port.to_string());
      #[cfg(windows)]
      {
        use std::os::windows::process::CommandExt;
        command.creation_flags(0x08000000);
      }
      let child = command.spawn()?;
      app.manage(Backend(Mutex::new(Some(child))));
      thread::sleep(Duration::from_millis(700));
      WebviewWindowBuilder::new(
        app,
        "main",
        WebviewUrl::External(format!("http://127.0.0.1:{port}").parse()?),
      )
      .title("Fact Trainer")
      .inner_size(1280.0, 820.0)
      .min_inner_size(960.0, 680.0)
      .build()?;
      Ok(())
    })
    .on_window_event(|window, event| {
      if let tauri::WindowEvent::Destroyed = event {
        if let Some(state) = window.try_state::<Backend>() {
          if let Ok(mut backend) = state.0.lock() {
            if let Some(child) = backend.as_mut() { let _ = child.kill(); }
          }
        }
      }
    })
    .run(tauri::generate_context!())
    .expect("error while running tauri application");
}
