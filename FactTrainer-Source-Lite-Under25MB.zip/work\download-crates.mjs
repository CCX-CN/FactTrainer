import fs from "node:fs";
import path from "node:path";
import https from "node:https";

const lockPath = process.argv[2];
const cacheDir = process.argv[3];
fs.mkdirSync(cacheDir, { recursive: true });
const blocks = fs.readFileSync(lockPath, "utf8").split("[[package]]").slice(1);
const packages = blocks.map(block => {
  const name = block.match(/\nname = "([^"]+)"/)?.[1];
  const version = block.match(/\nversion = "([^"]+)"/)?.[1];
  const source = block.match(/\nsource = "([^"]+)"/)?.[1];
  return { name, version, source };
}).filter(item => item.name && item.version && item.source?.startsWith("registry+"));

function download(url, destination, redirects = 0) {
  return new Promise((resolve, reject) => {
    const temporary = `${destination}.part`;
    const existing = fs.existsSync(temporary) ? fs.statSync(temporary).size : 0;
    https.get(url, { headers: existing ? { Range: `bytes=${existing}-` } : {} }, response => {
      if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location && redirects < 5) {
        response.resume();
        download(response.headers.location, destination, redirects + 1).then(resolve, reject);
        return;
      }
      if (response.statusCode !== 200 && response.statusCode !== 206) {
        response.resume(); reject(new Error(`${response.statusCode} ${url}`)); return;
      }
      const file = fs.createWriteStream(temporary, { flags: response.statusCode === 206 ? "a" : "w" });
      response.pipe(file);
      file.on("finish", () => { file.close(); fs.renameSync(temporary, destination); resolve(); });
      file.on("error", reject);
    }).on("error", reject);
  });
}

let cursor = 0;
async function worker() {
  while (cursor < packages.length) {
    const item = packages[cursor++];
    const destination = path.join(cacheDir, `${item.name}-${item.version}.crate`);
    if (fs.existsSync(destination)) continue;
    const url = `https://static.crates.io/crates/${encodeURIComponent(item.name)}/${item.name}-${item.version}.crate`;
    for (let attempt = 1; attempt <= 3; attempt++) {
      try { await download(url, destination); break; }
      catch (error) { if (attempt === 3) throw error; }
    }
  }
}
await Promise.all(Array.from({ length: 12 }, worker));
console.log(`cached ${packages.length} locked crates`);
