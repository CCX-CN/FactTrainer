# -*- mode: python ; coding: utf-8 -*-
from pathlib import Path

PROJECT_ROOT = Path(SPECPATH).parent
FACT_TRAINER = PROJECT_ROOT / "FactTrainer"
UI = PROJECT_ROOT / "ui"

a = Analysis(
    [str(FACT_TRAINER / "app_server.py")],
    pathex=[str(FACT_TRAINER)],
    binaries=[],
    datas=[
        (str(UI / "index.html"), "ui"),
        (str(UI / "styles.css"), "ui"),
        (str(UI / "app.js"), "ui"),
        (str(FACT_TRAINER / "knowledge"), "FactTrainer\\knowledge"),
        (str(FACT_TRAINER / "student" / "capability_memory.json"), "FactTrainer\\student"),
        (str(FACT_TRAINER / "prompts" / "teacher_prompt.txt"), "FactTrainer\\prompts"),
        (str(FACT_TRAINER / "prompts" / "teacher_prompt.txt"), "prompts"),
    ],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, a.binaries, a.datas, [],
    name="fact-trainer-backend-x86_64-pc-windows-msvc",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
